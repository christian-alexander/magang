<?php 
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "magang";
$connection    = mysqli_connect($host, $user, $password, $database);
?>