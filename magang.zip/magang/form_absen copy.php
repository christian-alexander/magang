<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Absensi</title>
</head>
<body>
<form action=""></form>
    <div>
        <label for="jam_masuk">Jam Masuk</label>
        <br>
        <input type="time" name="jam_masuk" id="jam_masuk">
    </div>
    <br>
    <div>
        <label for="jam_pulang">Jam Pulang</label>
        <br>
        <input type="time" name="jam_pulang" id="jam_pulang">
    </div>
    <br>
    <div>
        <label for="uraian_kegiatan">Uraian kegiatan</label>
        <br>
        <input type="text" name="uraian_kegiatan" id="uraian_kegiatan">
    </div>
</form>
</body>
</html>