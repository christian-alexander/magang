
$("#tombol1").click(function(){
    $(".tombol-bulat").css('font-size','1.5em');
    $(this).css('font-size','1.7em');
    $("#tombol2").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol3").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
    $("#line1").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line2").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line4").css('stroke','rgb(114, 124, 245,0.5)');
    
    $("#box1").css('display','block');
    $("#box2").css('display','none');
    $("#box3").css('display','none');
    $("#box4").css('display','none');
    $("#box5").css('display','none');

    });
$("#tombol2").click(function(){
    $(".tombol-bulat").css('font-size','1.5em');
    $(this).css('font-size','1.7em');
    $("#tombol2").css('background-color','rgb(114, 124, 245)');
    $("#tombol3").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
    $("#line1").css('stroke','rgb(114, 124, 245)');
    $("#line2").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line4").css('stroke','rgb(114, 124, 245,0.5)');

    $("#box1").css('display','none');
    $("#box2").css('display','block');
    $("#box3").css('display','none');
    $("#box4").css('display','none');
    $("#box5").css('display','none');

    });
$("#tombol3").click(function(){
    $(".tombol-bulat").css('font-size','1.5em');
    $(this).css('font-size','1.7em');
    $("#tombol2").css('background-color','rgb(114, 124, 245)');
    $("#tombol3").css('background-color','rgb(114, 124, 245)');
    $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
    $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
    $("#line1").css('stroke','rgb(114, 124, 245)');
    $("#line2").css('stroke','rgb(114, 124, 245)');
    $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
    $("#line4").css('stroke','rgb(114, 124, 245,0.5)');

    $("#box1").css('display','none');
    $("#box2").css('display','none');
    $("#box3").css('display','block');
    $("#box4").css('display','none');
    $("#box5").css('display','none');

    });
$("#tombol4").click(function(){
    $(".tombol-bulat").css('font-size','1.5em');
    $(this).css('font-size','1.7em');
    $("#tombol2").css('background-color','rgb(114, 124, 245)');
    $("#tombol3").css('background-color','rgb(114, 124, 245)');
    $("#tombol4").css('background-color','rgb(114, 124, 245)');
    $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
    $("#line1").css('stroke','rgb(114, 124, 245)');
    $("#line2").css('stroke','rgb(114, 124, 245)');
    $("#line3").css('stroke','rgb(114, 124, 245)');
    $("#line4").css('stroke','rgb(114, 124, 245,0.5)');
    
    $("#box1").css('display','none');
    $("#box2").css('display','none');
    $("#box3").css('display','none');
    $("#box4").css('display','block');
    $("#box5").css('display','none');


	});

    $("#tombol5").click(function(){
        $(".tombol-bulat").css('font-size','1.5em');
        $(this).css('font-size','1.7em');
        $("#tombol2").css('background-color','rgb(114, 124, 245)');
        $("#tombol3").css('background-color','rgb(114, 124, 245)');
        $("#tombol4").css('background-color','rgb(114, 124, 245)');
        $("#tombol5").css('background-color','rgb(114, 124, 245)');
        $("#line1").css('stroke','rgb(114, 124, 245)');
        $("#line2").css('stroke','rgb(114, 124, 245)');
        $("#line3").css('stroke','rgb(114, 124, 245)');
        $("#line4").css('stroke','rgb(114, 124, 245)');
        
    	$("#box1").css('display','none');
        $("#box2").css('display','none');
        $("#box3").css('display','none');
        $("#box4").css('display','none');
        $("#box5").css('display','block');


    	});
    
