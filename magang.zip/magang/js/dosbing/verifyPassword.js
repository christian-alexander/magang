function verifikasi(){
    var password = document.getElementById("passBaru");
    var konfirmasipassword = document.getElementById("konfirmasiPassBaru");

    var warningPassword = document.getElementById('warningPassBaru');
    var warningKonfirmasiPassword = document.getElementById('warningKonfirmasiPassBaru');
    

    var isipassword = password.value;
    if(isipassword == ""){
        warningPassword.innerHTML = " *Wajib";
        var passwordValid = false;
    }else if(isipassword.length <8){
        warningPassword.innerHTML = " *Minimal 8 Digit";
        var passwordValid = false;        
    }else{
        warningPassword.innerHTML = "";
        var passwordValid = true;
    }

    var konfirmasiIsiPassword = konfirmasipassword.value;
    if(konfirmasiIsiPassword == ""){
        warningKonfirmasiPassword.innerHTML = " *Wajib";
        var konfirmasiPasswordValid = false;
    }else if(konfirmasiIsiPassword != isipassword){
        warningKonfirmasiPassword.innerHTML = " *Password Tidak Sama";
        var konfirmasiPasswordValid = false;        
    }else{
        warningKonfirmasiPassword.innerHTML = "";
        var konfirmasiPasswordValid = true;
    }
    if(passwordValid && konfirmasiPasswordValid){
        return true ;
    }else{
        return false ;
    }
}