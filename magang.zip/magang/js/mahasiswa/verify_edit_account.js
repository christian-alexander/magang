function verifikasi(){
    var nama = document.getElementById("nama");
    var email = document.getElementById("email");
    var nowa = document.getElementById("nowa");
    
    var warningNama = document.getElementById('warningNama');
    var warningEmail = document.getElementById('warningEmail');
    var warningNowa = document.getElementById('warningNowa');
    var warningNRP = document.getElementById('warningNRP');

    if(nama.value == ""){
        warningNama.innerHTML = " *Wajib";
        var namaValid = false;
    }
    else{
        warningNama.innerHTML = "";
        var namaValid = true;
    }
	
    if(email.value == ""){
        warningEmail.innerHTML = " *Wajib";
        var emailValid = false ;
    }else if((email.value).indexOf("@")<0){
        warningEmail.innerHTML = " *Email Tidak Valid";
        var emailValid = false ;
    }else{
        warningEmail.innerHTML = "";
        var emailValid = true ;
    }
    

    if(nowa.value == ""){
        warningNowa.innerHTML = " *Wajib";
        var nowaValid = false ;
    }else if(isNaN(nowa.value)){
        warningNowa.innerHTML = " *Harus Angka";
        var nowaValid = false ;
    }else{
        warningNowa.innerHTML = "";
        var nowaValid = true ;
    }
    
    var pilihanperan=document.getElementById('peran');
    var isiNRP = document.getElementById('NRP');
    if(pilihanperan.value == "Dosen Pembimbing"){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else if(pilihanperan.value == "Mahasiswa"){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else{
        warningNRP.innerHTML ="";
        var NRPValid = true ;
    }

    if(namaValid  && nowaValid && emailValid && NRPValid){
        return true;
    }
    else{
        return false;
    }
}

function verifikasiAwal(){
    var nama = document.getElementById("nama");
    var email = document.getElementById("email");
    var nowa = document.getElementById("nowa");
    var instansi = document.getElementById('instansi');
    var pemlap = document.getElementById('pembimbing_lapangan');
    
    var warningNama = document.getElementById('warningNama');
    var warningEmail = document.getElementById('warningEmail');
    var warningNowa = document.getElementById('warningNowa');
    var warningNRP = document.getElementById('warningNRP');

    if(nama.value == ""){
        warningNama.innerHTML = " *Wajib";
        var namaValid = false;
    }
    else{
        warningNama.innerHTML = "";
        var namaValid = true;
    }
	
    if(email.value == ""){
        warningEmail.innerHTML = " *Wajib";
        var emailValid = false ;
    }else if((email.value).indexOf("@")<0){
        warningEmail.innerHTML = " *Email Tidak Valid";
        var emailValid = false ;
    }else{
        warningEmail.innerHTML = "";
        var emailValid = true ;
    }
    

    if(nowa.value == ""){
        warningNowa.innerHTML = " *Wajib";
        var nowaValid = false ;
    }else if(isNaN(nowa.value)){
        warningNowa.innerHTML = " *Harus Angka";
        var nowaValid = false ;
    }else{
        warningNowa.innerHTML = "";
        var nowaValid = true ;
    }
    
    var pilihanperan=document.getElementById('peran');
    var isiNRP = document.getElementById('NRP');
    if(pilihanperan.value == "Dosen Pembimbing"){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else if(pilihanperan.value == "Mahasiswa"){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else{
        warningNRP.innerHTML ="";
        var NRPValid = true ;
    }


    if(pemlap.value == ""){
        var pemlapValid = false;
    }else{
        var pemlapValid = true ;
    }

    if(instansi.value == '1'){
        var instansiValid = false;
    }else{
        var instansiValid = true;
    }

    $setuju = false ;
    if(confirm("Apakah anda yakin? anda tidak dapat mengubah instansi dan pembimbing lapangan di kemudian hari\n\nWARNING : bila data instansi dan pembimbing lapangan belum ada di pilihan tekan cancel")){
        if(confirm("Apakah anda benar-benar yakin? pastikan data pembimbing lapangan dan instansi(perusahaan) magang sudah betul")){
            $setuju = true ; 
        }else{
            setuju = false;
        }
    }else{
        $setuju = false;
    }




    if(namaValid  && nowaValid && emailValid && NRPValid && setuju && instansiValid && pemlapValid){
        return true;
    }
    else{
        return false;
    }
}
