// ada error returnya dianggap true :") //
// 3 jam dewekk cari errornya dimana //
// eh cuma lupa nyatakan variabel //
// 11 jan 2021 //

function verifikasi(){
    var nama = document.getElementById("nama");
    var NRP = document.getElementById("NRP");
    var email = document.getElementById("email");
    var password = document.getElementById("password");
    var konfirmasipassword = document.getElementById("konfirmasipassword");
    var nowa = document.getElementById("nowa");
    
    var warningNama = document.getElementById('warningNama');
    var warningEmail = document.getElementById('warningEmail');
    var warningPassword = document.getElementById('warningPassword');
    var warningKonfirmasiPassword = document.getElementById('warningKonfirmasiPassword');
    var warningNowa = document.getElementById('warningNowa');
    var warningNRP = document.getElementById('warningNRP');

    if(nama.value == ""){
        warningNama.innerHTML = " *Wajib";
        var namaValid = false;
    }
    else{
        warningNama.innerHTML = "";
        var namaValid = true;
    }
	
    if(email.value == ""){
        warningEmail.innerHTML = " *Wajib";
        var emailValid = false ;
    }else if((email.value).indexOf("@")<0){
        warningEmail.innerHTML = " *Email Tidak Valid";
        var emailValid = false ;
    }else{
        warningEmail.innerHTML = "";
        var emailValid = true ;
    }
    
    var isipassword = password.value;
    if(isipassword == ""){
        warningPassword.innerHTML = " *Wajib";
        var passwordValid = false;
    }else if(isipassword.length <8){
        warningPassword.innerHTML = " *Minimal 8 Digit";
        var passwordValid = false;        
    }else{
        warningPassword.innerHTML = "";
        var passwordValid = true;
    }

    var konfirmasiIsiPassword = konfirmasipassword.value;
    if(konfirmasiIsiPassword == ""){
        warningKonfirmasiPassword.innerHTML = " *Wajib";
        var konfirmasiPasswordValid = false;
    }else if(konfirmasiIsiPassword != isipassword){
        warningKonfirmasiPassword.innerHTML = " *Password Tidak Sama";
        var konfirmasiPasswordValid = false;        
    }else{
        warningKonfirmasiPassword.innerHTML = "";
        var konfirmasiPasswordValid = true;
    }

    if(nowa.value == ""){
        warningNowa.innerHTML = " *Wajib";
        var nowaValid = false ;
    }else if(isNaN(nowa.value)){
        warningNowa.innerHTML = " *Harus Angka";
        var nowaValid = false ;
    }else{
        warningNowa.innerHTML = "";
        var nowaValid = true ;
    }
    
    var pilihanperan=document.getElementById('peran');
    var isiNRP = document.getElementById('NRP');

    if(pilihanperan.value == 4){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else{
        warningNRP.innerHTML ="";
        var NRPValid = true ;
    }

    if(namaValid  && nowaValid && emailValid && NRPValid && passwordValid && konfirmasiPasswordValid){
        return true;
    }
    else{
        return false;
    }
}

/*
function lihat_password(){
    var lihatpassword = document.getElementById('password');
    lihatpassword.type = 'text';
}

function lihat_konfirmasipassword(){
    var lihatkonfirmasipassword = document.getElementById('konfirmasipassword');
    lihatkonfirmasipassword.type = 'text';
}
*/

function gantiNRP(){
    var pilihanperan = document.getElementById('peran');
    var teksNRP = document.getElementById('teksNRP');
    if (pilihanperan.value == 2){
        teksNRP.innerHTML = "NIDN";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "none";
        boxmhs[1].style.display = "none";
    }else if (pilihanperan.value == 3){
        teksNRP.innerHTML = "NIP (opsional)";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "none";
        boxmhs[1].style.display = "none";
    }else if (pilihanperan.value == 4){
        teksNRP.innerHTML = "NRP";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "block";
        boxmhs[1].style.display = "block";
    }
    
}