function verifikasi(){
    var Nama = document.getElementById("Nama");
    var Email = document.getElementById("Email");
    var NoTelp = document.getElementById("NoTelp");
    var NoFax = document.getElementById("NoFax");
    var Alamat = document.getElementById("Alamat");

    
    var warningNama = document.getElementById('warningNama');
    var warningEmail = document.getElementById('warningEmail');
    var warningNoTelp = document.getElementById('warningNoTelp');
    var warningNoFax = document.getElementById('warningNoFax');
    var warningAlamat = document.getElementById('warningAlamat');

    if(Nama.value == ""){
        warningNama.innerHTML = " *Wajib";
        var NamaValid = false;
    }
    else{
        warningNama.innerHTML = "";
        var NamaValid = true;
    }
	
    if(Email.value == ""){
        warningEmail.innerHTML = " *Wajib";
        var EmailValid = false ;
    }else if((Email.value).indexOf("@")<0){
        warningEmail.innerHTML = " *Email Tidak Valid";
        var EmailValid = false ;
    }else{
        warningEmail.innerHTML = "";
        var EmailValid = true ;
    }
    

    if(NoTelp.value == ""){
        warningNoTelp.innerHTML = " *Wajib";
        var NoTelpValid = false ;
    }else if(isNaN(NoTelp.value)){
        warningNoTelp.innerHTML = " *Harus Angka";
        var NoTelpValid = false ;
    }else{
        warningNoTelp.innerHTML = "";
        var NoTelpValid = true ;
    }

  

    if(Alamat.value == ""){
        warningAlamat.innerHTML = " *Wajib";
        var AlamatValid = false;
    }
    else{
        warningAlamat.innerHTML = "";
        var AlamatValid = true;
    }

    if(NamaValid  && NoTelpValid && EmailValid && AlamatValid){
        return true;
    }
    else{
        return false;
    }
}

