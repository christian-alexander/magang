$(document).ready(function(){
$('#myTable').dataTable();
});


