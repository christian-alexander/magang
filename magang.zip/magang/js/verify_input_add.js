// ada error returnya dianggap true :") //
// 3 jam dewekk cari errornya dimana //
// eh cuma lupa nyatakan variabel //
// signed : alex //

function verifikasi(){
    var nama = document.getElementById("nama");
    var email = document.getElementById("email");
    var nowa = document.getElementById("nowa");
    
    var warningNama = document.getElementById('warningNama');
    var warningEmail = document.getElementById('warningEmail');
    var warningNowa = document.getElementById('warningNowa');
    var warningNRP = document.getElementById('warningNRP');

    if(nama.value == ""){
        warningNama.innerHTML = " *Wajib";
        var namaValid = false;
    }
    else{
        warningNama.innerHTML = "";
        var namaValid = true;
    }
	
    if(email.value == ""){
        warningEmail.innerHTML = " *Wajib";
        var emailValid = false ;
    }else if((email.value).indexOf("@")<0){
        warningEmail.innerHTML = " *Email Tidak Valid";
        var emailValid = false ;
    }else{
        warningEmail.innerHTML = "";
        var emailValid = true ;
    }
    

    if(nowa.value == ""){
        warningNowa.innerHTML = " *Wajib";
        var nowaValid = false ;
    }else if(isNaN(nowa.value)){
        warningNowa.innerHTML = " *Harus Angka";
        var nowaValid = false ;
    }else{
        warningNowa.innerHTML = "";
        var nowaValid = true ;
    }
    
    var pilihanperan=document.getElementById('peran');
    var isiNRP = document.getElementById('NRP');
    if(pilihanperan.value == 2){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else if(pilihanperan.value == 4){
		if(isiNRP.value == ""){
            warningNRP.innerHTML = " *Wajib";
            var NRPValid = false ;
        }else if(isNaN(isiNRP.value)){
            warningNRP.innerHTML = " *Harus Angka";
            var NRPValid = false ;
        }else{
            warningNRP.innerHTML = "";
            var NRPValid = true ;
        }
    }else{
        warningNRP.innerHTML ="";
        var NRPValid = true ;
    }

    if(namaValid  && nowaValid && emailValid && NRPValid){
        return true;
    }
    else{
        return false;
    }
}


function gantiNRP(){
    var pilihanperan = document.getElementById('peran');
    var teksNRP = document.getElementById('teksNRP');
    if (pilihanperan.value == 2){
        teksNRP.innerHTML = "NIDN";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "none";
        boxmhs[1].style.display = "none";
    }else if (pilihanperan.value == 3){
        teksNRP.innerHTML = "NIP (opsional)";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "none";
        boxmhs[1].style.display = "none";
    }else if (pilihanperan.value == 4){
        teksNRP.innerHTML = "NRP";
        var boxmhs = document.getElementsByClassName('utkmhs');
        boxmhs[0].style.display = "block";
        boxmhs[1].style.display = "block";
    }
    
}