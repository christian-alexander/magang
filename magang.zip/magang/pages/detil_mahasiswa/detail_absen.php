<?php
    include('../../connection/connection.php');

    $id_utama = $_POST['id_utama'];

    //untuk isi dari detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$id_utama."");

    $id_absen = $_POST['dataValueAbsen'];
    $seleksiDataAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$id_utama." WHERE id_absen = '".$id_absen."'");
    $seleksiFileAbsen = mysqli_query($connection,"SELECT * FROM _data_file_absen_mhs".$id_utama." WHERE id_absen = '".$id_absen."'");


    //untuk download
    if(isset($_GET['file'])){
        $filename = basename(($_GET['file']));
        $filepatch = '../../filepool/' . $filename;
        if(!empty($filename) && file_exists($filepatch)) {
            header("Cache-Control: public");
            header("Content-Description: FIle Trasfer");
            header("Content-disposition: attachment; filename=$filename");
            header("Content-Type: application/zip");
            header("Content-Tranfer-Encoding:binary");

            readfile($filepatch);
            exit;
        }
    }
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel = "stylesheet" href="../../css/detil_mahasiswa/detil_mahasiswa.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
	  
	<div class = "container" style="padding-top:5em;">
        <div class = "box-keterangan" style="overflow-wrap:break-word;">
            <h3><b><p style = "text-align:center;">Detail Absensi</p></b></h3><?php
            foreach($seleksiDataAbsen as $row){ ?>
                <div class = "row">
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Tanggal</b><br>
                        <?php echo $row['tanggal']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Jam Masuk</b><br>
                        <?php echo $row['jam_mulai']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Jam Pulang</b><br>
                        <?php echo $row['jam_selesai']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6"> 
                        <b>Status</b><br>
                        <?php echo $row['status'] ?><br><br>
                    </div>
                </div>
                <div style = "text-align:justify;"> 
                    <b>Uraian Kegiatan</b><br>
                    <?php echo $row['uraian_kegiatan']?><br><br>
                </div>
                <div>
                    <b>File Bukti</b>
                    <form method = "POST" action="../detil_mahasiswa/donlod_absen.php">
                        <ul style = "list-style:decimal;"><?php
                        foreach($seleksiFileAbsen as $rowFile){?>
                            <li>
                                <input type = "text" style = "display:none;" value ="<?php echo $rowFile['file']?>" name = "file"> 
                                <button class = "btn-donlod"><a class = "link-donlod"><?php echo $rowFile['file']?> </a></button>
                            </li><?php
                        } ?>
                        </ul>
                    </form>
                </div><?php
            } ?>
            <div class="div-add" action="#">
                <form method = "POST">
                    <input type = "text" name = "dataValue" value = "<?php echo $_POST['id_utama'] ?>" style ="display:none;">
                    <button type ="submit" class = "btn btn-primary add">Back</button>
                </form>
            </div>              
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

    <script>
        
        $(document).ready(function(){
            $('html,body').scrollTop(0);
        });
    </script>
</body>