<?php
    include("../../connection/connection.php");

    $id_utama = $_POST['dataValue'];
    $seleksiRow = mysqli_query($connection, "SELECT * FROM mahasiswa WHERE id_utama = '".$id_utama."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    
    $nama = $seleksiKolom['nama'];
    $email = $seleksiKolom['email'];
    $nowa = $seleksiKolom['nowa'];
    $nrp = $seleksiKolom['nrp'];
    
    $instansi = $seleksiKolom['instansi'];
    $seleksiRowInstansi = mysqli_query($connection, "SELECT * FROM instansi WHERE id_instansi = '".$instansi."'");
    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
    $namaInstansi = $seleksiKolomInstansi['nama'];

    $dosenpembimbing = $seleksiKolom['dosenpembimbing'];
    $seleksiRowDosbing = mysqli_query($connection, "SELECT * FROM dosen_pembimbing WHERE id_utama = '".$dosenpembimbing."'");
    $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiRowDosbing);
    $namaDosbing = $seleksiKolomDosbing['nama'];
    
    $pembimbinglapangan = $seleksiKolom['pembimbinglapangan'];
    if($seleksiKolom['pembimbinglapangan']==""){
        $namaPemlap="Tidak Ada";
    }else{
        $seleksiRowPemlap = mysqli_query($connection, "SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$pembimbinglapangan."'");
        $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiRowPemlap);
        $namaPemlap = $seleksiKolomPemlap['nama'];
    }
?>

<!DOCTYPE html>
<head>
    <title>Wajib Ada</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/detil_mahasiswa/detil_mahasiswa.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <h1>Info Pribadi</h1>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="instansi.php">Instansi</a>
                    </li>
                    <!--
                    <li class="nav-item">
                    	<a class="nav-link" href="pengajuan_perusahaan.php">Pengajuan Perusahaan</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="laporan_akhir.php">Laporan Akhir</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
					-->
                    <li class="nav-item">
                    	<a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

<div class = "container">
        <h1><b><p style="margin-top:3em;margin-bottom:0em;">Biodata Mahasiswa</p></b></h1>
        <table>
            <tr>
                <td style="padding-right: 170px;">Nama</td>
                <td style="padding-right: 10px;">:</td>
                <td><?php echo $nama?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>:</td>
                <td><?php echo $email?></a></td>
            </tr>
            <tr>
                <td>No Whatsapp</td>
                <td>:</td>
                <td><?php echo $nowa?></td>
            </tr>
            <tr>
                <td>NRP</td>
                <td>:</td>
                <td><?php echo $nrp?></td>
            </tr>
            <tr>
                <td>Instansi</td>
                <td>:</td>
                <td><?php echo $namaInstansi?></td>
            </tr>
            <tr>
                <td>Nama Dosen Pembimbing</td>
                <td>:</td>
                <td><?php echo $namaDosbing?></td>
            </tr>   
            <tr>
                <td>Nama Pembimbing Lapangan</td>
                <td>:</td>
                <td>
                    <?php echo $namaPemlap;?>
                </td>
            </tr>
        </table>
</div>
<section class="cd-horizontal-timeline">
	<div class="timeline">
		<div class="events-wrapper" style="border: none;">
			<div class="events">
				<ol style="list-style : none ;">
                    <li><a href="#0" data-date="14/06/2016" class="selected">Senin, 14/06/2016</a></li>
					<li><a href="#0" data-date="21/06/2016">Selasa, 15/06/2016</a></li>
					<li><a href="#0" data-date="24/06/2016">June 24</a></li>
					<li><a href="#0" data-date="30/06/2016">June 21-30</a></li>
					<li><a href="#0" data-date="08/07/2016"> July</a></li>
					<li><a href="#0" data-date="17/07/2016">June 28</a></li>
					<li><a href="#0" data-date="23/07/2016">June 30</a></li>
					<li><a href="#0" data-date="26/07/2016">Aug 23</a></li>
					<li><a href="#0" data-date="30/07/2016">Sep 25</a></li>
				</ol>

				<span class="filling-line" aria-hidden="true"></span>
			</div> <!-- .events -->
		</div> <!-- .events-wrapper -->
			
		<ul class="cd-timeline-navigation" style="list-style : none ;">
			<li><a href="#0" class="prev inactive">Prev</a></li>
			<li><a href="#0" class="next">Next</a></li>
		</ul> <!-- .cd-timeline-navigation -->
	</div> <!-- .timeline -->

	<div class="events-content">
		<ol style="list-style : none ;">
			<li class="selected" data-date="14/06/2016">
				<h2>TK</h2>
				<em>June 14th, 2016</em>
				<p>	
					Wkwkwk
				</p>
			</li>

			<li data-date="21/06/2016">
				<h2>TK</h2>
				<em>June 21st, 2016</em>
				<p>	
					CNN publishes “Doctors issue warning about LED streetlighting.”
				</p>
			</li>

			<li data-date="24/06/2016">
				<h2>TK</h2>
				<em>June 24th, 2016</em>
				<p>	
					In response to AMA Report 2-A-16, IES Issues “IES Board Position on AMA CSAPH Report 2-A-16.
				</p>
			</li>

			<li data-date="30/06/2016">
				<h2>TK</h2>
				<em>June 21-30th, 2016</em>
				<p>	
					Various entities in the lighting community issue responses to AMA Report 2-A-16.
				</p>
			</li>

			<li data-date="08/07/2016">
				<h2>TK</h2>
				<em>July, 2016</em>
				<p>	
					Lighting publications report on the AMA controversy. 
				</p>
			</li>

			<li data-date="17/07/2016">
				<h2>TK</h2>
				<em>June 28th, 2017</em>
				<p>	
					IES issues Position Statement PS-09-17 (status update of dialogue with AMA). 
				</p>
			</li>

			<li data-date="23/07/2016">
				<h2>TK</h2>
				<em>June 30th, 2017</em>
				<p>	
					IALD endorses IES Position Statement PS-09-17. 
				</p>
			</li>

			<li data-date="26/07/2016">
				<h2>TK</h2>
				<em>August 23rd, 2017</em>
				<p>	
					U.S. Department of Energy’s Solid-State Lighting program issues an activity and research update in its SSL Postings newsletter. 
				</p>
			</li>

			<li data-date="30/07/2016">
				<h2>TK</h2>
				<em>September 25, 2017</em>
				<p>	
					The Washington Post publishes, “Some cities are taking another look at LED lighting after AMA warning.”
				</p>
			</li>

			
		</ol>
    </div> <!-- .events-content -->
</section>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="../../js/detil_mahasiswa/detil_mahasiswa.js"></script>
</body>