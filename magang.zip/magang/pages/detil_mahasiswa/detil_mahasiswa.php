<?php
    session_start();

    include("../../connection/connection.php");
    
    $id_utama = $_SESSION['datamhs'];
    $seleksiRow = mysqli_query($connection, "SELECT * FROM mahasiswa WHERE id_utama = '".$id_utama."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    
    $nama = $seleksiKolom['nama'];
    $email = $seleksiKolom['email'];
    $nowa = $seleksiKolom['nowa'];
    $nrp = $seleksiKolom['nrp'];
    
    $instansi = $seleksiKolom['instansi'];
    $seleksiRowInstansi = mysqli_query($connection, "SELECT * FROM instansi WHERE id_instansi = '".$instansi."'");
    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
    $namaInstansi = $seleksiKolomInstansi['nama'];

    $dosenpembimbing = $seleksiKolom['dosenpembimbing'];
    $seleksiRowDosbing = mysqli_query($connection, "SELECT * FROM dosen_pembimbing WHERE id_utama = '".$dosenpembimbing."'");
    $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiRowDosbing);
    $namaDosbing = $seleksiKolomDosbing['nama'];
    
    $pembimbinglapangan = $seleksiKolom['pembimbinglapangan'];
    if($seleksiKolom['pembimbinglapangan']==""){
        $namaPemlap="Tidak Ada";
    }else{
        $seleksiRowPemlap = mysqli_query($connection, "SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$pembimbinglapangan."'");
        $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiRowPemlap);
        $namaPemlap = $seleksiKolomPemlap['nama'];
    }
?>

<!DOCTYPE html>
<head>
    <title>Wajib Ada</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/detil_mahasiswa/detil_mahasiswa.css">
</head>
<body>
    <div class = "container">
        <h1><b><p style="margin-top:3em;margin-bottom:0em;">Biodata Mahasiswa</p></b></h1>
        <table>
            <tr>
                <td style="padding-right: 170px;">Nama</td>
                <td style="padding-right: 10px;">:</td>
                <td><?php echo $nama?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>:</td>
                <td><?php echo $email?></a></td>
            </tr>
            <tr>
                <td>No Whatsapp</td>
                <td>:</td>
                <td><?php echo $nowa?></td>
            </tr>
            <tr>
                <td>NRP</td>
                <td>:</td>
                <td><?php echo $nrp?></td>
            </tr>
            <tr>
                <td>Instansi</td>
                <td>:</td>
                <td><?php echo $namaInstansi?></td>
            </tr>
            <tr>
                <td>Nama Dosen Pembimbing</td>
                <td>:</td>
                <td><?php echo $namaDosbing?></td>
            </tr>   
            <tr>
                <td>Nama Pembimbing Lapangan</td>
                <td>:</td>
                <td>
                    <?php echo $namaPemlap;?>
                </td>
            </tr>
        </table>
    </div>
    <div class = "container tempat-timeline">
        <table class = "table">
            <tr>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol1" style ="font-size:1.7em; background-color : rgb(114, 124, 245);">1</button>
                   
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line1">
                    </svg>
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol2">2</button>
                    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line2">
                    </svg>    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol3">3</button>
                    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line3">
                    </svg>
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol4">4</button>
                    
                </td>
            </tr>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        $("#tombol1").click(function(){
            $(".tombol-bulat").css('font-size','1.5em');
            $(this).css('font-size','1.7em');
            $("#tombol2").css('background-color','rgb(114, 124, 245,0.5)');
            $("#tombol3").css('background-color','rgb(114, 124, 245,0.5)');
            $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
            $("#line1").css('stroke','rgb(114, 124, 245,0.5)');
            $("#line2").css('stroke','rgb(114, 124, 245,0.5)');
            $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
            });
        $("#tombol2").click(function(){
            $(".tombol-bulat").css('font-size','1.5em');
            $(this).css('font-size','1.7em');
            $("#tombol2").css('background-color','rgb(114, 124, 245)');
            $("#tombol3").css('background-color','rgb(114, 124, 245,0.5)');
            $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
            $("#line1").css('stroke','rgb(114, 124, 245)');
            $("#line2").css('stroke','rgb(114, 124, 245,0.5)');
            $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
            });
        $("#tombol3").click(function(){
            $(".tombol-bulat").css('font-size','1.5em');
            $(this).css('font-size','1.7em');
            $("#tombol2").css('background-color','rgb(114, 124, 245)');
            $("#tombol3").css('background-color','rgb(114, 124, 245)');
            $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
            $("#line1").css('stroke','rgb(114, 124, 245)');
            $("#line2").css('stroke','rgb(114, 124, 245)');
            $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
            });
        $("#tombol4").click(function(){
            $(".tombol-bulat").css('font-size','1.5em');
            $(this).css('font-size','1.7em');
            $("#tombol2").css('background-color','rgb(114, 124, 245)');
            $("#tombol3").css('background-color','rgb(114, 124, 245)');
            $("#tombol4").css('background-color','rgb(114, 124, 245)');
            $("#line1").css('stroke','rgb(114, 124, 245)');
            $("#line2").css('stroke','rgb(114, 124, 245)');
            $("#line3").css('stroke','rgb(114, 124, 245)');
            });
            
    </script>
</body>