<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<?php
    session_start();

    include("../../connection/connection.php");
    
    date_default_timezone_set("Asia/Bangkok");

    $id_utama = $_SESSION['datamhs'];
    $seleksiRow = mysqli_query($connection, "SELECT * FROM mahasiswa WHERE id_utama = '".$id_utama."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    
    //untuk biodata
    $nama = $seleksiKolom['nama'];
    $email = $seleksiKolom['email'];
    $nowa = $seleksiKolom['nowa'];
    $nrp = $seleksiKolom['nrp'];
    
    $instansi = $seleksiKolom['instansi'];
    $seleksiRowInstansi = mysqli_query($connection, "SELECT * FROM instansi WHERE id_instansi = '".$instansi."'");
    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
    $namaInstansi = $seleksiKolomInstansi['nama'];

    $dosenpembimbing = $seleksiKolom['dosenpembimbing'];
    $seleksiRowDosbing = mysqli_query($connection, "SELECT * FROM dosen_pembimbing WHERE id_utama = '".$dosenpembimbing."'");
    $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiRowDosbing);
    $namaDosbing = $seleksiKolomDosbing['nama'];
    
    $pembimbinglapangan = $seleksiKolom['pembimbinglapangan'];
    if($seleksiKolom['pembimbinglapangan']==""){
        $namaPemlap="Tidak Ada";
    }else{
        $seleksiRowPemlap = mysqli_query($connection, "SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$pembimbinglapangan."'");
        $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiRowPemlap);
        $namaPemlap = $seleksiKolomPemlap['nama'];
    }


    //untuk track record
    $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$_SESSION['datamhs']."'");
    $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
    $statusMagang = $seleksiKolomStatus['id_status']; 
    
    //untuk track record 3 yang bagian jam magang terselesaikan 
    $seleksiRowJamMagang = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$_SESSION['datamhs']."'");
    $seleksiKolomJamMagang = mysqli_fetch_assoc($seleksiRowJamMagang);
    $detikJamMagang = $seleksiKolomJamMagang['jam_magang'];
    $jamJamMagang = floor($detikJamMagang/3600);

    $judulKeterangan1 = "Menunggu Surat TU"; 
    $isiKeterangan1 = "Mahasiswa ini sudah menemukan calon instansi dan masih menunggu surat pengantar dari TU sebagai awal dari proses KP nya." ;
        
    $judulKeterangan2 = "Pengajuan Ke Instansi";
    $isiKeterangan2 = "Mahasiswa ini sedang dalam proses mengajukan permintaan magang di calon instansi." ;
    
    $judulKeterangan3 = "Masa Magang";
    $isiKeterangan3 = "Mahasiswa ini sedang menjalani proses magang di instansi tempatnya magang.<br><br>Jam Magang Terselesaikan : $jamJamMagang / 400 Jam";
        
    $judulKeterangan4 = "Laporan Magang";
    $isiKeterangan4 = "Mahasiswa telah menyelesaikan jam magangnya dan sedang dalam proses mengerjakan laporan kerja praktek."; 
    
    $judulKeterangan5 = "Selesai";
    $isiKeterangan5 = "Mahasiswa ini telah menyelesaikan seluruh proses KP"; 
    
    if($statusMagang == 1){
        
        //utk timestamp, kolom timestamp adalah timestamp terakhir
        $timestamp1 = $seleksiKolomStatus['timestamp'];
        $arrayTimestamp1 = explode(" ", "$timestamp1");
        
        $tanggal1 = ($arrayTimestamp1[0]);
        $jam1 = ($arrayTimestamp1[1]);
        $tanggal2 = "";
        $jam2 = "Belum Ditempuh";
        $tanggal3 = "";
        $jam3 = "Belum Ditempuh";
        $tanggal4 = "";
        $jam4 = "Belum Ditempuh";
        $tanggal5 = "";
        $jam5 = "Belum Ditempuh"; ?>
        <script>
	        $(document).ready(function(){

                $("#box1").css('display','block');
                $("#box2").css('display','none');
                $("#box3").css('display','none');
                $("#box4").css('display','none');
                $("#box5").css('display','none');
            });
        </script>
        <?php
    }else if($statusMagang == 2){
        
        //utk timestamp
        $timestamp1 = $seleksiKolomStatus['time1'];
        $arrayTimestamp1 = explode(" ", "$timestamp1");
        $timestamp2 = $seleksiKolomStatus['timestamp'];
        $arrayTimestamp2 = explode(" ", "$timestamp2");
        

        $tanggal1 = ($arrayTimestamp1[0]);
        $jam1 = ($arrayTimestamp1[1]);
        $tanggal2 = ($arrayTimestamp2[0]);
        $jam2 = ($arrayTimestamp2[1]);
        $tanggal3 = "";
        $jam3 = "Belum Ditempuh";
        $tanggal4 = "";
        $jam4 = "Belum Ditempuh";
        $tanggal5 = "";
        $jam5 = "Belum Ditempuh"; 
        ?>
        <script>
            $(document).ready(function(){
                $(".tombol-bulat").css('font-size','1.5em');
                $("#tombol2").css('font-size','1.7em');
                $("#tombol2").css('background-color','rgb(114, 124, 245)');
                $("#tombol3").css('background-color','rgb(114, 124, 245,0.5)');
                $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
                $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
                $("#line1").css('stroke','rgb(114, 124, 245)');
                $("#line2").css('stroke','rgb(114, 124, 245,0.5)');
                $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
                $("#line4").css('stroke','rgb(114, 124, 245,0.5)');

                $("#box1").css('display','none');
                $("#box2").css('display','block');
                $("#box3").css('display','none');
                $("#box4").css('display','none');
                $("#box5").css('display','none');
            });
        </script><?php
    }else if($statusMagang == 3){
        //utk timestamp
        $timestamp1 = $seleksiKolomStatus['time1'];
        $arrayTimestamp1 = explode(" ", "$timestamp1");
        $timestamp2 = $seleksiKolomStatus['time2'];
        $arrayTimestamp2 = explode(" ", "$timestamp2");
        $timestamp3 = $seleksiKolomStatus['timestamp'];
        $arrayTimestamp3 = explode(" ", "$timestamp3");


        $tanggal1 = ($arrayTimestamp1[0]);
        $jam1 = ($arrayTimestamp1[1]);
        $tanggal2 = ($arrayTimestamp2[0]);
        $jam2 = ($arrayTimestamp2[1]);
        $tanggal3 = ($arrayTimestamp3[0]);
        $jam3 = ($arrayTimestamp3[1]);
        $tanggal4 = "";
        $jam4 = "Belum Ditempuh";
        $tanggal5 = "";
        $jam5 = "Belum Ditempuh";
        ?>
        <script>
            $(document).ready(function(){
                $(".tombol-bulat").css('font-size','1.5em');
                $("#tombol3").css('font-size','1.7em');
                $("#tombol2").css('background-color','rgb(114, 124, 245)');
                $("#tombol3").css('background-color','rgb(114, 124, 245)');
                $("#tombol4").css('background-color','rgb(114, 124, 245,0.5)');
                $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
                $("#line1").css('stroke','rgb(114, 124, 245)');
                $("#line2").css('stroke','rgb(114, 124, 245)');
                $("#line3").css('stroke','rgb(114, 124, 245,0.5)');
                $("#line4").css('stroke','rgb(114, 124, 245,0.5)');

                $("#box1").css('display','none');
                $("#box2").css('display','none');
                $("#box3").css('display','block');
                $("#box4").css('display','none');
                $("#box5").css('display','none');
            });
        </script><?php
    }else if($statusMagang == 4){
        //utk timestamp
        $timestamp1 = $seleksiKolomStatus['time1'];
        $arrayTimestamp1 = explode(" ", "$timestamp1");
        $timestamp2 = $seleksiKolomStatus['time2'];
        $arrayTimestamp2 = explode(" ", "$timestamp2");
        $timestamp3 = $seleksiKolomStatus['time3'];
        $arrayTimestamp3 = explode(" ", "$timestamp3");
        $timestamp4 = $seleksiKolomStatus['timestamp'];
        $arrayTimestamp4 = explode(" ", "$timestamp4");


        $tanggal1 = ($arrayTimestamp1[0]);
        $jam1 = ($arrayTimestamp1[1]);
        $tanggal2 = ($arrayTimestamp2[0]);
        $jam2 = ($arrayTimestamp2[1]);
        $tanggal3 = ($arrayTimestamp3[0]);
        $jam3 = ($arrayTimestamp3[1]);
        $tanggal4 = ($arrayTimestamp4[0]);
        $jam4 = ($arrayTimestamp4[1]);
        $tanggal5 = "";
        $jam5 = "Belum Ditempuh";

        ?>
        <script>
            $(document).ready(function(){
                $(".tombol-bulat").css('font-size','1.5em');
                $("#tombol4").css('font-size','1.7em');
                $("#tombol2").css('background-color','rgb(114, 124, 245)');
                $("#tombol3").css('background-color','rgb(114, 124, 245)');
                $("#tombol4").css('background-color','rgb(114, 124, 245)');
                $("#tombol5").css('background-color','rgb(114, 124, 245,0.5)');
                $("#line1").css('stroke','rgb(114, 124, 245)');
                $("#line2").css('stroke','rgb(114, 124, 245)');
                $("#line3").css('stroke','rgb(114, 124, 245)');
                $("#line4").css('stroke','rgb(114, 124, 245,0.5)');

                $("#box1").css('display','none');
                $("#box2").css('display','none');
                $("#box3").css('display','none');
                $("#box4").css('display','block');
                $("#box5").css('display','none');
            });
        </script><?php    
    }else if($statusMagang == 5){
        //utk timestamp
        $timestamp1 = $seleksiKolomStatus['time1'];
        $arrayTimestamp1 = explode(" ", "$timestamp1");
        $timestamp2 = $seleksiKolomStatus['time2'];
        $arrayTimestamp2 = explode(" ", "$timestamp2");
        $timestamp3 = $seleksiKolomStatus['time3'];
        $arrayTimestamp3 = explode(" ", "$timestamp3");
        $timestamp4 = $seleksiKolomStatus['time4'];
        $arrayTimestamp4 = explode(" ", "$timestamp4");
        $timestamp5 = $seleksiKolomStatus['timestamp'];
        $arrayTimestamp5 = explode(" ", "$timestamp5");


        $tanggal1 = ($arrayTimestamp1[0]);
        $jam1 = ($arrayTimestamp1[1]);
        $tanggal2 = ($arrayTimestamp2[0]);
        $jam2 = ($arrayTimestamp2[1]);
        $tanggal3 = ($arrayTimestamp3[0]);
        $jam3 = ($arrayTimestamp3[1]);
        $tanggal4 = ($arrayTimestamp4[0]);
        $jam4 = ($arrayTimestamp4[1]);
        $tanggal5 = ($arrayTimestamp5[0]);
        $jam5 = ($arrayTimestamp5[1]);
        

        ?>
        <script>
            $(document).ready(function(){
                $(".tombol-bulat").css('font-size','1.5em');
                $("#tombol5").css('font-size','1.7em');
                $("#tombol2").css('background-color','rgb(114, 124, 245)');
                $("#tombol3").css('background-color','rgb(114, 124, 245)');
                $("#tombol4").css('background-color','rgb(114, 124, 245)');
                $("#tombol5").css('background-color','rgb(114, 124, 245)');
                $("#line1").css('stroke','rgb(114, 124, 245)');
                $("#line2").css('stroke','rgb(114, 124, 245)');
                $("#line3").css('stroke','rgb(114, 124, 245)');
                $("#line4").css('stroke','rgb(114, 124, 245)');

                $("#box1").css('display','none');
                $("#box2").css('display','none');
                $("#box3").css('display','none');
                $("#box4").css('display','none');
                $("#box5").css('display','block');
            });
        </script><?php
    }


    // untuk detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$id_utama." ");

    //untuk progress bar
    $seleksiRowJamMagang = mysqli_query($connection,"SELECT * FROM mahasiswa");
    foreach($seleksiRowJamMagang as $row){
        if($row['id_utama'] == $id_utama){
            $detikJamMagang = $row['jam_magang'];
            $jamJamMagang = floor($detikJamMagang/3600);
            $persentase = $jamJamMagang / 200 * 100 ; 
            if($persentase > 100){
                $persentase = 100 ;
            }
        }
    }
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/detil_mahasiswa/detil_mahasiswa.css">
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
	<!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
    <div class = "container">
        <h1><b><p style="margin-top:3em;margin-bottom:0em;">Biodata Mahasiswa</p></b></h1>
        <table>
            <tr>
                <td style="padding-right: 170px;">Nama</td>
                <td style="padding-right: 10px;">:</td>
                <td><?php echo $nama?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>:</td>
                <td><?php echo $email?></a></td>
            </tr>
            <tr>
                <td>No Whatsapp</td>
                <td>:</td>
                <td><?php echo $nowa?></td>
            </tr>
            <tr>
                <td>NRP</td>
                <td>:</td>
                <td><?php echo $nrp?></td>
            </tr>
            <tr>
                <td>Instansi</td>
                <td>:</td>
                <td><?php echo $namaInstansi?></td>
            </tr>
            <tr>
                <td>Nama Dosen Pembimbing</td>
                <td>:</td>
                <td><?php echo $namaDosbing?></td>
            </tr>   
            <tr>
                <td>Nama Pembimbing Lapangan</td>
                <td>:</td>
                <td>
                    <?php echo $namaPemlap;?>
                </td>
            </tr>
        </table>
    </div>
    <div class = "container tempat-timeline">
        <table class = "table">
            <tr>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol1" style="font-size:1.7em; background-color : rgb(114, 124, 245);">1</button>
                   
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%" height = "100px">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line1">
                    </svg>
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol2">2</button>
                    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%" height = "20px">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line2">
                    </svg>    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol3">3</button>
                    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%" height = "20px">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line3">
                    </svg>
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol4">4</button>
                    
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "garis mepet">
                    <svg width = "100%" height = "20px">
                        <line x1="0" y1="20" x2="100%" y2="20" id = "line4">
                    </svg>
                </td>
                <td style = "border-top: 0px solid #dee2e6;" class = "bulat mepet">
                    
                    <button class = "tombol-bulat" id="tombol5">5</button>
                    
                </td>
            </tr>
        </table>


        <div id = "box1" class = "box-keterangan" style = "display : block ;">
            <h4 class = "judul-keterangan"><?php echo $judulKeterangan1 ?></h4>
            <div class = "kontener-keterangan">
                <p class = "isi-keterangan"><?php echo $isiKeterangan1 ?></p>
            </div>    
            <div class = "kontener-waktu">
                <a><?php echo $jam1 ?><br><?php echo $tanggal1 ?></a>
            </div>
        </div>

        <div id = "box2" class = "box-keterangan" style = "display : none ;">
            <h4 class = "judul-keterangan"><?php echo $judulKeterangan2 ?></h4>
            <div class = "kontener-keterangan">
                <p class = "isi-keterangan"><?php echo $isiKeterangan2 ?></p>
            </div>    
            <div class = "kontener-waktu">
                <a><?php echo $jam2 ?><br><?php echo $tanggal2 ?></a>
            </div>
        </div>

        <div id = "box3" class = "box-keterangan" style = "display : none ;">
            <h4 class = "judul-keterangan"><?php echo $judulKeterangan3 ?></h4>
            <div class = "kontener-keterangan">
                <p class = "isi-keterangan"><?php echo $isiKeterangan3 ?></p>
            </div>    
            <div class = "kontener-waktu">
                <a><?php echo $jam3 ?><br><?php echo $tanggal3 ?></a>
            </div>
        </div>

        <div id = "box4" class = "box-keterangan" style = "display : none ;">
            <h4 class = "judul-keterangan"><?php echo $judulKeterangan4 ?></h4>
            <div class = "kontener-keterangan">
                <p class = "isi-keterangan"><?php echo $isiKeterangan4 ?></p>
            </div>    
            <div class = "kontener-waktu">
                <a><?php echo $jam4 ?><br><?php echo $tanggal4 ?></a>
            </div>
        </div>

        <div id = "box5" class = "box-keterangan" style = "display : none ;">
            <h4 class = "judul-keterangan"><?php echo $judulKeterangan5 ?></h4>
            <div class = "kontener-keterangan">
                <p class = "isi-keterangan"><?php echo $isiKeterangan5 ?></p>
            </div>    
            <div class = "kontener-waktu">
                <a><?php echo $jam5 ?><br><?php echo $tanggal5 ?></a>
            </div>
        </div>

         <!-- progress bar -->
        <div class = "box-keterangan" style="overflow-wrap:break-word;margin-top : 5em ;">  
            <h5><b><p style = "text-align:center;">Proses Magang Mahasiswa</p></b></h5>
            <div class="progress" style = "margin-top:3em;height:2.5em;text-align:center;">
                <span style = "position : absolute; right:0; left:0;"><h5><b><?php echo $persentase ?>%</b></h5></span>
                <div class="progress-bar" role="progressbar" style="width: <?php echo $persentase ?>%;" aria-valuenow="<?php echo $jamJamMagang ?>" aria-valuemin="0" aria-valuemax="200"></div>
            </div>
            <p>
                <h5 style = "color:rgba(67, 27, 100, 0.8);">Jam Magang Terselesaikan : <?php echo $jamJamMagang ?> / 200 Jam</h5>
            </p>
        </div>
    
    </div>

   

    <?php //tabel riwayat absensi
    if($statusMagang > 2 ){ ?>
        <div style = "text-align : center ;padding : 2em ;">
            <h3 style = "text-align:center;padding-top:2em;">Riwayat Absensi</h3>
            <table id="myTable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Jam Masuk</th>
                        <th>Jam Pulang</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody><?php
                    foreach($seleksiRowAbsen as $row){ ?>
                        <tr>
                            <form method = "POST" action = "detail_absen.php">
                                <td><?php echo $row['tanggal'] ?></td>
                                <td><?php echo $row['jam_masuk'] ?> </td>
                                <td><?php echo $row['jam_pulang'] ?></td>
                                <td><?php echo $row['status'] ?></td>
                                <td style="white-space : nowrap;">
                                    <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                    <input type="text" name="dataValue" value="<?php echo $row['id_absen'] ?>" style="display:none;">
                                    <input type="text" name="id_utama" value="<?php echo $id_utama ?>" style="display:none">
                                </td>
                            </form>
                        </tr><?php
                    } ?>
                </tbody>
            </table>
        </div><?php
    } ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script src="../../js/detil_mahasiswa/detil_mahasiswa.js"></script>
    <script>
        $(document).ready(function(){
            $('#myTable').dataTable();
        });
    </script>
</body>