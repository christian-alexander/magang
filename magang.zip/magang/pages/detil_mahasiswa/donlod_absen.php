<?php
//untuk download
if(isset($_POST['file'])){
    $filename = basename(($_POST['file']));
    $filepatch = '../../filepool/' . $filename;
    if(!empty($filename) && file_exists($filepatch)) {
        header("Cache-Control: public");
        header("Content-Description: FIle Trasfer");
        header("Content-disposition: attachment; filename=$filename");
        header("Content-Type: application/zip");
        header("Content-Tranfer-Encoding:binary");

        readfile($filepatch);
        exit;
    }
}
?>