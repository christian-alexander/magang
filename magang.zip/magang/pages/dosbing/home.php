<?php
    session_start();
    include('../../connection/connection.php');
    
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 2){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
    //untuk tabel boi//
    $seleksiTabelMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa");
    $banyakRowMahasiswa = mysqli_num_rows($seleksiTabelMahasiswa);
    $daftarMahasiswa = array();
    for ($baris = 1 ; $baris <= $banyakRowMahasiswa ; $baris++){
        $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id = $baris");
        $seleksiKolomMahasiswa = mysqli_fetch_assoc($seleksiRowMahasiswa);
        $id_utama = $seleksiKolomMahasiswa['id_utama'];
        $nama = $seleksiKolomMahasiswa['nama'];
        
        $nrp = $seleksiKolomMahasiswa['nrp'];
        
        $idInstansi = $seleksiKolomMahasiswa['instansi'];
        $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$idInstansi."'");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $instansi = $seleksiKolomInstansi['nama'];
        
        $nowa = $seleksiKolomMahasiswa['nowa'];
        $email = $seleksiKolomMahasiswa['email'];
        
        $idDosenPembimbing = $seleksiKolomMahasiswa['dosenpembimbing'];

        $seleksiRowDosenPembimbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$idDosenPembimbing."'");
        $seleksiKolomDosenPembimbing = mysqli_fetch_assoc($seleksiRowDosenPembimbing);
        $dosenpembimbing = $seleksiKolomDosenPembimbing['nama'];
        

        $idPembimbingLapangan = $seleksiKolomMahasiswa['pembimbinglapangan'];
        if($idPembimbingLapangan==""){
            $pembimbinglapangan="Tidak Ada";
        }else{
            $seleksiRowPembimbingLapangan = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$idPembimbingLapangan."'");
            $seleksiKolomPembimbingLapangan = mysqli_fetch_assoc($seleksiRowPembimbingLapangan);
            $pembimbinglapangan = $seleksiKolomPembimbingLapangan['nama'];
        }
        

        $seleksiRowStatusAkun = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama ='".$id_utama."'");
        $seleksiKolomStatusAkun = mysqli_fetch_assoc($seleksiRowStatusAkun);
        $statusAkun = $seleksiKolomStatusAkun['status'];

        
        $seleksiRowStatusMagang = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$id_utama."'");
        $seleksiKolomStatusMagang = mysqli_fetch_assoc($seleksiRowStatusMagang);
        $tanggalStart = $seleksiKolomStatusMagang['time1'];
        $arrayTanggal = explode(" ",$tanggalStart);
        $tanggalAwal = $arrayTanggal[0];
        $timeTanggalAwal = strtotime($tanggalAwal);
        $today = strtotime(date("Y-m-d"));
        $rentangHari = ($today - $timeTanggalAwal)/(24*60*60) ;


        if($idDosenPembimbing == $loggedUser && $statusAkun == "on"){
            $detilMahasiswa = array($id_utama,$nama,$nrp,$instansi,$nowa,$email,$dosenpembimbing,$pembimbinglapangan,$rentangHari);
            array_push($daftarMahasiswa,$detilMahasiswa);
        }
    }

    
    //untuk mhs selesai dibimbing
    $seleksiMhsBerhasil = mysqli_query($connection,"SELECT * FROM status_magang");

?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
	<!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
					</li>       
                </ul>
            </div>
        </div>
    </nav>
    
    <div style = "text-align : center ; padding : 2em ;">
        <h3><p style="margin-top:2em;margin-bottom:1em;">Mahasiswa Dalam Bimbingan</p></h3>
        <table id="myTable" class="table table-striped">  
            <thead>  
                <tr>  
                    <th>Nama</th>
                    <th>NRP</th>
                    <th>Instansi</th>
                    <th>Dosen Pembimbing</th>
                    <th>Pembimbing Lapangan</th>
                    <th>Lama Magang</th>
                    <th>Detail</th>
                </tr>  
            </thead>  
            <tbody><?php
                for($baris = 0; $baris <count($daftarMahasiswa); $baris++){
                    if($daftarMahasiswa[$baris][8] > 335){ //bila udah kurang 1 bulan waktu magangnya?>
                        <tr class="highlight" style="background-color:rgb(219, 141, 141);">
                            <form method = "POST" action = "nav_detil_mahasiswa.php">
                                <td><?php echo $daftarMahasiswa[$baris][1]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][2]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][3]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][6]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][7]?></td>
                                <td><?php echo floor($daftarMahasiswa[$baris][8]/30)?> Bulan</td>
                                <td style="white-space : nowrap;">
                                    <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                    <input type="text" name="dataValue" value="<?php echo $daftarMahasiswa[$baris][0] ?>" style="display:none;">
                                </td>
                            </form>
                        </tr><?php
                    }else if($daftarMahasiswa[$baris][8] > 255){ //bila udah kurang 3 bulan waktu magangnya?>
                        <tr class="highlight" style="background-color:rgb(235, 223, 114);">
                            <form method = "POST" action = "nav_detil_mahasiswa.php">
                                <td><?php echo $daftarMahasiswa[$baris][1]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][2]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][3]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][6]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][7]?></td>
                                <td><?php echo floor($daftarMahasiswa[$baris][8]/30)?> Bulan</td>
                                <td style="white-space : nowrap;">
                                    <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                    <input type="text" name="dataValue" value="<?php echo $daftarMahasiswa[$baris][0] ?>" style="display:none;">
                                </td>
                            </form>
                        </tr><?php
                    }else{ ?>
                        <tr class="highlight">
                            <form method = "POST" action = "nav_detil_mahasiswa.php">
                                <td><?php echo $daftarMahasiswa[$baris][1]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][2]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][3]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][6]?></td>
                                <td><?php echo $daftarMahasiswa[$baris][7]?></td>
                                <td><?php echo floor($daftarMahasiswa[$baris][8]/30)?> Bulan</td>
                                <td style="white-space : nowrap;">
                                    <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                    <input type="text" name="dataValue" value="<?php echo $daftarMahasiswa[$baris][0] ?>" style="display:none;">
                                </td>
                            </form>
                        </tr><?php
                    }
                }?>
            </tbody>  
        </table>  


        <!-- tabel selesai dibimbing -->
        <h3><p style="margin-top:2em;margin-bottom:1em;">Mahasiswa Selesai KP</p></h3>
        <table id="myTable2" class="table table-striped">  
            <thead>  
                <tr>  
                    <th>Nama</th>
                    <th>NRP</th>
                    <th>Instansi</th>
                    <th>Dosen Pembimbing</th>
                    <th>Pembimbing Lapangan</th>
                    <th>Detail</th>
                </tr>  
            </thead>  
            <tbody><?php
                foreach($seleksiMhsBerhasil as $row){
                    if($row['id_status'] == 5){
                        $seleksiDataMhsBerhasil = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$row['id_utama']."'");
                        foreach($seleksiDataMhsBerhasil as $rowData){
                            if($rowData['dosenpembimbing'] == $loggedUser){ ?>
                                <tr class="highlight" id = "clickable-row<?php echo $baris ?>">
                                    <form method = "POST" action = "nav_detil_mahasiswa.php">
                                        <td><?php echo $rowData['nama']?></td>
                                        <td><?php echo $rowData['nrp']?></td><?php 
                                        //untuk ambil nama instansi
                                        $seleksiInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$rowData['instansi']."'");
                                        foreach($seleksiInstansi as $rowInstansi){?>
                                            <td><?php echo $rowInstansi['nama']?></td><?php
                                        }
                                        //untuk ambil nama dosbing
                                        $seleksiDosbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$rowData['dosenpembimbing']."'");
                                        foreach($seleksiDosbing as $rowDosbing){ ?>
                                            <td><?php echo $rowDosbing['nama']?></td><?php
                                        }
                                        //untuk ambil nama pembimbing lapangan
                                        $seleksiPemlap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$rowData['pembimbinglapangan']."'");
                                        foreach($seleksiPemlap as $rowPemlap){ ?>
                                            <td><?php echo $rowPemlap['nama']?></td><?php
                                        } ?>
                                        <td style="white-space : nowrap;">
                                            <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                            <input type="text" name="dataValue" value="<?php echo $rowData['id_utama'] ?>" style="display:none;">
                                        </td>
                                    </form>
                                </tr><?php
                            }
                        }
                    }
                }?>
            </tbody>  
        </table>
    </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#myTable').dataTable();
            $('#myTable2').dataTable();
        });

    </script>

</body>