<?php
    session_start();
    include('../../connection/connection.php');
    
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 2){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
     
    
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
	<!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
					</li>       
                </ul>
            </div>
        </div>
    </nav>
    
    <div style = "text-align : center ; padding : 2em ;">
        <h3><p style="margin-top:2em;margin-bottom:1em;">Laporan Belum Dinilai</p></h3>
        <table id="myTable" class="table table-striped fl-table">  
            <thead>  
                <tr>  
                    <th>Nama Mahasiswa</th>
                    <th>Judul Laporan</th>
                    <th>Instansi</th>
                    <th>Dosen Pembimbing</th>
                    <th>Pembimbing Lapangan</th>
                    <th>Detail</th>
                </tr>  
            </thead>  
            <tbody><?php
                $keluarkanData = FALSE ;
                $seleksiMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE dosenpembimbing = '".$loggedUser."'");
                foreach($seleksiMahasiswa as $rowMahasiswa){ 
                    $seleksiDataLaporan = mysqli_query($connection,"SELECT * FROM data_laporan WHERE id_utama = '".$rowMahasiswa['id_utama']."'");
                    foreach($seleksiDataLaporan as $rowData){ 
                        $seleksiFileLaporan = mysqli_query($connection,"SELECT * FROM file_laporan"); 
                        foreach($seleksiFileLaporan as $rowFile){
                            if($rowFile['id_utama'] == $rowMahasiswa['id_utama'] and $rowFile['status'] == 'on' and $rowData['nilai_dosbing'] == 0){ 
                                $keluarkanData = TRUE ;
                                break;
                            }
                        }if($keluarkanData){ ?>
                            <tr>
                                <td><?php echo $rowMahasiswa['nama'] ?></td>
                                <td><?php echo $rowData['judul_laporan'] ?></td>

                                <?php 
                                    $seleksiInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$rowMahasiswa['instansi']."'");
                                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiInstansi);
                                    $namaInstansi = $seleksiKolomInstansi['nama'];
                                ?>
                                <td><?php echo $namaInstansi ?></td>

                                <?php
                                    $seleksiDosbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$rowMahasiswa['dosenpembimbing']."'");
                                    $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiDosbing);
                                    $namaDosbing = $seleksiKolomDosbing['nama'];
                                ?>
                                <td><?php echo $namaDosbing ?></td>

                                <?php
                                    $seleksiPemlap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$rowMahasiswa['pembimbinglapangan']."'");
                                    $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiPemlap);
                                    $namaPemlap = $seleksiKolomPemlap['nama'];
                                ?>
                                <td><?php echo $namaPemlap ?></td>
                                <td>
                                    <form method = "POST" action="lihat_laporan.php">
                                        <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                        <input type="text" name="id_utama" value="<?php echo $rowMahasiswa['id_utama'] ?>" style="display:none;">
                                        <input type="text" name="judul_laporan" value="<?php echo $rowData['judul_laporan'] ?>" style="display:none;">
                                    	<input type="text" name="nama_mahasiswa" value="<?php echo $rowMahasiswa['nama'] ?>" style="display:none;">
                                    
                                    </form>
                                </td>
                            </tr><?php
                        
                        }
                    }
                } ?>
            </tbody>  
        </table>  


        <!-- tabel laporan slesai dinilai -->
        <h3><p style="margin-top:2em;margin-bottom:1em;">Laporan Sudah Dinilai</p></h3>
        <table id="myTable2" class="table table-striped fl-table">  
            <thead>  
                <tr>  
                    <th>Nama Mahasiswa</th>
                    <th>Judul Laporan</th>
                    <th>Instansi</th>
                    <th>Dosen Pembimbing</th>
                    <th>Pembimbing Lapangan</th>
                    <th>Detail</th>
                </tr>  
            </thead>  
            <tbody><?php
                $seleksiMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE dosenpembimbing = '".$loggedUser."'");
                foreach($seleksiMahasiswa as $rowMahasiswa){ 
                    $seleksiDataLaporan = mysqli_query($connection,"SELECT * FROM data_laporan WHERE id_utama = '".$rowMahasiswa['id_utama']."'");
                    foreach($seleksiDataLaporan as $rowData){ 
                        $seleksiFileLaporan = mysqli_query($connection,"SELECT * FROM file_laporan"); 
                        foreach($seleksiFileLaporan as $rowFile){
                            $keluarkanData = FALSE ;
                            if($rowFile['id_utama'] == $rowMahasiswa['id_utama'] and $rowFile['status'] == 'on' and $rowData['nilai_dosbing'] != 0 and $rowData['nilai_pemlap'] != 0){ 
                                $keluarkanData = TRUE ;
                                break;
                            }
                        }if($keluarkanData){ ?>
                            <tr>
                                <td><?php echo $rowMahasiswa['nama'] ?></td>
                                <td><?php echo $rowData['judul_laporan'] ?></td>

                                <?php 
                                    $seleksiInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$rowMahasiswa['instansi']."'");
                                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiInstansi);
                                    $namaInstansi = $seleksiKolomInstansi['nama'];
                                ?>
                                <td><?php echo $namaInstansi ?></td>

                                <?php
                                    $seleksiDosbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$rowMahasiswa['dosenpembimbing']."'");
                                    $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiDosbing);
                                    $namaDosbing = $seleksiKolomDosbing['nama'];
                                ?>
                                <td><?php echo $namaDosbing ?></td>

                                <?php
                                    $seleksiPemlap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$rowMahasiswa['pembimbinglapangan']."'");
                                    $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiPemlap);
                                    $namaPemlap = $seleksiKolomPemlap['nama'];
                                ?>
                                <td><?php echo $namaPemlap ?></td>
                                <td>    
                                    <form method = "POST" action="lihat_laporan.php">
                                        <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                        <input type="text" name="id_utama" value="<?php echo $rowMahasiswa['id_utama'] ?>" style="display:none;">
                                        <input type="text" name="judul_laporan" value="<?php echo $rowData['judul_laporan'] ?>" style="display:none;">
                                    	<input type="text" name="nama_mahasiswa" value="<?php echo $rowMahasiswa['nama'] ?>" style="display:none;">
                                    </form>
                                </td>
                            </tr><?php
                        
                        }
                    }
                } ?>
            </tbody>  
        </table>  


    </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#myTable').dataTable();
            $('#myTable2').dataTable();
        });

    </script>

</body>