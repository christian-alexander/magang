<?php 
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 2){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
    $_SESSION['datamhs'] = $_POST['dataValue'];
    $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$_POST['dataValue']."'");
    $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
    $idStatus = $seleksiKolomStatus['id_status'];
    if($idStatus < 5){
        $idStatusBerikutnya = $idStatus + 1 ;
        $seleksiRowIdStatus = mysqli_query($connection,"SELECT * FROM nama_status_magang WHERE id_status = '".$idStatusBerikutnya."'");
        $seleksiKolomIdStatus = mysqli_fetch_assoc($seleksiRowIdStatus);
        $statusBerikutnya = $seleksiKolomIdStatus['nama'];
    }
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <iframe scrolling = "no" src = "../detil_mahasiswa/detil_mahasiswa.php" style = "width:100%;height:1000px;"></iframe>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>