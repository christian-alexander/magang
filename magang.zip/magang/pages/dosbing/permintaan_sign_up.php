<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 2){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }

    //untuk daftar permintaan//
    $seleksiTabelPermintaan = mysqli_query($connection,"SELECT * FROM sign_up_akun");
    $banyakRowPermintaan = mysqli_num_rows($seleksiTabelPermintaan);
    $daftarPermintaan = array();
    for ($baris = 1 ; $baris <= $banyakRowPermintaan ; $baris++){
        $seleksiRowPermintaan = mysqli_query($connection,"SELECT * FROM sign_up_akun WHERE id = $baris");
        $seleksiKolomPermintaan = mysqli_fetch_assoc($seleksiRowPermintaan);
        $status = $seleksiKolomPermintaan['status'];
        if($status == "on"){
            $id = $seleksiKolomPermintaan['id'];
            $nama = $seleksiKolomPermintaan['nama'];
            
            $nrpValue = $seleksiKolomPermintaan['nrp'];
            if($nrpValue == ""){
                $nrp = "-";
            }else{
                $nrp = $nrpValue;
            }
            
            $entitas = $seleksiKolomPermintaan['entitas'];
            
            $idInstansi = $seleksiKolomPermintaan['instansi'];
            $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$idInstansi."'");
            $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
            $instansi = $seleksiKolomInstansi['nama'];
            
            $nowa = $seleksiKolomPermintaan['nowa'];
            $email = $seleksiKolomPermintaan['email'];
            
            $idDosenPembimbing = $seleksiKolomPermintaan['dosenpembimbing'];
			if($entitas == 3){
                $dosenpembimbing = "-";
            }else{
                $seleksiRowDosenPembimbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$idDosenPembimbing."'");
                $seleksiKolomDosenPembimbing = mysqli_fetch_assoc($seleksiRowDosenPembimbing);
                $dosenpembimbing = $seleksiKolomDosenPembimbing['nama'];
            }

            $idPembimbingLapangan = $seleksiKolomPermintaan['pembimbinglapangan'];
            if($entitas == 3){
				$pembimbinglapangan = "-";
        	}else if($idPembimbingLapangan == ""){
                $pembimbinglapangan = "Belum Ada";
            }else{
                $seleksiRowPembimbingLapangan = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$idPembimbingLapangan."'");
                $seleksiKolomPembimbingLapangan = mysqli_fetch_assoc($seleksiRowPembimbingLapangan);
                $pembimbinglapangan = $seleksiKolomPembimbingLapangan['nama'];
            }
            
            if($idDosenPembimbing == $loggedUser or $entitas == 3){
                $detilPermintaan = array($id,$nama,$nrp,$entitas,$instansi,$nowa,$email,$dosenpembimbing,$pembimbinglapangan);
                array_push($daftarPermintaan,$detilPermintaan);
            }
        }
    }
    
    //utk tabel permintaan instansi
    $seleksiTabelPermintaanInstansi = mysqli_query($connection,"SELECT * FROM sign_up_instansi");
    $banyakRowPermintaanInstansi = mysqli_num_rows($seleksiTabelPermintaanInstansi);
    $daftarPermintaanInstansi = array();
    for($baris = 1 ; $baris <= $banyakRowPermintaanInstansi ; $baris++){
        $seleksiRowPermintaanInstansi = mysqli_query($connection,"SELECT * FROM sign_up_instansi WHERE id = $baris");
        $seleksiKolomPermintaanInstansi = mysqli_fetch_assoc($seleksiRowPermintaanInstansi);
        $status = $seleksiKolomPermintaanInstansi['status'];
        if($status == "on"){
            $id = $baris ;
            $namaInstansi = $seleksiKolomPermintaanInstansi['nama'];
            $notelpInstansi = $seleksiKolomPermintaanInstansi['notelp'];
            $nofaxInstansi = $seleksiKolomPermintaanInstansi['nofax'];
            $emailInstansi = $seleksiKolomPermintaanInstansi['email'];
            $alamatInstansi = $seleksiKolomPermintaanInstansi['alamat'];
            $detilInstansi = array($id,$namaInstansi,$notelpInstansi,$nofaxInstansi,$emailInstansi,$alamatInstansi);
            array_push($daftarPermintaanInstansi,$detilInstansi);
        }
    }
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../../css/dosbing/permintaan_sign_up.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
	<br>
    <div class = "div-tabel">
        <h3><p style="margin-top:2em;margin-bottom:1em;">Permintaan Sign Up Akun</p></h3>
        <table id="myTable" class="table table-striped">  
            <thead>  
                <tr>  
                    <th>Nama</th>
                    <th>NRP / NIP</th>
                    <th>Peran</th>
                    <th>Instansi</th>
                    <th>No WhatsApp</th>
                    <th>Email</th>
                    <th>Dosen Pembimbing</th>
                    <th>Pembimbing Lapangan</th>
                    <th>Aksi</th>
                </tr>  
            </thead>  
            <tbody><?php
                for($baris=0; $baris < count($daftarPermintaan) ; $baris++){ ?>
                    <tr>
                        <td><?php echo $daftarPermintaan[$baris][1] ?></td>
                        <td><?php echo $daftarPermintaan[$baris][2] ?></td><?php
                        if($daftarPermintaan[$baris][3] == 3){$peran = "Pembimbing Lapangan";}
                        else if($daftarPermintaan[$baris][3] == 4){$peran = "Mahasiswa";} ?>
                        <td><?php echo  $peran ?></td>
                        <td><?php echo $daftarPermintaan[$baris][4] ?></td>
                        <td><?php echo $daftarPermintaan[$baris][5] ?></td>
                        <td><a data-toggle ="tooltip" title="<?php echo $daftarPermintaan[$baris][6] ?>"><?php echo $daftarPermintaan[$baris][6] ?></a></td>
                        <td><?php echo $daftarPermintaan[$baris][7] ?></td>
                        <td><?php echo $daftarPermintaan[$baris][8] ?></td>
                        <td style="white-space:nowrap">
                        	<form class="tombol" method="POST" action="../../process/signup/signup_akun_acc_utk_dosbing.php" onsubmit ="return getIdentitasAccept<?php echo $daftarPermintaan[$baris][0] ?>()">
                            	<span><a href="#" class="done" title="Setujui" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">done</i></button></a></span> 
                                <input type="text" id="dataAcceptValue<?php echo $daftarPermintaan[$baris][0] ?>" name="dataAcceptValue" value="" style="display:none;">
                                <script>
                                    function getIdentitasAccept<?php echo $daftarPermintaan[$baris][0] ?>(){
                                        if (confirm("Yakin terima permintaan akun <?php echo $daftarPermintaan[$baris][1]?> ?")){
                                            var dataAcceptValue<?php echo $daftarPermintaan[$baris][0] ?> = document.getElementById("dataAcceptValue<?php echo $daftarPermintaan[$baris][0] ?>");
                                            dataAcceptValue<?php echo $daftarPermintaan[$baris][0] ?>.value = "<?php echo $daftarPermintaan[$baris][0] ?>";
                                            return true;
                                        }else{
                                            return false;
                                        }
                                    }
                                </script>
                            </form>
                            <form class="tombol" method="POST" action="../../process/signup/signup_akun_decline_utk_dosbing.php" onsubmit ="return getIdentitasDecline<?php echo $daftarPermintaan[$baris][0] ?>()">
                                <span><a href="#" class="block" title="Tolak" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">block</i></button></a></span> 
                                <input type="text" id="dataDeclineValue<?php echo $daftarPermintaan[$baris][0] ?>" name="dataDeclineValue" value="" style="display:none;">
                                <script>
                                        function getIdentitasDecline<?php echo $daftarPermintaan[$baris][0] ?>(){
                                            if (confirm("Yakin tolak permintaan akun <?php echo $daftarPermintaan[$baris][1]?> ?")){
                                                var dataDeclineValue<?php echo $daftarPermintaan[$baris][0] ?> = document.getElementById("dataDeclineValue<?php echo $daftarPermintaan[$baris][0] ?>");
                                                dataDeclineValue<?php echo $daftarPermintaan[$baris][0] ?>.value = "<?php echo $daftarPermintaan[$baris][0] ?>";
                                                return true;
                                            }else{
                                                return false;
                                            }
                                        }
                                </script>
                            </form>
                        </td>
                    </tr><?php
                } ?>
                </tr>
            </tbody>  
        </table>  
    </div>
    <div class = "div-tabel">
        <h3><p style="margin-top:2em;margin-bottom:1em;">Permintaan Sign Up Instansi</p></h3>
        <table id="myTable2" class="table table-striped" >  
            <thead>  
                <tr>  
                    <th>Nama Instansi</th>
                    <th>No Telepon</th>
                    <th>No Fax</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>  
            </thead>  
            <tbody><?php
            	for($baris = 0 ; $baris < count($daftarPermintaanInstansi) ; $baris++){?>
                    <tr>
                    	<td><?php echo $daftarPermintaanInstansi[$baris][1]?></td>
                        <td><?php echo $daftarPermintaanInstansi[$baris][2]?></td>
                        <td><?php echo $daftarPermintaanInstansi[$baris][3]?></td>
                        <td><?php echo $daftarPermintaanInstansi[$baris][4]?></td>
                        <td><?php echo $daftarPermintaanInstansi[$baris][5]?></td>
                        <td style="white-space : nowrap;">
                        	<form class="tombol" method="POST" action="../../process/signup/signup_instansi_acc_utk_dosbing.php" onsubmit ="return getIdentitasAcceptInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>()">
                            	<span><a href="#" class="done" title="Setujui" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">done</i></button></a></span> 
                                <input type="text" id="dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>" name="dataAcceptInstansiValue" value="" style="display:none;">
                                <script>
                                    function getIdentitasAcceptInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>(){
                                        if (confirm("Yakin terima permintaan instansi <?php echo $daftarPermintaanInstansi[$baris][1]?> ?")){
                                            var dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?> = document.getElementById("dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>");
                                            dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>.value = "<?php echo $daftarPermintaanInstansi[$baris][0] ?>";
                                            return true;
                                        }else{
                                            return false;
                                        }
                                    }
                                </script>
                            </form>
                            <form class="tombol" method="POST" action="../../process/signup/signup_instansi_decline_utk_dosbing.php" onsubmit ="return getIdentitasDeclineInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>()">
                                <span><a href="#" class="block" title="Tolak" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">block</i></button></a></span> 
                                <input type="text" id="dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>" name="dataDeclineInstansiValue" value="" style="display:none;">
                                <script>
                                        function getIdentitasDeclineInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>(){
                                            if (confirm("Yakin tolak permintaan instansi <?php echo $daftarPermintaanInstansi[$baris][1]?> ?")){
                                                var dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?> = document.getElementById("dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>");
                                                dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>.value = "<?php echo $daftarPermintaanInstansi[$baris][0] ?>";
                                                return true;
                                            }else{
                                                return false;
                                            }
                                        }
                                </script>
                            </form>
                        </td>
                    </tr><?php
                } ?>
            </tbody>  
        </table>  
        <br><br>
    </div>


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
        $('#myTable').dataTable();
    });
    	$(document).ready(function(){
        $('#myTable2').dataTable();
    });
    </script>
</body>