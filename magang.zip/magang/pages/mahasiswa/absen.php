<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk isi dari detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$loggedUser."");

    //untuk menentukan apa yg dilihat user, mengambil status
    $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
	$statusMahasiswa = $seleksiKolomStatus['id_status'];

    //utk memberitahu apakah si mhs sudah input pemlap atau belum
    $seleksiRowPemlap = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomPemlap = mysqli_fetch_assoc($seleksiRowPemlap);
    $idPemlap = $seleksiKolomPemlap['pembimbinglapangan'];

?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto"><?php
                    if($statusMahasiswa > 3 && $idPemlap != ""){ ?>
                        <li class="nav-item">
                            <a class ="btn btn-success" href="absen_baru.php">Absen Baru</a>
                        </li><?php
                    }?>
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <form method = "POST" action="akun.php" style="margin-block-end:0;">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun">Profil</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <?php 
    if($statusMahasiswa < 3){ ?>
        <div class = "container" id="noAccessContainer" style="padding-top:5em;">
            <div class = "box-keterangan">
                Anda belum punya akses untuk absen karena belum mendapatkan instansi magang.<br><br>Sudah diterima di instansi magang? minta TU untuk menaikkan status anda.
            </div>
        </div> <?php
    }else if($idPemlap == ""){ ?>
        <div class = "container" id="cantAbsenContainer" style="padding-top:5em;">
            <div class = "box-keterangan">
                Anda belum punya akses untuk absen karena belum mengisikan pembimbing lapangan dan instansi magang.<br><br>Edit akun anda dengan menekan tombol di bawah ini.<br><br>
                <form method = "POST" action = "edit_account.php">
                    <input type = "text" name = "dataEditValue" value = "<?php echo $loggedUser ?>" style = "display : none ;">
                    <button class = "btn btn-success">Isikan Instansi</button>
                </form>    
            </div> 
        </div><?php
    }else{ ?>
        <div class="div-tabel" id="hasAccessContainer">
        <h3><p style="margin-top:2em;margin-bottom:1em;">Riwayat Absensi</p></h3>
            <table id="myTable" class="table table-striped fl-table">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Jam Masuk</th>
                        <th>Jam Pulang</th>
                        <th>Status</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody><?php
                    foreach($seleksiRowAbsen as $row){ ?>
                        <tr>
                            <form method = "POST" action = "detail_absen.php">
                                <td><?php echo $row['tanggal'] ?></td>
                                <td><?php echo $row['jam_masuk'] ?> </td>
                                <td><?php echo $row['jam_pulang'] ?></td>
                                <td><?php echo $row['status'] ?></td>
                                <td style="white-space : nowrap;">
                                    <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                    <input type="text" name="dataValue" value="<?php echo $row['id_absen'] ?>" style="display:none;">
                                </td>
                            </form>
                        </tr><?php
                    } ?>
                </tbody>
            </table>
        </div><?php
    } ?>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
        $(document).ready(function(){
            $('#myTable').dataTable();
        });
    </script>
</body>