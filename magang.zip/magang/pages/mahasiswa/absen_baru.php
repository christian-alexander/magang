<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }

    //utk mambatasi kalender (update : gajadi dipake)
    date_default_timezone_set("Asia/Bangkok");

    $hariIni = date("Y-m-d");
    $tanggalIni = date("d");
    $tanggalKemarin = $tanggalIni - 1 ;
    $kemarinTahunBulan = date("Y-m-");
    $kemarin = $kemarinTahunBulan.=$tanggalKemarin;
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
	<div class = "box1" style="padding-top:5em;">
        <div class = "box2">
            <div class = "teks-login">
                <b>Absen Baru</b>
            </div>
            <div class = "box-info">
                <b>AM = 00.00 - 12.00 / PM = 12.01 - 23.59<br>Kesalahan AM PM dapat menyebabkan jam magang yang telah ditempuh berkurang<br>Kesalahan penginputan jam adalah tanggung jawab pribadi</b>
            </div>
            <div class="container" style="padding-left:2em;">
                <form method = "POST" action = "../../process/mahasiswa/absen_baru.php" onsubmit = "return ask()" id="absen" enctype="multipart/form-data">
                    <div class = "row box-date">
                        <div class = "col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            Jam Masuk
                            <p>
                                <input type = "time" name = "jam_masuk">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            Jam Pulang
                            <p>
                                <input type = "time" name = "jam_pulang">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-4 col-sm-12 col-xs-12">
                            Tanggal
                            <p>
                                <input type = "date" name = "tanggal">
                            </p>
                        </div>
                    </div>
                    Uraian Kegiatan
                        <p>
                            <textarea name = "uraian_kegiatan" form = "absen" class="teksarea"></textarea>
                        </p>
                    File Bukti
                    <div class="dropzone-wrapper">
                        <div class="dropzone-desc">
                            <div id = "keterangan">Pilih file bukti atau drag kesini.</div>
                        </div>
                        <input type="file" name="files[]" class="dropzone" id = "uploader" multiple/>
                    </div>
                    <div id = "tes"></div>
                    File Terpilih : <br>
                    <div id = "detail_files"><ul></ul></div>
                    <input type = "text" id = "jumlahFile" name = "jumlahFile" value = "" style = "display:none;">
                    <div class="div-add">
                        <button class = "btn btn-success add">Submit</button>
                    </div>     
                    <div class="div-add">
                        <a href = "absen.php" class = "btn btn-danger add">Cancel</a>
                    </div>                   
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script>
        var uploader = document.getElementById('uploader');
        uploader.onchange = 
        function getFileNames(){
            var files = document.getElementById("uploader").files;
            var names = "";
            var keterangan = document.getElementById('keterangan');
            var detail_files = document.getElementById('detail_files')
            var jumlahFile = document.getElementById('jumlahFile');
            for(var i = 0; i < files.length; i++){
                names += "<li>"+files[i].name + "</li>";
            }
            keterangan.innerHTML = files.length + " files terpilih";
            detail_files.innerHTML = names ;
            jumlahFile.value = files.length ;
        }

        function ask(){
            if(confirm("Apakah anda yakin?\n\nPastikan semua data betul, terutama JAM MASUK & JAM PULANG")){
                var keterangan = document.getElementById('keterangan');
                if(keterangan.innerHTML == "Pilih file bukti atau drag kesini."){
                    alert("Anda belum memilih file");
                    return false;
                }else{
                    return true;
                }
            }else{
                return false;
            }
        }
    </script>

</body>