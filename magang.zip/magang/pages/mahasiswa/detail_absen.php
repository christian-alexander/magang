<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk isi dari detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$loggedUser."");

    $id_absen = $_POST['dataValue'];
    $seleksiDataAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$loggedUser." WHERE id_absen = '".$id_absen."'");
    $seleksiFileAbsen = mysqli_query($connection,"SELECT * FROM _data_file_absen_mhs".$loggedUser." WHERE id_absen = '".$id_absen."'");


    //untuk download
    $filename = basename(($_GET['file']));
    $filepatch = '../../filepool/' . $filename;
    if(!empty($filename) && file_exists($filepatch)) {
        header("Cache-Control: public");
        header("Content-Description: FIle Trasfer");
        header("Content-disposition: attachment; filename=$filename");
        header("Content-Type: application/zip");
        header("Content-Tranfer-Encoding:binary");

        readfile($filepatch);
        exit;
    }
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
	<div class = "container" style="padding-top:5em;">
        <div class = "box-keterangan">
            <h3><b><p>Detail Absensi</p></b></h3>
            <table><?php
                foreach($seleksiDataAbsen as $row){ ?>
                    <tr>
                        <td style="padding-right: 170px;">Tanggal</td>
                        <td style="padding-right: 10px;">:</td>
                        <td><?php echo $row['tanggal']?></td>
                    </tr>
                    <tr>
                        <td>Jam Masuk</td>
                        <td>:</td>
                        <td><?php echo $row['jam_masuk']?></a></td>
                    </tr>
                    <tr>
                        <td>Jam Pulang</td>
                        <td>:</td>
                        <td><?php echo $row['jam_pulang']?></td>
                    </tr>
                    <tr>
                        <td>Uraian Kegiatan</td>
                        <td>:</td>
                        <td><?php echo $row['uraian_kegiatan']?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>:</td>
                        <td><?php echo $row['status'] ?></td>
                    </tr><?php
                }
                $i = 1 ;
                foreach($seleksiFileAbsen as $rowFile){?>
                    <tr><?php
                        if($i == 1){ ?>
                            <td>File Bukti</td>
                            <td>:</td>
                            <td>
                                <a href = "detail_absen.php/?file=<?php echo $rowFile['file']?>"><?php echo $rowFile['file']?> </a>
                            </td><?php
                        }else{ ?>
                            <td></td>
                            <td></td>
                            <td>
                                <a href = "detail_absen.php/?file=<?php echo $rowFile['file']?>"><?php echo $rowFile['file']?></a>
                            </td><?php
                        } ?>
                    </tr><?php
                $i++ ;
                } ?>
            </table>
            <div class="div-add">
                <a href = "absen.php" class = "btn btn-success add">Back</a>
            </div>              
        </div>
    </div>

    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

</body>