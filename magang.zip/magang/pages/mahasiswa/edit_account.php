<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }

    $seleksiTabel = mysqli_query($connection,"SELECT * FROM instansi");
    $banyakRow = mysqli_num_rows($seleksiTabel);
    $daftarInstansi = array();
    for($baris = 1 ; $baris <= $banyakRow ; $baris++){
    	$seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = $baris");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $namaInstansi = $seleksiKolomInstansi['nama'];
        $idInstansi = $seleksiKolomInstansi['id_instansi'];
        $detildata = array($namaInstansi,$idInstansi);
        array_push($daftarInstansi,$detildata);
    }


    $seleksiTabelPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
    $banyakRowPemLap = mysqli_num_rows($seleksiTabelPemLap);
    $daftarPemLap = array();
    for($baris = 1 ; $baris <= $banyakRowPemLap ; $baris++){
    	$seleksiRowPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id = $baris");
        $seleksiKolomPemLap = mysqli_fetch_assoc($seleksiRowPemLap);
        $namaPemLap = $seleksiKolomPemLap['nama'];
        $idPemLap = $seleksiKolomPemLap['id_utama'];
        $detildataPemLap = array($namaPemLap,$idPemLap);
        array_push($daftarPemLap,$detildataPemLap);
    }


    $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$_POST['dataEditValue']."'");
    $seleksiKolomMahasiswa = mysqli_fetch_assoc($seleksiRowMahasiswa);
    $namaMahasiswa = $seleksiKolomMahasiswa['nama'];
    $nowaMahasiswa = $seleksiKolomMahasiswa['nowa'];
    $emailMahasiswa = $seleksiKolomMahasiswa['email'];
    $nrpMahasiswa = $seleksiKolomMahasiswa['nrp'];
    $instansiMahasiswa = $seleksiKolomMahasiswa['instansi'];
    $dosenMahasiswa = $seleksiKolomMahasiswa['dosenpembimbing'];
    $pemlapMahasiswa = $seleksiKolomMahasiswa['pembimbinglapangan'];
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="../../css/superuser/edit/edit_account.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top" style="position:fixed !important;">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                	<li class="nav-item">
                    	<a class ="btn btn-danger" href="edit_password.php">Ubah Password</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item active">
                        <form method = "POST" action="akun.php">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun-active" style="display: block !important; margin-top: 1rem !important;">Profil</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Edit Profil</b>
            </div><?php 
            if($pemlapMahasiswa != ""){ ?>			
                <form method = "POST" action = "../../process/mahasiswa/edit/edit_account.php" onsubmit ="return verifikasi()"><?php
            }else{ ?>
                <form method = "POST" action = "../../process/mahasiswa/edit/edit_account_awal.php" onsubmit ="return verifikasiAwal()"><?php
            } ?>
                    <div class="container" style="padding-left:2em;">
                        <div class = "row">
                            <!-- untuk meneruskan email lama utk pengecualian -->
                            <input type = "text" style = "display:none" name = "emailLama" value = "<?php echo $emailMahasiswa ?>">
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Nama Lengkap<a id="warningNama" style="color:red;"></a>                            
                                <p>
                                    <input type = "text" name="nama" id="nama" class = "inside-box" value="<?php echo $namaMahasiswa ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <a id="teksNRP">NRP</a><a id="warningNRP" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="NRP" id="NRP" class = "inside-box" value="<?php echo $nrpMahasiswa ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Email<a id="warningEmail" style="color:red;"></a>
                                <p>
                                    <input type = "text" name="email" id="email" class = "inside-box" value="<?php echo $emailMahasiswa?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                No WhatsApp<a id="warningNowa" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="nowa" id="nowa" class = "inside-box" value="<?php echo $nowaMahasiswa?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Peran<br>
                                <p>
                                    <input type = "text" name="peran" id="peran" class = "inside-box" value="Mahasiswa" disabled>
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12"><?php
                                if($pemlapMahasiswa == ""){ ?>
                                    Instansi<a style="color:red;"> *Ganti dengan instansi baru</a><br>
                                    <select name = "instansi" id="instansi" class="selectpicker" data-live-search="true">
                                        <?php
                                        for($baris = 0 ; $baris < $banyakRow ; $baris++){
                                            if($daftarInstansi[$baris][1] == $instansiMahasiswa){?>
                                                <option value="<?php echo $daftarInstansi[$baris][1]?>" selected><?php echo $daftarInstansi[$baris][0]?></option><?php
                                            }else{ ?>
                                                <option value="<?php echo $daftarInstansi[$baris][1]?>"><?php echo $daftarInstansi[$baris][0]?></option><?php
                                            }
                                        } ?>
                                    </select><?php
                                }else{ 
                                    $seleksiTabelInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$instansiMahasiswa."' ");
                                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiTabelInstansi);
                                    $namaInstansi = $seleksiKolomInstansi['nama'];?>
                                    Instansi<br>
                                    <input type="text" name="instansi" value="<?php echo $namaInstansi ?>" disabled><?php
                                } ?>
                            </div>  
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Dosen Pembimbing<?php
                                $seleksiTabelDosBing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$dosenMahasiswa."' ");
                                $seleksiKolomDosbing = mysqli_fetch_assoc($seleksiTabelDosBing);
                                $namaDosbing = $seleksiKolomDosbing['nama']; ?>
                                <p>
                                    <input type = "text" name="dosen_pembimbing" value="<?php echo $namaDosbing ?>" disabled>
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12"><?php
                                if($pemlapMahasiswa == ""){ ?>
                                    Pembimbing Lapangan<a style="color:red;"> *Pilih</a>
                                    <select name = "pembimbing_lapangan" id="pembimbing_lapangan" class="selectpicker" data-live-search="true">
                                        <option value = "" selected>Belum Ada</option><?php
                                        for($baris = 0 ; $baris < $banyakRowPemLap ; $baris++){
                                            if($daftarPemLap[$baris][1] == $pemlapMahasiswa){?>
                                                <option value="<?php echo $daftarPemLap[$baris][1]?>" selected><?php echo $daftarPemLap[$baris][0]?></option><?php
                                            }else{ ?>
                                            <option value="<?php echo $daftarPemLap[$baris][1]?>"><?php echo $daftarPemLap[$baris][0]?></option><?php
                                            }
                                        } ?>
                                    </select> <?php
                                }else{
                                    $seleksiTabelPembimbingLapangan = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$pemlapMahasiswa."' ");
                                    $seleksiKolomPembimbingLapangan = mysqli_fetch_assoc($seleksiTabelPembimbingLapangan);
                                    $namaPembimbingLapangan = $seleksiKolomPembimbingLapangan['nama'];?>
                                    Pembimbing Lapangan<br>
                                    <input type="text" name="pembimbing_lapangan" value="<?php echo $namaPembimbingLapangan ?>" disabled><?php
                                } ?>
                                </select>
                            </div>
                        </div>
                        <div class="div-add">
                            <button type = "submit" class = "btn btn-success add">Edit</button>
                        </div>  
                        <div class="div-add" style="padding-top:0;">
                            <a href="home.php" class = "btn btn-danger add">Cancel</a>
                        </div>
                        <input type = "text" name= "id_utama" value="<?php echo $loggedUser ?>" style="display:none;">
                    </div>
                </form>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
	<script src="../../js/mahasiswa/verify_edit_account.js"></script>
	
</body>