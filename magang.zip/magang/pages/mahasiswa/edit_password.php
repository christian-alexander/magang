<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
    
    $seleksiRowPassword = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomPassword = mysqli_fetch_assoc($seleksiRowPassword);
    $passwordTerEncrypt = $seleksiKolomPassword['password'];
    //proses decrypt
    $passwordPlain = $passwordTerEncrypt;
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/signup/signup_instansi.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top" style="position:fixed !important;">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item active">
                        <form method = "POST" action="akun.php">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun-active" >Profil</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div id = "boxPassLama" class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Ubah Password</b>
            </div>			
            	
            <div class="container" style="padding-left:2em;">
            
                <div class = "container">
                    Password Lama<a id="warningPassLama" style="color:red;"></a>                            
                    <p>
                        <input type = "password" id="passLama" class = "inside-box" value="">
                    </p>
                </div>
                <div class="div-add">
                    <button style="margin-top:10px;" onclick = "cek()" class = "btn btn-success add">OK</button>
                    <br>
                    <a style="margin-top:10px;" href = "akun.php" class = "btn btn-danger add">Cancel</a>
                </div>  
            </div>
        </div>
    </div>	
    
    <div id="boxPassBaru"class = "box" style="padding-top:5em;padding-bottom:5em;display:none;">
        <div class = "box2">
            <div class = teks-login>
                <b>Ubah Password</b>
            </div>			
            	
            <form method = "POST" action="../../process/mahasiswa/edit/edit_password.php" onsubmit ="return verifikasi()">
                <div class="container" style="padding-left:2em;">
                    <div class = "container">
                        Password Baru<a id="warningPassBaru" style="color:red;"></a>                            
                        <p>
                            <input name = "password" type = "password" id="passBaru" class = "inside-box" value="">
                        </p>
                    </div>
                    <div class = "container">
                        Konfirmasi Password Baru<a id="warningKonfirmasiPassBaru" style="color:red;"></a>                            
                        <p>
                            <input type = "password" id="konfirmasiPassBaru" class = "inside-box" value="">
                        </p>
                    </div>
                    <div class="div-add">
                        <button style="margin-top:10px;" type = "submit" class = "btn btn-success add">Ubah</button>
                        <br>
                        <a style="margin-top:10px;" href = "akun.php" class = "btn btn-danger add">Cancel</a>
                    </div>  
                </div>
			</form>
        </div>
    </div>	

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="../../js/mahasiswa/verifyPassword.js"></script>
    <script>
        function cek(){
            var passLama = document.getElementById('passLama');
            if(passLama.value == "<?php echo $passwordPlain ?>"){
                var boxPassBaru = document.getElementById('boxPassBaru');
                boxPassBaru.style.display = "block" ;
                var boxPassLama = document.getElementById('boxPassLama');
                boxPassLama.style.display = "none" ;
                
            }else{
                var warningPassLama = document.getElementById('warningPassLama');
                warningPassLama.innerHTML = " *Password salah";
            
            }
        }   
    </script>
</body>