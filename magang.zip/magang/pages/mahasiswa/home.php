<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk menentukan apa yg dilihat user, mengambil status
    $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
    $statusMahasiswa = $seleksiKolomStatus['id_status'];


    //untuk progress bar
    $seleksiRowJamMagang = mysqli_query($connection,"SELECT * FROM mahasiswa");
    foreach($seleksiRowJamMagang as $row){
        if($row['id_utama'] == $loggedUser){
            $detikJamMagang = $row['jam_magang'];
            $jamJamMagang = floor($detikJamMagang/3600);
            $persentase = $jamJamMagang / 200 * 100 ; 
            if($persentase > 100){
                $persentase = 100 ;
            }
        }
    }
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <form method = "POST" action="akun.php">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun">Profil</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
    <div class = "container" style="padding-top : 5em ;">
        <div class = "box-keterangan" style="overflow-wrap:break-word;">    
            <h3><b><p style = "text-align:center;">Proses Magang Anda</p></b></h3>
            <div class="progress" style = "margin-top:3em;height:2.5em;text-align:center;">
                <span style = "position : absolute; right:0; left:0;"><h5><b><?php echo $persentase ?>%</b></h5></span>
                <div class="progress-bar" role="progressbar" style="width: <?php echo $persentase ?>%;" aria-valuenow="<?php echo $jamJamMagang ?>" aria-valuemin="0" aria-valuemax="200"></div>
            </div>
            <p>
                <h5 style = "color:rgba(67, 27, 100, 0.8);">Jam Magang Terselesaikan : <?php echo $jamJamMagang ?> / 200 Jam</h5>
            </p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>