<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 4){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk menentukan apa yg dilihat user, mengambil status
    $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
	$statusMahasiswa = $seleksiKolomStatus['id_status'];

    
    //untuk penentuan sudah create judul laporan atau belum
    $seleksiLaporan = mysqli_query($connection,"SELECT * FROM data_laporan WHERE id_utama = '".$loggedUser."'");
    $seleksiKolomLaporan = mysqli_fetch_assoc($seleksiLaporan);
    if($seleksiKolomLaporan == null){
        $namaLaporan = "Laporan Anda";
    }else{
		$namaLaporan = $seleksiKolomLaporan['judul_laporan'];
    }

    //untuk cek laporan udah ada belom
    $fileLaporanKetemu = FALSE ;
    $seleksiTabel = mysqli_query($connection,"SELECT * FROM file_laporan");
    foreach($seleksiTabel as $row){
        if($row['id_utama'] == $loggedUser and $row['status'] == "on"){
            $fileLaporanKetemu = TRUE ;
            $timestamp = $row['timestamp'];
            $arrayTimestamp = explode(" ",$timestamp);
            $tanggalLaporan = $arrayTimestamp[0];
            $jamLaporan = $arrayTimestamp[1];
            break;
        }
    }

    if($fileLaporanKetemu){
        $statusLaporan = "sudah";
    }else{
        $statusLaporan = "belum";
    }

    

?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/laporan.css">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <form method = "POST" action="akun.php">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun">Akun</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <?php
    if($statusMahasiswa < 4){ ?>
        <div class = "container" id="noAccessContainer" style="padding-top:5em;">
            <div class = "box-keterangan">
                Anda belum punya akses untuk laporan karena belum memenuhi kewajiban jam magang.
        
            </div>  
        </div><?php
    }else{ ?>
        <div class="container" id="hasAccessContainer" style="padding-top:5em;"><?php
        if($namaLaporan == "Laporan Anda"){ ?>    
            <div class = "box-keterangan">
                <h3><b><p style="text-align:center;"><?php echo $namaLaporan ?></p></b></h3>
                <h5><p style="color:rgba(67, 27, 100, 0.8);margin-top:2em;margin-bottom:2em;">Sepertinya anda belum memberi judul pada laporan anda. Klik tombol dibawah ini untuk memberi judul.</p></h5>
                <form method="POST" action="../../process/mahasiswa/namai_laporan.php" onsubmit="return namaiLaporan();">
                    <input type = "text" style = "display : none ;" value ="" name = "judulLaporan" id="judulLaporan">
                    <button type="submit" class = "btn btn-success add">Beri Judul</button>
                </form>
            </div><?php
        }else{ ?>
            <div class = "box-keterangan">
                <h3><b><p style="text-align:center;">Laporan Anda</p></b></h3>
            
                <h5 class = "judul-box"><?php echo $namaLaporan ?></h5><?php
                if($statusLaporan == "belum"){ ?>
                    <a style="color:rgba(67, 27, 100, 0.8);">Belum Dikerjakan</a>
                    <div class="div-add" style="margin-top:1.5em;padding-bottom:1.5em;">
                        <form method="POST" action="upload_laporan.php">
                            <button class = "btn btn-success add">Upload</button>
                        </form>    
                    </div><?php
                }else{ ?>
                    <a style="color:rgba(67, 27, 100, 0.8);"><?php echo"Terakhir Diubah<br>";echo"Tanggal : ";echo $tanggalLaporan;echo"<br>Waktu : ";echo $jamLaporan; ?></a>
                    <div class="div-add" style="margin-top:1.5em;padding-bottom:1.5em;">
                        <form method="POST" action="lihat_laporan.php">
                            <input type ="text" name = "judul_laporan" style="display:none;" value="<?php echo $namaLaporan ?>" >
                            <button class = "btn btn-success add">Lihat</button>
                        </form>    
                    </div><?php
                } ?>
            </div><?php
        } ?>
        </div><?php
    } ?>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        function namaiLaporan(){
            var judulLaporan = document.getElementById("judulLaporan");
            var judul = prompt("Judul Laporan");
            if(judul != null && judul !=""){
                judulLaporan.value = judul ;
                return true ;
            }else{
                return false;
            }
        }
    </script>
</body>