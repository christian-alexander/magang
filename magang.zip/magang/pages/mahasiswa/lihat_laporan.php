<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<?php
session_start();
include('../../connection/connection.php');
//cek valid login
if(isset($_SESSION['loggedUser'])){
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $entitasLoggedUser = $seleksiKolom['entitas'];
    if($entitasLoggedUser != 4){
        header("Location: ../../index.php");    
    }else{
        $namaUser = $seleksiKolom['nama'] ;
    } 
}else{
    header("Location: ../../index.php");
}

//untuk isi dari detail laporan
$seleksiDataLaporan = mysqli_query($connection,"SELECT * FROM data_laporan WHERE id_utama = '".$loggedUser."'");
$seleksiKolomDataLaporan = mysqli_fetch_assoc($seleksiDataLaporan);
$seleksiLaporan = mysqli_query($connection,"SELECT * FROM file_laporan WHERE id_utama = '".$loggedUser."'");
$judulLaporan = $seleksiKolomDataLaporan['judul_laporan'];
//untuk download
if(isset($_GET['file'])){
    $filename = basename(($_GET['file']));
    $filepatch = '../../filepool_laporan/' . $filename;
    if(!empty($filename) && file_exists($filepatch)) {
        header("Cache-Control: public");
        header("Content-Description: FIle Trasfer");
        header("Content-disposition: attachment; filename=$filename");
        header("Content-Type: application/zip");
        header("Content-Tranfer-Encoding:binary");

        readfile($filepatch);
        exit;
    }
}



?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
    <link rel="stylesheet" href="../../css/mahasiswa/lihat_laporan.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <form method = "POST" action="akun.php" style="margin-block-end:0;">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun">Profil</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
	<div class = "container" style="padding-top:5em;">
        <div class = "box-keterangan" style="overflow-wrap:break-word;">
            <h3><b><p style = "text-align:center;">Laporan KP</b></h3>    
            
            <a style="color:rgba(67, 27, 100, 0.8);">Judul : <?php echo $judulLaporan ; ?></a><br>
            
            <div style="margin-top:1em;">
                <h4>File Program</h4>
                <ul style = "list-style:decimal;"><?php
                foreach($seleksiLaporan as $rowFile){
                    if($rowFile['status'] == "on" and $rowFile['jenis_laporan'] == 1){?>
                    	<li><a href = "lihat_laporan.php/?file=<?php echo $rowFile['file']?>">  <?php echo $rowFile['file']?>  </a></li><?php
                    }
                } ?>
                </ul>
            </div>
            <div>
                <h4>File User Guide</h4>
                <ul style = "list-style:decimal;"><?php
                foreach($seleksiLaporan as $rowFile){
                    if($rowFile['status'] == "on" and $rowFile['jenis_laporan'] == 2){?>
                    	<li><a href = "lihat_laporan.php/?file=<?php echo $rowFile['file']?>">  <?php echo $rowFile['file']?>  </a></li><?php
                    }
                } ?>
                </ul>
            </div>
            <div>
                <h4>File Lembar Pengesahan</h4>
                <ul style = "list-style:decimal;"><?php
                foreach($seleksiLaporan as $rowFile){
                    if($rowFile['status'] == "on" and $rowFile['jenis_laporan'] == 3){?>
                    	<li><a href = "lihat_laporan.php/?file=<?php echo $rowFile['file']?>">  <?php echo $rowFile['file']?>  </a></li><?php
                    }
                } ?>
                </ul>
            </div><?php
            foreach($seleksiDataLaporan as $row){ ?>
                <div class = "div-nilai">
                    <h4>Komentar</h4>
                    <a style="text-align:justify">1. Dosen Pembimbing : <br><?php if($row['komentar_dosbing'] != ""){echo $row['komentar_dosbing'];}else{echo "Belum Ada";} ?></a><br>
                    <br><a style="text-align:justify">2. Pembimbing Lapangan : <br><?php if($row['komentar_pemlap'] != ""){echo $row['komentar_pemlap'];}else{echo "Belum Ada";} ?></a>
                </div>
                <div class = "div-nilai">
                    <h4>Score</h4>
                    <a>1. Dosen Pembimbing : <?php if($row['nilai_dosbing'] != 0){echo $row['nilai_dosbing'];}else{echo "Belum Dinilai";} ?></a><br>
                    <a>2. Pembimbing Lapangan : <?php if($row['nilai_pemlap'] != 0){echo $row['nilai_pemlap'];}else{echo "Belum Dinilai";} ?></a>
                </div><?php
                if($row['nilai_dosbing'] == 0 and $row['nilai_pemlap'] == 0){ ?>
                    <div class="div-add">
                        <form action="edit_laporan.php" method="POST">
                            <input type = "text" name="pemilikLaporan" style="display:none" value="<?php echo $row['id_utama'] ?>">
                            <button class = "btn btn-success add">Edit</button>
                        </form>
                    </div><?php 
                } ?>
                <div class="div-add">
                    <a href = "laporan.php" class = "btn btn-primary add">Back</a>
                </div><?php 
            } ?>             
        </div>
    </div>

    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>