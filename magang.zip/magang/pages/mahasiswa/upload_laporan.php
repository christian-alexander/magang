<?php
session_start();
include('../../connection/connection.php');
//cek valid login
if(isset($_SESSION['loggedUser'])){
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $entitasLoggedUser = $seleksiKolom['entitas'];
    if($entitasLoggedUser != 4){
        header("Location: ../../index.php");    
    }else{
        $namaUser = $seleksiKolom['nama'] ;
    } 
}else{
    header("Location: ../../index.php");
}

?>



<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/mahasiswa/nav.css">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="absen.php">Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <form method = "POST" action="akun.php">
                            <input type = "text" name="dataValue" value="<?php echo $loggedUser ?>" style="display:none" >
                            <button type = "submit" class = "nav-link button-akun">Akun</button>
                        </form>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
	<div class = "box1" style="padding-top:5em;">
        <div class = "box2">
            <div class = "teks-login">
                <b>Upload Laporan</b>
            </div>
            <div class = "box-info">
                <b>Silahkan Mengupload Hasil Laporan Disini</b>
            </div>
            <div class="container" style="padding-left:2em;">
            	<h5>File Program</h5>
                <form method = "POST" action = "../../process/mahasiswa/upload_laporan.php" onsubmit = "return ask()" id="absen" enctype="multipart/form-data">
                    <input type = "text" name="valueLaporan" style="display:none;" value="<?php echo $valueLaporan ?>">
                    <div class="dropzone-wrapper">
                        <div class="dropzone-desc">
                            <div id = "keterangan1">Pilih file atau drag kesini.</div>
                        </div>
                        <input type="file" name="files1[]" class="dropzone" id = "uploader1" multiple/>
                    </div>
                    File Terpilih : <br>
                    <div id = "detail_files1"><ul></ul></div><br>
                    <input type = "text" id = "jumlahFile1" name = "jumlahFile1" value = "" style = "display:none;">     
                

                    <!-- User Guide -->
                    <h5>User Guide</h5>
                	<div class="dropzone-wrapper">
                        <div class="dropzone-desc">
                            <div id = "keterangan2">Pilih file atau drag kesini.</div>
                        </div>
                        <input type="file" name="files2[]" class="dropzone" id = "uploader2" multiple/>
                    </div>
                    File Terpilih : <br>
                    <div id = "detail_files2"><ul></ul></div><br>
                    <input type = "text" id = "jumlahFile2" name = "jumlahFile2" value = "" style = "display:none;">
                    
                    <!-- Lembar Pengesahan -->
                    <h5>Lembar Pengesahan</h5>
                	<div class="dropzone-wrapper">
                        <div class="dropzone-desc">
                            <div id = "keterangan3">Pilih file atau drag kesini.</div>
                        </div>
                        <input type="file" name="files3[]" class="dropzone" id = "uploader3" multiple/>
                    </div>
                    File Terpilih : <br>
                    <div id = "detail_files3"><ul></ul></div><br>
                    <input type = "text" id = "jumlahFile3" name = "jumlahFile3" value = "" style = "display:none;">
                    
                    
                    <div class="div-add">
                        <button class = "btn btn-success add">Submit</button>
                    </div>     
                    <div class="div-add">
                        <a href = "laporan.php" class = "btn btn-danger add">Cancel</a>
                    </div>                   
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script>
        var uploader1 = document.getElementById('uploader1');
        uploader1.onchange = 
        function getFileNames(){
            var files = document.getElementById("uploader1").files;
            var names = "";
            var keterangan1 = document.getElementById('keterangan1');
            var detail_files1 = document.getElementById('detail_files1')
            var jumlahFile1 = document.getElementById('jumlahFile1');
            for(var i = 0; i < files.length; i++){
                names += "<li>"+files[i].name + "</li>";
            }
            keterangan1.innerHTML = files.length + " files terpilih";
            detail_files1.innerHTML = names ;
            jumlahFile1.value = files.length ;
        }

        var uploader2 = document.getElementById('uploader2');
        uploader2.onchange = 
        function getFileNames(){
            var files = document.getElementById("uploader2").files;
            var names = "";
            var keterangan2 = document.getElementById('keterangan2');
            var detail_files2 = document.getElementById('detail_files2')
            var jumlahFile2 = document.getElementById('jumlahFile2');
            for(var i = 0; i < files.length; i++){
                names += "<li>"+files[i].name + "</li>";
            }
            keterangan2.innerHTML = files.length + " files terpilih";
            detail_files2.innerHTML = names ;
            jumlahFile2.value = files.length ;
        }

        var uploader3 = document.getElementById('uploader3');
        uploader3.onchange = 
        function getFileNames(){
            var files = document.getElementById("uploader3").files;
            var names = "";
            var keterangan3 = document.getElementById('keterangan3');
            var detail_files3 = document.getElementById('detail_files3')
            var jumlahFile3 = document.getElementById('jumlahFile3');
            for(var i = 0; i < files.length; i++){
                names += "<li>"+files[i].name + "</li>";
            }
            keterangan3.innerHTML = files.length + " files terpilih";
            detail_files3.innerHTML = names ;
            jumlahFile3.value = files.length ;
        }

        function ask(){
            if(confirm("Apakah anda yakin?\n\nPastikan semua file betul. Anda tak dapat mengedit lagi bila sudah dinilai.")){
                var keterangan1 = document.getElementById('keterangan1');
                var keterangan2 = document.getElementById('keterangan2');
                var keterangan3 = document.getElementById('keterangan3');
                
                if(keterangan1.innerHTML == "Pilih file atau drag kesini."){
                    alert("Anda belum memilih file program");
                    return false;
                }else if(keterangan2.innerHTML == "Pilih file atau drag kesini."){
                    alert("Anda belum memilih file user guide");
                    return false;
                }else if(keterangan3.innerHTML == "Pilih file atau drag kesini."){
                    alert("Anda belum memilih file lembar pengesahan");
                    return false;
                }else{
                    return true;
                }
            }else{
                return false;
            }
        }
    </script>

</body>