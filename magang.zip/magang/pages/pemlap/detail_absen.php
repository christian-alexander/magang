<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 3){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk isi dari detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$loggedUser."");
    
    $id_utama = $_POST['dataValueIdUtama'];
    $id_absen = $_POST['dataValueIdAbsen'];
    $seleksiDataAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$id_utama." WHERE id_absen = '".$id_absen."'");
    $seleksiFileAbsen = mysqli_query($connection,"SELECT * FROM _data_file_absen_mhs".$id_utama." WHERE id_absen = '".$id_absen."'");


    //untuk download
    if(isset($_GET['file'])){
        $filename = basename(($_GET['file']));
        $filepatch = '../../filepool/' . $filename;
        if(!empty($filename) && file_exists($filepatch)) {
            header("Cache-Control: public");
            header("Content-Description: FIle Trasfer");
            header("Content-disposition: attachment; filename=$filename");
            header("Content-Type: application/zip");
            header("Content-Tranfer-Encoding:binary");

            readfile($filepatch);
            exit;
        }
    }
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="permintaan_absen.php">Permintaan Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="laporan.php">Laporan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Profil</a>
					</li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
					</li>       
                </ul>
            </div>
        </div>
    </nav>
  
	<div class = "container" style="padding-top:5em;">
        <div class = "box-keterangan" style="overflow-wrap:break-word;">
            <h3><b><p style = "text-align:center;">Detail Absensi</p></b></h3><?php
            foreach($seleksiDataAbsen as $row){ ?>
                <div class = "row">
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Tanggal</b><br>
                        <?php echo $row['tanggal']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Jam Masuk</b><br>
                        <?php echo $row['jam_mulai']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <b>Jam Pulang</b><br>
                        <?php echo $row['jam_selesai']?>
                    </div>
                    <div class = "kolom col-lg-3 col-md-3 col-sm-6 col-xs-6"> 
                        <b>Status</b><br>
                        <?php echo $row['status'] ?><br><br>
                    </div>
                </div>
                <div style = "text-align:justify;"> 
                    <b>Uraian Kegiatan</b><br>
                    <?php echo $row['uraian_kegiatan']?><br><br>
                </div>
                <div>
                    <b>File Bukti</b>
                    <ul style = "list-style:decimal;"><?php
                    foreach($seleksiFileAbsen as $rowFile){?>
                        <li><a href = "detail_absen.php/?file=<?php echo $rowFile['file']?>">  <?php echo $rowFile['file']?>  </a></li><?php
                    } ?>
                    </ul>
                </div><?php
            } ?>
            <div class="div-add">
                <form method = "POST" action = "../../process/pemlap/acc_absen.php" onsubmit = "return cekAcc()">
                    <input type="text" name="dataValueIdUtama" value="<?php echo $id_utama ?>" style="display:none;">
                    <input type="text" name="dataValueIdAbsen" value="<?php echo $id_absen ?>" style="display:none;">
                    <button class = "btn btn-success add" style="color:white;">Terima</button>
                </form>
            </div>           
            <div class="div-add">
                <form method = "POST" action = "../../process/pemlap/dec_absen.php" onsubmit = "return cekDec()">
                    <input type="text" name="dataValueIdUtama" value="<?php echo $id_utama ?>" style="display:none;">
                    <input type="text" name="dataValueIdAbsen" value="<?php echo $id_absen ?>" style="display:none;">
                    <button class = "btn btn-danger add" style="color:white;">Tolak</button>
                </form>
            </div>           
            <div class="div-add">
                <a href = "permintaan_absen.php" class = "btn btn-primary add" style="color:white;">Cancel</a>
            </div>              
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        function cekAcc(){
            if(confirm("Apakah Anda yakin menerima permohonan absen ini?")){
                return true;
            }else{
                return false;
            }
        }

        function cekDec(){
            if(confirm("Apakah Anda yakin menolak permohonan absen ini?")){
                return true;
            }else{
                return false;
            }
        }
    </script>
</body>