<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 3){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }


    //untuk isi dari detail absen
    $seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM mahasiswa");

?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
	<!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <form action = "../../process/pemlap/acc_semua.php" onsubmit = "return cekAcc()" style="margin-block-end:0;">
                <button class="btn btn-success">Setujui Semua</button>
            </form>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="permintaan_absen.php">Permintaan Absen</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="akun.php">Akun</a>
					</li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Log Out</a>
					</li>       
                </ul>
            </div>
        </div>
    </nav>
   
    <div class="div-tabel" id="hasAccessContainer">
    <h3><p style="margin-top:2em;margin-bottom:1em;">Permohonan Absensi</p></h3>
        <table id="myTable" class="table table-striped">
            <thead>
                <tr>
                    <th>Mahasiswa</th>
                    <th>Tanggal</th>
                    <th>Jam Masuk</th>
                    <th>Jam Pulang</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody><?php
                foreach($seleksiRowAbsen as $row){
                    if($row['pembimbinglapangan'] == $loggedUser){ 
                        $seleksiRowDetailAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$row['id_utama']." ");
                        foreach($seleksiRowDetailAbsen as $rowDetail){ 
                            if($rowDetail['status'] == 'Diajukan') {?>
                                <tr>
                                    <form method = "POST" action = "detail_absen.php">
                                        <td><?php echo $row['nama'] ?></td>
                                        <td><?php echo $rowDetail['tanggal'] ?></td>
                                        <td><?php echo $rowDetail['jam_masuk'] ?> </td>
                                        <td><?php echo $rowDetail['jam_pulang'] ?></td>
                                        <td style="white-space : nowrap;">
                                            <span><a href="#" class="description" title="Info" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">description</i></button></a></span> 
                                            <input type="text" name="dataValueIdUtama" value="<?php echo $row['id_utama'] ?>" style="display:none;">
                                            <input type="text" name="dataValueIdAbsen" value="<?php echo $rowDetail['id_absen'] ?>" style="display:none;">
                                        </td>
                                    </form>
                                </tr><?php
                            }
                        }
                    }
                } ?>
            </tbody>
        </table>
    </div>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
        $(document).ready(function(){
            $('#myTable').dataTable();
        });

        function cekAcc(){
            if(confirm("Apakah anda yakin menyetujui semua permintaan absen disini? \n\nnote : kesalahan penyetujuan adalah tanggung jawab pribadi, pastikan benar-benar yakin sebelum memencet tombol ini")){
                return true ;
            }else{
                return false ;
            }
        }
    </script>
</body>