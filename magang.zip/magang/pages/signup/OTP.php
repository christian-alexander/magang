<?php
include("../../connection/connection.php");
$OTPCode = rand(100000,999999);
$email = $_POST['email'];
$pesan = "Kode Verifikasi Anda : " ;
$pesan.=$OTPCode;
$OTP = ".";
$OTP.=$OTPCode;
//kirim ke email
/*
ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "admin@christianalex.xyz";
$to = $email;
$subject = "Kode Verifikasi";
$message = $pesan ;
$headers = "From:" . $from;
mail($to,$subject,$message, $headers);
*/
?>



<!DOCTYPE html>
<head>
    <title>Wajib Ada</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/signup/signup_instansi.css">
    <link rel = "stylesheet" href="../../css/mahasiswa/absen.css">
    <link rel="stylesheet" href="../../css/signup/OTP.css">
</head>
<body>
    <div class = "box2" style= "margin-top:5em;">
        <div class = teks-login>
            <b>Masukkan Kode Verifikasi</b>
        </div>			
        <div class = "box-info">
            Harap masukkan kode verifikasi yang kami kirim ke email anda. Apabila tidak ada di halaman utama, harap memeriksa bagian spam.
        </div>
        <div class="container" style="padding-left:2em;">
            
            <div style = "text-align:center;">
                <form method="get" class="digit-group" data-group-name="digits" data-autosubmit="false" autocomplete="off">
                    <input type="tel" id="digit-1" name="digit-1" data-next="digit-2" class = "digit"/>
                    <input type="tel" id="digit-2" name="digit-2" data-next="digit-3" data-previous="digit-1" class = "digit"/>
                    <input type="tel" id="digit-3" name="digit-3" data-next="digit-4" data-previous="digit-2" class = "digit"/>
                    <span class="splitter">&ndash;</span>
                    <input type="tel" id="digit-4" name="digit-4" data-next="digit-5" data-previous="digit-3" class = "digit"/>
                    <input type="tel" id="digit-5" name="digit-5" data-next="digit-6" data-previous="digit-4" class = "digit"/>
                    <input type="tel" id="digit-6" name="digit-6" data-previous="digit-5" class = "digit"/>
                </form>
            </div>
            <form method="POST" onsubmit="return cekOTP()" action="../../process/signup/signup_akun.php">
                <div class="div-add">
                    <button style="margin-top:10px;" class = "btn btn-success add">OK</button>
                </div>
                <input type = "text" style="display:none;" name = "nama" value="<?php echo $_POST['nama'] ?>">
                <input type = "text" style="display:none;" name = "NRP" value="<?php echo $_POST['NRP'] ?>">
                <input type = "text" style="display:none;" name = "email" value="<?php echo $_POST['email'] ?>">
                <input type = "text" style="display:none;" name = "password" value="<?php echo $_POST['password'] ?>">
                <input type = "text" style="display:none;" name = "nowa" value="<?php echo $_POST['nowa'] ?>">
                <input type = "text" style="display:none;" name = "instansi" value="<?php echo $_POST['instansi'] ?>">
                <input type = "text" style="display:none;" name = "peran" value="<?php echo $_POST['peran'] ?>">
                <input type = "text" style="display:none;" name = "dosen_pembimbing" value="<?php echo $_POST['dosen_pembimbing'] ?>">
                <input type = "text" style="display:none;" name = "pembimbing_lapangan" value="<?php echo $_POST['pembimbing_lapangan'] ?>"> 
            </form>  
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="../../js/signup/OTP.js"></script>

    <script>
		function cekOTP(){
            var digit1 = document.getElementById('digit-1');
            var digit2 = document.getElementById('digit-2');
            var digit3 = document.getElementById('digit-3');
            var digit4 = document.getElementById('digit-4');
            var digit5 = document.getElementById('digit-5');
            var digit6 = document.getElementById('digit-6');
            if(
				digit1.value == '<?php echo $OTP[1] ?>' &&
                digit2.value == '<?php echo $OTP[2] ?>' &&
                digit3.value == '<?php echo $OTP[3] ?>' &&
                digit4.value == '<?php echo $OTP[4] ?>' &&
                digit5.value == '<?php echo $OTP[5] ?>' &&
                digit6.value == '<?php echo $OTP[6] ?>'
            ){
				return true;
            }else{
                digit1.value = '' ;
                digit2.value = '' ;
                digit3.value = '' ;
                digit4.value = '' ;
                digit5.value = '' ;
                digit6.value = '' ;
                alert('Kode yang anda masukkan salah. Coba lagi');
                return false;
            }
        }

    </script>
</body>