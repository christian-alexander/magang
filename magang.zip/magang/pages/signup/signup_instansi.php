<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="../../css/signup/signup_instansi.css">
</head>

<body>
    <div class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Ajukan Instansi</b>
            </div>			
            	
            <form method = "POST" action = "../../process/signup/signup_instansi.php" onsubmit ="return verifikasi()">
                <div class="container" style="padding-left:2em;">
                    <div class = "row">
                    <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Nama Instansi<a id="warningNama" style="color:red;"> *Wajib</a>                            
                            <p>
                                <input type = "text" name="Nama" id="Nama" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No Telepon<a id="warningNoTelp" style="color:red;"> *Wajib</a>
                            <p>
                                <input type = "tel" name="NoTelp" id="NoTelp" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No Fax<a id="warningNoFax" style="color:red;"></a>
                            <p>
                                <input type = "tel" name="NoFax" id="NoFax" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Email<a id="warningEmail" style="color:red;"> *Wajib</a>
                            <p>
                                <input type = "text" name="Email" id="Email" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Alamat<a id="warningAlamat" style="color:red;"> *Wajib</a>
                            <p>
                                <input type = "text" name="Alamat" id="Alamat" class = "inside-box" value="">
                            </p>
                        </div>
                    </div>
                    <div class="div-add">
                        <button type = "submit" class = "btn btn-success add">Ajukan</button>
                    </div>  
                </div>
			</form>
        </div>
    </div>	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>

	<script src="../../js/signup/verify_signup_instansi.js"></script>
	

</body>