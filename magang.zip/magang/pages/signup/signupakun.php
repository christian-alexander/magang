<?php
    session_start();
    include('../../connection/connection.php');
    
    $seleksiTabel = mysqli_query($connection,"SELECT * FROM instansi");
    $banyakRow = mysqli_num_rows($seleksiTabel);
    $daftarInstansi = array();
    for($baris = 1 ; $baris <= $banyakRow ; $baris++){
    	$seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = $baris");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $namaInstansi = $seleksiKolomInstansi['nama'];
        $idInstansi = $seleksiKolomInstansi['id_instansi'];
        $detildata = array($namaInstansi,$idInstansi);
        array_push($daftarInstansi,$detildata);
    }

    $seleksiTabelDosBing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing");
    $banyakRowDosBing = mysqli_num_rows($seleksiTabelDosBing);
    $daftarDosBing = array();
    for($baris = 1 ; $baris <= $banyakRowDosBing ; $baris++){
    	$seleksiRowDosBing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id = $baris");
        $seleksiKolomDosBing = mysqli_fetch_assoc($seleksiRowDosBing);
        $namaDosBing = $seleksiKolomDosBing['nama'];
        $idDosBing = $seleksiKolomDosBing['id_utama'];
        $detildataDosBing = array($namaDosBing,$idDosBing);
        array_push($daftarDosBing,$detildataDosBing);
    }

    $seleksiTabelPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
    $banyakRowPemLap = mysqli_num_rows($seleksiTabelPemLap);
    $daftarPemLap = array();
    for($baris = 1 ; $baris <= $banyakRowPemLap ; $baris++){
    	$seleksiRowPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id = $baris");
        $seleksiKolomPemLap = mysqli_fetch_assoc($seleksiRowPemLap);
        $namaPemLap = $seleksiKolomPemLap['nama'];
        $idPemLap = $seleksiKolomPemLap['id_utama'];
        $detildataPemLap = array($namaPemLap,$idPemLap);
        array_push($daftarPemLap,$detildataPemLap);
    }
?>

<!DOCTYPE html>
<head>
    <title>Sign Up</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />

    <link rel="stylesheet" href="../../css/signup/signupakun.css">
</head>
<body>
    <div class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Sign Up</b>
            </div>			
            	
            <form method = "POST" action = "../../process/signup/signupakun.php" onsubmit ="return verifikasi()">
                <div class="container" style="padding-left:2em;">
                    <div class = "row">
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Nama Lengkap<a id="warningNama" style="color:red;"></a>                            
                            <p>
                                <input type = "text" name="nama" id="nama" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            <a id="teksNRP">NIP (opsional)</a><a id="warningNRP" style="color:red;"></a>
                            <p>
                                <input type = "tel" name="NRP" id="NRP" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-xs">
                        	Email<a id="warningEmail" style="color:red;"></a>
                            <p>
                                <input type = "text" name="email" id="email" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Password<a id="warningPassword" style="color:red;"></a>                            
                                        <span><input type = "password" name="password" id="password" class = "inside-box" value=""></span>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Konfirmasi Password<a id="warningKonfirmasiPassword" style="color:red;"></a>                            
                                        <span><input type = "password" name="konfirmasipassword" id="konfirmasipassword" class = "inside-box" value=""></span>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No WhatsApp<a id="warningNowa" style="color:red;"></a>
                            <p>
                                <input type = "tel" name="nowa" id="nowa" class = "inside-box" value="">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Instansi<br>
                            <select name = "instansi" class="selectpicker" data-live-search="true">
                                <?php
                                for($baris = 0 ; $baris < $banyakRow ; $baris++){?>
                                    <option value="<?php echo $daftarInstansi[$baris][1]?>"><?php echo $daftarInstansi[$baris][0]?></option><?php
                                } ?>
                            </select>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Peran<br>
                            <select name="peran" class="selectpicker" id="peran" onchange="gantiNRP()">
                                <option value="3">Pembimbing Lapangan</option>
                                <option value="4">Mahasiswa</option>
                            </select>
                        </div>  
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12 utkmhs">
                            Dosen Pembimbing<br>
                            <select name = "dosen_pembimbing" class="selectpicker" data-live-search="true">
                                <?php
                                for($baris = 0 ; $baris < $banyakRowDosBing ; $baris++){?>
                                    <option value="<?php echo $daftarDosBing[$baris][1]?>"><?php echo $daftarDosBing[$baris][0]?></option><?php
                                } ?>
                            </select>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12 utkmhs">
                            Pembimbing Lapangan<br>
                            <select name = "pembimbing_lapangan" class="selectpicker" data-live-search="true">
                                <option value ="">Belum Ada</option>
                                <?php
                                for($baris = 0 ; $baris < $banyakRowPemLap ; $baris++){?>
                                    <option value="<?php echo $daftarPemLap[$baris][1]?>"><?php echo $daftarPemLap[$baris][0]?></option><?php
                                } ?>
                            </select>
                        </div>
                    </div>
                    <div class="div-add">
                        <button type = "submit" class = "btn btn-success add">Sign Up</button>
                    </div>  
                </div>
			</form>
        </div>
    </div>	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>

    <script src="../../js/superuser/add/verify_signup_account.js"></script>
</body>