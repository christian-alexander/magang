<?php
    session_start();
    include('../../connection/connection.php');
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM super_user WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $namaUser = $seleksiKolom['nama'] ;

    /*php array untuk view akun*/
    $result = mysqli_query($connection,"SELECT * FROM akun"); //utk diambil jumlah row nya

    $jumlahbaris = mysqli_num_rows ( $result ); //ambil jumlah row
    $daftarakun = array(); /*utk tempat array utama*/
    /* info : array yg digunakan 2 dimensi */
    for($baris = 1 ; $baris <= $jumlahbaris ; $baris++){
        /*cari tipe entitas dari tabel utama dulu*/
        $seleksiRowCariTabel = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama = $baris");
        $seleksiKolomCariTabel = mysqli_fetch_assoc($seleksiRowCariTabel);
        $entitas = $seleksiKolomCariTabel['entitas'];
        /* sekarang baru pindah tabel*/
        /* superuser tidak ikut masuk */
        if($entitas !== 1){
            if ($entitas == 2){
                $seleksiRowEntitas = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = $baris");
                $seleksiKolomEntitas = mysqli_fetch_assoc($seleksiRowEntitas);
                $NRP_NIDN_NIP = $seleksiKolomEntitas['nidn'];
                $peran = "Dosen Pembimbing";
                /*bagian ini tambahkan detil data*/
                $nama = $seleksiKolomEntitas['nama'];
                $id_instansi = $seleksiKolomEntitas['instansi'];
                    $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$id_instansi."'");
                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
                    $instansi = $seleksiKolomInstansi['nama'];
                $nowa = $seleksiKolomEntitas['nowa'];
                $email = $seleksiKolomEntitas['email'];
                $id_utama = $baris;
                $detildata = array($id_utama,$nama,$NRP_NIDN_NIP,$peran,$instansi,$nowa,$email);
            	array_push($daftarakun,$detildata);
            }
            else if($entitas == 3){
                $seleksiRowEntitas = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = $baris");
                $seleksiKolomEntitas = mysqli_fetch_assoc($seleksiRowEntitas);
                $NRP_NIDN_NIP =$seleksiKolomEntitas['nip'];
                $peran = "Pembimbing Lapangan";
                /*bagian ini tambahkan detil data*/
                $nama = $seleksiKolomEntitas['nama'];
                $id_instansi = $seleksiKolomEntitas['instansi'];
                    $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$id_instansi."'");
                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
                    $instansi = $seleksiKolomInstansi['nama'];
                $nowa = $seleksiKolomEntitas['nowa'];
                $email = $seleksiKolomEntitas['email'];
                $id_utama = $baris;
                $detildata = array($id_utama,$nama,$NRP_NIDN_NIP,$peran,$instansi,$nowa,$email);
                /*append detil data ke array utama*/   
                array_push($daftarakun,$detildata);
            }
            else if($entitas == 4){
                $seleksiRowEntitas = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = $baris");
                $seleksiKolomEntitas = mysqli_fetch_assoc($seleksiRowEntitas);
                $NRP_NIDN_NIP = $seleksiKolomEntitas['nrp'];
                $peran = "Mahasiswa";
                /*bagian ini tambahkan detil data*/
                $nama = $seleksiKolomEntitas['nama'];
                $id_instansi = $seleksiKolomEntitas['instansi'];
                    $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$id_instansi."'");
                    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
                    $instansi = $seleksiKolomInstansi['nama'];
                $nowa = $seleksiKolomEntitas['nowa'];
                $email = $seleksiKolomEntitas['email'];
                $id_utama = $baris;
                $detildata = array($id_utama,$nama,$NRP_NIDN_NIP,$peran,$instansi,$nowa,$email);
                /*append detil data ke array utama*/
                array_push($daftarakun,$detildata);
            }
        }
    }

/* untuk value menampilkan berapa akun*/
$seleksiRowJumlahAkun = mysqli_query($connection, "SELECT * FROM total_entitas WHERE entitas = 9");
$seleksiKolomJumlahAkun = mysqli_fetch_assoc($seleksiRowJumlahAkun);
$jumlahAkun = $seleksiKolomJumlahAkun['jumlah'];
?>

<!DOCTYPE html>   
<html lang="en">   
<head>   
	<title>Magang Informatika</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width = device-width, initial-scale = 1">
   
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">   
	<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <link rel="stylesheet" href="../../css/superuser/akun.css">

    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
    <!-- script -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>  
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
			</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="perusahaan.php">Perusahaan</a>
                    </li>
                    <!--
                    <li class="nav-item">
                    	<a class="nav-link" href="pengajuan_perusahaan.php">Pengajuan Perusahaan</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="laporan_akhir.php">Laporan Akhir</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
					-->
                    <li class="nav-item active">
                    	<a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>  
	<div style ="padding-top:2em;padding-left:2em;padding-right:2em;">

        <table id="myTable" class="table table-striped" >  
            <thead>  
                <tr>  
                    <th>Nama</th>
                    <th>NRP / NIDN / NIP</th>
                    <th>Peran</th>
                    <th>Instansi</th>
                    <th>No WhatsApp</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>  
            </thead>  
            <tbody>  
            <?php
                $jumlah_akun = count($daftarakun);
                for($baris = 0 ; $baris < $jumlah_akun ; $baris++){?>
                    <tr>  
                    <td><?php echo $daftarakun[$baris][1]?></td>
                        <td><?php echo $daftarakun[$baris][2]?></td>
                        <td><?php echo $daftarakun[$baris][3]?></td>
                        <td><?php echo $daftarakun[$baris][4]?></td>
                        <td><?php echo $daftarakun[$baris][5]?></td>
                        <td><?php echo $daftarakun[$baris][6]?></td>
                        <td>
                        	<span><a href="#" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a></span>
                        	<span><a href="#" class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a></span>
                        </td>
                    </tr><?php 
                }?> 
            </tbody>  
        </table>  
	</div>
</body>  
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
