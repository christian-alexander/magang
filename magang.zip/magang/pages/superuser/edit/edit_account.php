<?php
	session_start();
    include('../../../connection/connection.php');
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $namaUser = $seleksiKolom['nama'] ;
    
    $seleksiTabel = mysqli_query($connection,"SELECT * FROM instansi");
    $banyakRow = mysqli_num_rows($seleksiTabel);
    $daftarInstansi = array();
    for($baris = 1 ; $baris <= $banyakRow ; $baris++){
    	$seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = $baris");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $namaInstansi = $seleksiKolomInstansi['nama'];
        $idInstansi = $seleksiKolomInstansi['id_instansi'];
        $detildata = array($namaInstansi,$idInstansi);
        array_push($daftarInstansi,$detildata);
    }

    $seleksiTabelDosBing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing");
    $banyakRowDosBing = mysqli_num_rows($seleksiTabelDosBing);
    $daftarDosBing = array();
    for($baris = 1 ; $baris <= $banyakRowDosBing ; $baris++){
    	$seleksiRowDosBing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id = $baris");
        $seleksiKolomDosBing = mysqli_fetch_assoc($seleksiRowDosBing);
        $namaDosbing = $seleksiKolomDosBing['nama'];
        $idDosbing = $seleksiKolomDosBing['id_utama'];
        $detildataDosBing = array($namaDosbing,$idDosBing);
        array_push($daftarDosBing,$detildataDosBing);
    }

    $seleksiTabelPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
    $banyakRowPemLap = mysqli_num_rows($seleksiTabelPemLap);
    $daftarPemLap = array();
    for($baris = 1 ; $baris <= $banyakRowPemLap ; $baris++){
    	$seleksiRowPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id = $baris");
        $seleksiKolomPemLap = mysqli_fetch_assoc($seleksiRowPemLap);
        $namaPemLap = $seleksiKolomPemLap['nama'];
        $idPemLap = $seleksiKolomPemLap['id_utama'];
        $detildataPemLap = array($namaPemLap,$idPemLap);
        array_push($daftarPemLap,$detildataPemLap);
    }


    //get entitas//
    $seleksiRowEntitas = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama ='".$_POST['dataEditValue']."'");
    $seleksiKolomEntitas = mysqli_fetch_assoc($seleksiRowEntitas);
    $entitas = $seleksiKolomEntitas['entitas'];

    //id_utama//
    $id_utama = $_POST['dataEditValue'];
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="../../../css/superuser/edit/edit_account.css">
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-expand-sm navbar-expand-xs navbar-dark bg-dark fixed-top" style="position:fixed;top:0;">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../instansi.php">Instansi</a>
                    </li>
                    <!--
                    <li class="nav-item">
                    	<a class="nav-link" href="pengajuan_perusahaan.php">Pengajuan Perusahaan</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="laporan_akhir.php">Laporan Akhir</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
					-->
                    <li class="nav-item active">
                    	<a class="nav-link" href="../akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
	</nav>
    
    
    <div class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Edit Akun</b>
            </div>			
            	
            <form method = "POST" action = "../../../process/superuser/edit/edit_account.php" onsubmit ="return verifikasi()">
                <div class="container" style="padding-left:2em;">
                    <div class = "row">
                    	<?php
                        if($entitas==2){?>
                            <?php 
                            $seleksiRowEntitas2 = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$_POST['dataEditValue']."'");
                            $seleksiKolomEntitas2 = mysqli_fetch_assoc($seleksiRowEntitas2);
                            $namaEntitas2 = $seleksiKolomEntitas2['nama'];
                            $nowaEntitas2 = $seleksiKolomEntitas2['nowa'];
                            $emailEntitas2 = $seleksiKolomEntitas2['email'];
                            $nidnEntitas2 = $seleksiKolomEntitas2['nidn'];
                            $instansiEntitas2 = $seleksiKolomEntitas2['instansi'];
                            ?>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Nama Lengkap<a id="warningNama" style="color:red;"></a>                            
                                <p>
                                    <input type = "text" name="nama" id="nama" class = "inside-box" value="<?php echo $namaEntitas2 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <a id="teksNRP">NIDN</a><a id="warningNRP" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="NRP" id="NRP" class = "inside-box" value="<?php echo $nidnEntitas2 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Email<a id="warningEmail" style="color:red;"></a>
                                <p>
                                    <input type = "text" name="email" id="email" class = "inside-box" value="<?php echo $emailEntitas2?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                No WhatsApp<a id="warningNowa" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="nowa" id="nowa" class = "inside-box" value="<?php echo $nowaEntitas2?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Peran<br>
                                <p>
                                    <input type = "text" name="peran" id="peran" class = "inside-box" value="Dosen Pembimbing" disabled>
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Instansi<br>
                                <select name = "instansi" class="selectpicker" data-live-search="true">
                                    <?php
                                    for($baris = 0 ; $baris < $banyakRow ; $baris++){
                                    	if($daftarInstansi[$baris][1] == $instansiEntitas2){?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>" selected><?php echo $daftarInstansi[$baris][0]?></option><?php
                                        }else{ ?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>"><?php echo $daftarInstansi[$baris][0]?></option><?php
                                    	}
                                    } ?>
                                </select>                            	
                            </div><?php
                        }else if($entitas==3){?>
                            <?php 
                            $seleksiRowEntitas3 = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan  WHERE id_utama = '".$_POST['dataEditValue']."'");
                            $seleksiKolomEntitas3 = mysqli_fetch_assoc($seleksiRowEntitas3);
                            $namaEntitas3 = $seleksiKolomEntitas3['nama'];
                            $nowaEntitas3 = $seleksiKolomEntitas3['nowa'];
                            $emailEntitas3 = $seleksiKolomEntitas3['email'];
                            $nipEntitas3 = $seleksiKolomEntitas3['nip'];
                            $instansiEntitas3 = $seleksiKolomEntitas3['instansi'];
                            ?>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Nama Lengkap<a id="warningNama" style="color:red;"></a>                            
                                <p>
                                    <input type = "text" name="nama" id="nama" class = "inside-box" value="<?php echo $namaEntitas3 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <a id="teksNRP">NRP</a><a id="warningNRP" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="NRP" id="NRP" class = "inside-box" value="<?php echo $nipEntitas3 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Email<a id="warningEmail" style="color:red;"></a>
                                <p>
                                    <input type = "text" name="email" id="email" class = "inside-box" value="<?php echo $emailEntitas3?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                No WhatsApp<a id="warningNowa" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="nowa" id="nowa" class = "inside-box" value="<?php echo $nowaEntitas3?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Peran<br>
                                <p>
                                    <input type = "text" name="peran" id="peran" class = "inside-box" value="Pembimbing Lapangan" disabled>
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Instansi<br>
                                <select name = "instansi" class="selectpicker" data-live-search="true">
                                    <?php
                                    for($baris = 0 ; $baris < $banyakRow ; $baris++){
                                    	if($daftarInstansi[$baris][1] == $instansiEntitas2){?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>" selected><?php echo $daftarInstansi[$baris][0]?></option><?php
                                        }else{ ?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>"><?php echo $daftarInstansi[$baris][0]?></option><?php
                                    	}
                                    } ?>
                                </select>
                            </div><?php
                        }else if($entitas==4){?>
                            <?php 
                            $seleksiRowEntitas4 = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$_POST['dataEditValue']."'");
                            $seleksiKolomEntitas4 = mysqli_fetch_assoc($seleksiRowEntitas4);
                            $namaEntitas4 = $seleksiKolomEntitas4['nama'];
                            $nowaEntitas4 = $seleksiKolomEntitas4['nowa'];
                            $emailEntitas4 = $seleksiKolomEntitas4['email'];
                            $nrpEntitas4 = $seleksiKolomEntitas4['nrp'];
                            $instansiEntitas4 = $seleksiKolomEntitas4['instansi'];
                            $dosenEntitas4 = $seleksiKolomEntitas4['dosenpembimbing'];
                            $pemlapEntitas4 = $seleksiKolomEntitas4['pembimbinglapangan'];
                            ?>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Nama Lengkap<a id="warningNama" style="color:red;"></a>                            
                                <p>
                                    <input type = "text" name="nama" id="nama" class = "inside-box" value="<?php echo $namaEntitas4 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <a id="teksNRP">NRP</a><a id="warningNRP" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="NRP" id="NRP" class = "inside-box" value="<?php echo $nrpEntitas4 ?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Email<a id="warningEmail" style="color:red;"></a>
                                <p>
                                    <input type = "text" name="email" id="email" class = "inside-box" value="<?php echo $emailEntitas4?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                No WhatsApp<a id="warningNowa" style="color:red;"></a>
                                <p>
                                    <input type = "tel" name="nowa" id="nowa" class = "inside-box" value="<?php echo $nowaEntitas4?>">
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Peran<br>
                                <p>
                                    <input type = "text" name="peran" id="peran" class = "inside-box" value="Mahasiswa" disabled>
                                </p>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Instansi<br>
                                <select name = "instansi" class="selectpicker" data-live-search="true">
                                    <?php
                                    for($baris = 0 ; $baris < $banyakRow ; $baris++){
                                    	if($daftarInstansi[$baris][1] == $instansiEntitas4){?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>" selected><?php echo $daftarInstansi[$baris][0]?></option><?php
                                        }else{ ?>
                                        	<option value="<?php echo $daftarInstansi[$baris][1]?>"><?php echo $daftarInstansi[$baris][0]?></option><?php
                                    	}
                                    } ?>
                                </select>
                            </div>  
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Dosen Pembimbing<br>
                                <select name = "dosen_pembimbing" class="selectpicker" data-live-search="true">
                                    <?php
                                    for($baris = 0 ; $baris < $banyakRowDosBing ; $baris++){
                                        if($daftarDosBing[$baris][1] == $dosenEntitas4){ ?>
                                        	<option value="<?php echo $daftarDosBing[$baris][1]?>" selected><?php echo $daftarDosBing[$baris][0]?></option><?php
                                        }else{ ?>
                                        	<option value="<?php echo $daftarDosBing[$baris][1]?>"><?php echo $daftarDosBing[$baris][0]?></option><?php
                                        }
                                    } ?>
                                </select>
                            </div>
                            <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                Pembimbing Lapangan<br>
                                <select name = "pembimbing_lapangan" class="selectpicker" data-live-search="true">
                                    <?php
                                    for($baris = 0 ; $baris < $banyakRowPemLap ; $baris++){
                                        if($daftarPemLap[$baris][1] == $pemlapEntitas4){?>
                                        	<option value="<?php echo $daftarPemLap[$baris][1]?>" selected><?php echo $daftarPemLap[$baris][0]?></option><?php
                                        }else{ ?>
                                        <option value="<?php echo $daftarPemLap[$baris][1]?>"><?php echo $daftarPemLap[$baris][0]?></option><?php
                                        }
                                    } ?>
                                </select>
                            </div><?php
                        } ?>
                    </div>
                    <div class="div-add">
                        <button type = "submit" class = "btn btn-success add">Edit</button>
                    </div>  
                    <div class="div-add" style="padding-top:0;">
                        <a href="#" class = "btn btn-danger add">Cancel</a>
                    </div>
                </div>
                <!-- untuk meneruskan id_utama dan entitas ke hlm brkutnya -->
                <input type = "text" name= "id_utama" value="<?php echo $id_utama ?>" style="display:none;">
				<input type = "text" name= "entitas" value="<?php echo $entitas ?>" style="display:none;">
			</form>
        </div>
    </div>	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
	
	<script src="../../../js/superuser/edit/verify_edit_account.js"></script>
	
</body>