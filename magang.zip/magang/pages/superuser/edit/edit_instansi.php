<?php
	session_start();
    include('../../../connection/connection.php');
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $namaUser = $seleksiKolom['nama'] ;
    
    //id_instansi//
    $id_instansi = $_POST['dataEditValue'];

    $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$_POST['dataEditValue']."'");
    $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
    $namaInstansi = $seleksiKolomInstansi['nama'];
    $notelpInstansi = $seleksiKolomInstansi['notelp'];
    $nofaxInstansi = $seleksiKolomInstansi['nofax'];
    $emailInstansi = $seleksiKolomInstansi['email'];
    $alamatInstansi = $seleksiKolomInstansi['alamat'];
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="../../../css/superuser/edit/edit_instansi.css">
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-expand-sm navbar-expand-xs navbar-dark bg-dark fixed-top" style="position:fixed;top:0;">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="../instansi.php">Instansi</a>
                    </li>
                    <!--
                    <li class="nav-item">
                    	<a class="nav-link" href="pengajuan_perusahaan.php">Pengajuan Perusahaan</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="laporan_akhir.php">Laporan Akhir</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
					-->
                    <li class="nav-item">
                    	<a class="nav-link" href="../akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
	</nav>
    
    
    <div class = "box" style="padding-top:5em;padding-bottom:5em;">
        <div class = "box2">
            <div class = teks-login>
                <b>Edit Instansi</b>
            </div>			
            	
            <form method = "POST" action = "../../../process/superuser/edit/edit_instansi.php" onsubmit ="return verifikasi()">
                <div class="container" style="padding-left:2em;">
                    <div class = "row">
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Nama Instansi<a id="warningNama" style="color:red;"></a>                            
                            <p>
                                <input type = "text" name="Nama" id="Nama" class = "inside-box" value="<?php echo $namaInstansi ?>">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No Telepon<a id="warningNoTelp" style="color:red;"></a>
                            <p>
                                <input type = "tel" name="NoTelp" id="NoTelp" class = "inside-box" value="<?php echo $notelpInstansi?>">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No Fax<a id="warningNoFax" style="color:red;"></a>
                            <p>
                                <input type = "tel" name="NoFax" id="NoFax" class = "inside-box" value="<?php echo $nofaxInstansi ?>">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Email<a id="warningEmail" style="color:red;"></a>
                            <p>
                                <input type = "text" name="Email" id="Email" class = "inside-box" value="<?php echo $emailInstansi?>">
                            </p>
                        </div>
                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            Alamat<a id="warningAlamat" style="color:red;"></a>
                            <p>
                                <input type = "text" name="Alamat" id="Alamat" class = "inside-box" value="<?php echo $alamatInstansi?>">
                            </p>
                        </div>
                    </div>
                    <div class="div-add">
                        <button type = "submit" class = "btn btn-success add">Edit</button>
                    </div>  
                    <div class="div-add" style="padding-top:0;">
                        <a href="../instansi.php" class = "btn btn-danger add">Cancel</a>
                    </div>
                </div>
                <!-- untuk meneruskan id_utama dan entitas ke hlm brkutnya -->
                <input type = "text" name= "id_instansi" value="<?php echo $id_instansi ?>" style="display:none;">
			</form>
        </div>
    </div>	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
	
	<script src="../../../js/superuser/edit/verify_edit_instansi.js"></script>
	
</body>