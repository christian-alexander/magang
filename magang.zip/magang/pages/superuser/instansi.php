<?php
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 1){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
    $seleksiTabelInstansi = mysqli_query($connection,"SELECT * FROM instansi");
    $jumlahTabelInstansi = mysqli_num_rows($seleksiTabelInstansi);
    $daftarInstansi = array();
    for($baris = 1 ; $baris <= $jumlahTabelInstansi ; $baris++){
        $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = $baris");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $nama = $seleksiKolomInstansi['nama'];
        $notelp = $seleksiKolomInstansi['notelp'];
        $nofax = $seleksiKolomInstansi['nofax'];
        $email = $seleksiKolomInstansi['email'];
        $alamat = $seleksiKolomInstansi['alamat'];
        $status = $seleksiKolomInstansi['status'];
        $timestamp = $seleksiKolomInstansi['timestamp'];
        $arr_timestamp = explode("-",$timestamp);
        $tahun = $arr_timestamp[0]; 
        $detilInstansi = array($baris,$nama,$notelp,$nofax,$email,$alamat,$status,$tahun);
        array_push($daftarInstansi,$detilInstansi);        
    }
?>

<!DOCTYPE html>   
<html lang="en">   
<head>   
	<title>Magang Informatika</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="widtd = device-widtd, initial-scale = 1">
   
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">   
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <link rel="stylesheet" href="../../css/superuser/instansi.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
    <!-- script -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>  
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
        
            <form action="add/add_instansi.php">
                <button class="btn btn-success" type="submit">Tambahkan Instansi</button>
            </form>
    
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="instansi.php">Instansi</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>  
	<div style ="padding-top:3em;padding-left:2em;padding-right:2em;text-align:center;">
    <h3><p style="margin-top:2em;margin-bottom:1em;">Daftar Instansi</p></h3>
        <table id="myTable" class="table table-striped" >  
        <thead>  
                <tr>  
                    <th>Tahun</th>
                    <th>Nama Instansi</th>
                    <th>No Telepon</th>
                    <th>No Fax</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>  
            <tbody><?php
            	for($baris = 0 ; $baris < count($daftarInstansi) ; $baris++){ ?>
                    <tr>  
                        <td><?php echo $daftarInstansi[$baris][7]?></td>
                        <td><?php echo $daftarInstansi[$baris][1]?></td>
                        <td><?php echo $daftarInstansi[$baris][2]?></td>
                        <td><?php echo $daftarInstansi[$baris][3]?></td>
                        <td><?php echo $daftarInstansi[$baris][4]?></td>
                        <td><?php echo $daftarInstansi[$baris][5]?></td>
                        <td style="white-space:nowrap;">
                            <?php 
                            if($daftarInstansi[$baris][6] == "on"){ ?>
                            	<a style = "display : none">1</a>
                                <form class ="tombol" method="POST" action="edit/edit_instansi.php" onsubmit ="getIdentitasEdit<?php echo $daftarInstansi[$baris][0] ?>()">
                                    <a href="#" class="edit" title="Edit" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">edit</i></button></a>
                                    <input type="text" id="dataEditValue<?php echo $daftarInstansi[$baris][0] ?>" name="dataEditValue" value="" style="display:none;">
                                    <script>
                                        function getIdentitasEdit<?php echo $daftarInstansi[$baris][0] ?>(){
                                            var dataEditValue<?php echo $daftarInstansi[$baris][0] ?> = document.getElementById("dataEditValue<?php echo $daftarInstansi[$baris][0] ?>");
                                            dataEditValue<?php echo $daftarInstansi[$baris][0] ?>.value = "<?php echo $daftarInstansi[$baris][0] ?>";
                                        }
                                    </script>
                                </form>
                                <form class ="tombol" method="POST" action="../../process/superuser/delete/delete_instansi.php" onsubmit ="return getIdentitasDelete<?php echo $daftarInstansi[$baris][0] ?>()">
                                    <a href="#" class="delete" title="NonAktifkan" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">delete</i></button></a> 
                                    <input type="text" id="dataDeleteValue<?php echo $daftarInstansi[$baris][0] ?>" name="dataDeleteValue" value="" style="display:none;">
                                    <script>
                                        function getIdentitasDelete<?php echo $daftarInstansi[$baris][0] ?>(){
                                            if (confirm("Yakin non-aktifkan Instansi <?php echo $daftarInstansi[$baris][1]?> ?")){
                                                var dataDeleteValue<?php echo $daftarInstansi[$baris][0] ?> = document.getElementById("dataDeleteValue<?php echo $daftarInstansi[$baris][0] ?>");
                                                dataDeleteValue<?php echo $daftarInstansi[$baris][0] ?>.value = "<?php echo $daftarInstansi[$baris][0] ?>";
                                        		return true;
                                            }else{
                                                return false;
                                            }
                                        }
                                    </script>
                                </form><?php 
                            }else{ ?>
                                <a style = "display : none">2</a>
                                <form class ="tombol" method="POST" action="edit/edit_instansi.php" onsubmit ="getIdentitasEdit<?php echo $daftarInstansi[$baris][0] ?>()">
                                    <a href="#" class="edit" title="Edit" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">edit</i></button></a>
                                    <input type="text" id="dataEditValue<?php echo $daftarInstansi[$baris][0] ?>" name="dataEditValue" value="" style="display:none;">
                                    <script>
                                        function getIdentitasEdit<?php echo $daftarInstansi[$baris][0] ?>(){
                                            var dataEditValue<?php echo $daftarInstansi[$baris][0] ?> = document.getElementById("dataEditValue<?php echo $daftarInstansi[$baris][0] ?>");
                                            dataEditValue<?php echo $daftarInstansi[$baris][0] ?>.value = "<?php echo $daftarInstansi[$baris][0] ?>";
                                        }
                                    </script>
                                </form>
                                <form class ="tombol" method="POST" action="../../process/superuser/delete/restore_instansi.php" onsubmit ="return getIdentitasRestore<?php echo $daftarInstansi[$baris][0] ?>()">
                                    <a href="#" class="restore" title="Aktifkan" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">restore_from_trash</i></button></a>
                                    <input type="text" id="dataRestoreValue<?php echo $daftarInstansi[$baris][0] ?>" name="dataRestoreValue" value="" style="display:none;">
                                    <script>
                                        function getIdentitasRestore<?php echo $daftarInstansi[$baris][0] ?>(){
                                            if (confirm("Yakin aktifkan Instansi <?php echo $daftarInstansi[$baris][1]?> ?")){
                                                var dataRestoreValue<?php echo $daftarInstansi[$baris][0] ?> = document.getElementById("dataRestoreValue<?php echo $daftarInstansi[$baris][0] ?>");
                                                dataRestoreValue<?php echo $daftarInstansi[$baris][0] ?>.value = "<?php echo $daftarInstansi[$baris][0] ?>";
                                                return true;
                                            }else{
                                                return false;
                                            }
                                        }
                                    </script>
                                </form><?php 
                            } ?>
                        </td>
                    </tr><?php
                } ?>
            </tbody>  
        </table>  
    </div>
</body>  
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>
