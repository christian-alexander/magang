<?php
    session_start();
    include('../../connection/connection.php');
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $namaUser = $seleksiKolom['nama'] ;

    //untuk tabel boi//
    $seleksiTabelMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa");
    $banyakRowMahasiswa = mysqli_num_rows($seleksiTabelMahasiswa);
    $daftarMahasiswa = array();
    for ($baris = 1 ; $baris <= $banyakRowMahasiswa ; $baris++){
        $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id = $baris");
        $seleksiKolomMahasiswa = mysqli_fetch_assoc($seleksiRowMahasiswa);
        $id_utama = $seleksiKolomMahasiswa['id_utama'];
        $nama = $seleksiKolomMahasiswa['nama'];
        
        $nrp = $seleksiKolomMahasiswa['nrp'];
        
        $idInstansi = $seleksiKolomMahasiswa['instansi'];
        $seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi WHERE id_instansi = '".$idInstansi."'");
        $seleksiKolomInstansi = mysqli_fetch_assoc($seleksiRowInstansi);
        $instansi = $seleksiKolomInstansi['nama'];
        
        $nowa = $seleksiKolomMahasiswa['nowa'];
        $email = $seleksiKolomMahasiswa['email'];
        
        $idDosenPembimbing = $seleksiKolomMahasiswa['dosenpembimbing'];

        $seleksiRowDosenPembimbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing WHERE id_utama = '".$idDosenPembimbing."'");
        $seleksiKolomDosenPembimbing = mysqli_fetch_assoc($seleksiRowDosenPembimbing);
        $dosenpembimbing = $seleksiKolomDosenPembimbing['nama'];
        

        $idPembimbingLapangan = $seleksiKolomMahasiswa['pembimbinglapangan'];
        if($idPembimbingLapangan==""){
            $pembimbinglapangan="Tidak Ada";
        }else{
            $seleksiRowPembimbingLapangan = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan WHERE id_utama = '".$idPembimbingLapangan."'");
            $seleksiKolomPembimbingLapangan = mysqli_fetch_assoc($seleksiRowPembimbingLapangan);
            $pembimbinglapangan = $seleksiKolomPembimbingLapangan['nama'];
        }
    
        $detilPermintaan = array($id_utama,$nama,$nrp,$instansi,$nowa,$email,$dosenpembimbing,$pembimbinglapangan);
        array_push($daftarMahasiswa,$detilPermintaan);
    
    }
?>

<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../../css/superuser/mahasiswa.css">
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="../../css/table/fl_table.css">
    <!-- utk icon -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="instansi.php">Instansi</a>
                    </li>
                    <!--
                    <li class="nav-item">
                    	<a class="nav-link" href="pengajuan_perusahaan.php">Pengajuan Perusahaan</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="laporan_akhir.php">Laporan Akhir</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="permintaan_sign_up.php">Permintaan Sign Up</a>
                    </li>
					-->
                    <li class="nav-item">
                    	<a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <iframe style="width: 100%; height: 1000px;" src="tabelmahasiswa.php"></iframe>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script src="../../js/superuser/mahasiswa.js"></script>
</body>