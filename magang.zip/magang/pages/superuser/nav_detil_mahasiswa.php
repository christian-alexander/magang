<?php 
    session_start();
    include('../../connection/connection.php');
    //cek valid login
    if(isset($_SESSION['loggedUser'])){
        $loggedUser = $_SESSION['loggedUser'] ;
        $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
        $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
        $entitasLoggedUser = $seleksiKolom['entitas'];
        if($entitasLoggedUser != 1){
            header("Location: ../../index.php");    
        }else{
            $namaUser = $seleksiKolom['nama'] ;
        } 
    }else{
        header("Location: ../../index.php");
    }
    if(isset($_POST['dataValue'])){
        $dataMhs = $_POST['dataValue'];
        $seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$_POST['dataValue']."'");
        $seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
        $idStatus = $seleksiKolomStatus['id_status'];
        if($idStatus < 5){
            $idStatusBerikutnya = $idStatus + 1 ;
            $seleksiRowIdStatus = mysqli_query($connection,"SELECT * FROM nama_status_magang WHERE id_status = '".$idStatusBerikutnya."'");
            $seleksiKolomIdStatus = mysqli_fetch_assoc($seleksiRowIdStatus);
            $statusBerikutnya = $seleksiKolomIdStatus['nama'];
        }
    }
?>
<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <!-- Navigation -->
    <!-- tambahkan navbar-expand-lg utk expand -->
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <?php echo $namaUser ?>
            </a><?php
            if(isset($_POST['dataValue'])){ ?>
                <form method = "POST" action = "../../process/update_status/update_status.php" onsubmit = "return konfirmasi()" >
                    <input type = "text" name = "idUtama" value = "<?php echo $_POST['dataValue'] ?>" style = "display:none;">
                    <input type = "text" name = "idStatus" value = "<?php echo $idStatus ?>" style = "display : none ;">
                    <?php 
                    if($idStatus < 5){ ?>
                        <button class="btn btn-success add" type="submit">Update Status</button><?php
                    }else if($idStatus == 5){ ?>
                        <button class="btn btn-success add" type="submit" disabled>Update Status</button><?php
                    } ?>                
                </form><?php
            } ?>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="mahasiswa.php">Mahasiswa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="instansi.php">Instansi</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="akun.php">Akun</a>
                    </li>
                    <li class="nav-item">
                    	<a class="nav-link" href="../../index.php">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><?php 
    if(isset($_POST['dataValue'])){
        header("Location: ");
        include("../../pages/detil_mahasiswa/detil_mahasiswa.php");
    }
    else if(isset($_POST['id_utama'])){
        header("Location: ");
        include("../../pages/detil_mahasiswa/detail_absen.php"); 
    } ?> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        function konfirmasi(){
            if(confirm("Apakah anda yakin mengupdate status mahasiswa ini ke status berikutnya (<?php echo $statusBerikutnya?>) ? \n\nPERHATIAN : Status tidak dapat dikembalikan ke status sebelumnya.")){
                return true ;
            }else{
                return false;
            }
        }
    </script>
</body>