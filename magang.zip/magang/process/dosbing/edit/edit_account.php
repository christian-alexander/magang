<?php

include("../../../connection/connection.php");
$id_utama = $_POST['id_utama'];
$nama = $_POST['nama'];
$nowa = $_POST['nowa'];
$email = $_POST['email'];
$nidn = $_POST['NRP'];
$instansi = $_POST['instansi'];
mysqli_query($connection,"UPDATE `dosen_pembimbing` SET `email` = '$email', `nama` = '$nama', `nidn` = '$nidn', `nowa` = '$nowa', `instansi` = '$instansi' WHERE `dosen_pembimbing`.`id_utama` = '".$id_utama."'");
mysqli_query($connection,"UPDATE `akun` SET `nama` = '$nama' WHERE `id_utama` = '".$id_utama."'");

?>

<script>
    
	alert("Sukses Mengedit Akun");
 	window.location= "../../../pages/dosbing/akun.php";
	
</script>
