<?php
session_start();
include("../../connection/connection.php");
$loggedUser = $_SESSION['loggedUser'];


$tanggal = htmlspecialchars($_POST['tanggal']);
$jam_masuk = htmlspecialchars($_POST['jam_masuk']);
$jam_pulang = htmlspecialchars($_POST['jam_pulang']);
$uraian_kegiatan = htmlspecialchars($_POST['uraian_kegiatan']);

$seleksiTabelDataAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$loggedUser." ");
$jumlahRowDataAbsen = mysqli_num_rows($seleksiTabelDataAbsen);
$id_absen = $jumlahRowDataAbsen + 1 ;

$seleksiTabelDataFile = mysqli_query($connection,"SELECT * FROM _data_file_absen_mhs".$loggedUser." ");
$jumlahRowDataFile = mysqli_num_rows($seleksiTabelDataFile);
$id_file = $jumlahRowDataFile + 1;

$jumlahFile = htmlspecialchars($_POST['jumlahFile']);
for($baris = 0 ; $baris < $jumlahFile ; $baris++){
    $namafile = $_FILES['files']['name'][$baris];
    $tmpname = $_FILES['files']['tmp_name'][$baris];

    move_uploaded_file($tmpname,'../../filepool/' . $namafile);

    $tes = mysqli_query($connection,"INSERT INTO _data_file_absen_mhs".$loggedUser." (id_file,id_absen,file)VALUES('$id_file','$id_absen','$namafile')");
   
    $id_file++ ;
}

mysqli_query($connection,"INSERT INTO _data_absen_mhs".$loggedUser." (id_absen,tanggal,jam_masuk,jam_pulang,uraian_kegiatan)VALUES('$id_absen','$tanggal','$jam_masuk','$jam_pulang','$uraian_kegiatan')");

?>

<script>
    alert("Absen berhasil diajukan. Hubungi Pembimbing Lapangan anda untuk memohon validasi.");
    window.location = "../../pages/mahasiswa/absen.php"
</script>