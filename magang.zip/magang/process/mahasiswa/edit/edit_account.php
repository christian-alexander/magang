<?php

include("../../../connection/connection.php");
//cek apabila ada dobelan akun
foreach($seleksiAkun as $row){
    if($row['status'] == "on"){
        if($row['email'] == $_POST['email'] and $_POST['email'] != $_POST['emailLama']){
            $emailDobel = TRUE ;
            break ;
        }
    }
}

if($emailDobel == FALSE){
	$id_utama = $_POST['id_utama'];
	$nama = $_POST['nama'];
	$nowa = $_POST['nowa'];
	$email = $_POST['email'];
	$nrp = $_POST['NRP'];
	$instansi = $_POST['instansi'];
	$DosBing = $_POST['dosen_pembimbing'];
	$PemLap = $_POST['pembimbing_lapangan'];
	mysqli_query($connection,"UPDATE `mahasiswa` SET `email` = '$email', `nama` = '$nama', `nrp` = '$nrp', `nowa` = '$nowa', `instansi` = '$instansi' ,`dosenpembimbing` = '$DosBing', `pembimbinglapangan` = '$PemLap' WHERE `mahasiswa`.`id_utama` = '".$id_utama."'");
	mysqli_query($connection,"UPDATE `akun` SET `nama` = '$nama' , `email` = '$email' WHERE `id_utama` = '".$id_utama."'");


	?>

	<script>
		
		alert("Sukses Mengedit Akun");
		window.location= "../../../pages/mahasiswa/akun.php";
		
	</script><?php
}else{ ?>
	<script>
        alert("Email sudah terdaftar di sistem. Harap gunakan email lain");
        window.location= "../../../pages/mahasiswa/akun.php";
    </script><?php
} ?>

