<?php
session_start();
include("../../connection/connection.php");
$loggedUser = $_SESSION['loggedUser'];

// mematikan file lama dulu baru uplod2
mysqli_query($connection,"UPDATE file_laporan SET `status` = 'off' WHERE id_utama = '".$loggedUser."'");


$seleksiTabelDataFile = mysqli_query($connection,"SELECT * FROM file_laporan");
$jumlahRowDataFile = mysqli_num_rows($seleksiTabelDataFile);
$id_file = $jumlahRowDataFile + 1;

$jumlahFile1 = htmlspecialchars($_POST['jumlahFile1']);
for($baris = 0 ; $baris < $jumlahFile1 ; $baris++){
    $namafile = $_FILES['files1']['name'][$baris];
    $tmpname = $_FILES['files1']['tmp_name'][$baris];

    move_uploaded_file($tmpname,'../../filepool_laporan/' . $namafile);
    mysqli_query($connection,"INSERT INTO file_laporan (`id_file`,`id_utama`,`jenis_laporan`,`file`)VALUES('$id_file','$loggedUser',1,'$namafile')");

    $id_file++ ;

} 

$jumlahFile2 = htmlspecialchars($_POST['jumlahFile2']);
for($baris = 0 ; $baris < $jumlahFile2 ; $baris++){
    $namafile = $_FILES['files2']['name'][$baris];
    $tmpname = $_FILES['files2']['tmp_name'][$baris];

    move_uploaded_file($tmpname,'../../filepool_laporan/' . $namafile);

    mysqli_query($connection,"INSERT INTO file_laporan (`id_file`,`id_utama`,`jenis_laporan`,`file`)VALUES('$id_file','$loggedUser',2,'$namafile')");

    $id_file++ ;
}


$jumlahFile3 = htmlspecialchars($_POST['jumlahFile3']);
for($baris = 0 ; $baris < $jumlahFile3 ; $baris++){
    $namafile = $_FILES['files3']['name'][$baris];
    $tmpname = $_FILES['files3']['tmp_name'][$baris];

    move_uploaded_file($tmpname,'../../filepool_laporan/' . $namafile);

    mysqli_query($connection,"INSERT INTO file_laporan (`id_file`,`id_utama`,`jenis_laporan`,`file`)VALUES('$id_file','$loggedUser',3,'$namafile')");

    $id_file++ ;

}

?>

<script>
    alert("File berhasil di upload");
    window.location = "../../pages/mahasiswa/laporan.php";
</script>