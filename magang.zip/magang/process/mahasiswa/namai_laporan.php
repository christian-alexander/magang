<?php
session_start();
include("../../connection/connection.php");
$loggedUser = $_SESSION['loggedUser'];

$seleksiDataLaporan = mysqli_query($connection,"SELECT * FROM data_laporan");
$jumlahRowLaporan = mysqli_num_rows($seleksiDataLaporan);
$id_laporan = $jumlahRowLaporan + 1 ;

$judulLaporan = $_POST['judulLaporan'];

mysqli_query($connection,"INSERT INTO data_laporan (`id_laporan`,`id_utama`,`judul_laporan`,`nilai_dosbing`,`nilai_pemlap`,`komentar_dosbing`,`komentar_pemlap`) VALUES ('$id_laporan','$loggedUser','$judulLaporan',0,0,'','') ");
header("Location: ../../pages/mahasiswa/laporan.php")
?>