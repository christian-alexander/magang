<?php
session_start();
include('../../connection/connection.php');
//cek valid login
if(isset($_SESSION['loggedUser'])){
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $entitasLoggedUser = $seleksiKolom['entitas'];
    if($entitasLoggedUser != 3){
        header("Location: ../../index.php");    
    }else{
        $namaUser = $seleksiKolom['nama'] ;
    } 
}else{
    header("Location: ../../index.php");
}

$id_utama = $_POST['dataValueIdUtama'];
$id_absen = $_POST['dataValueIdAbsen'];

$seleksiRowAbsen = mysqli_query($connection,"SELECT * FROM _data_absen_mhs".$id_utama." ");
foreach($seleksiRowAbsen as $row){
    if($row['id_absen'] == $id_absen){
        $jamPulang = strtotime($row['jam_pulang']);
        $jamMasuk = strtotime($row['jam_masuk']);
        $penambahanJam = $jamPulang - $jamMasuk ;
        
        $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa WHERE id_utama = '".$id_utama."'");
        $seleksiKolomMahasiswa = mysqli_fetch_assoc($seleksiRowMahasiswa);
        $jamSebelumnya = $seleksiKolomMahasiswa['jam_magang'];

        $jamMagang = $jamSebelumnya + $penambahanJam ;
        
        mysqli_query($connection,"UPDATE mahasiswa SET jam_magang = '$jamMagang' WHERE id_utama = '".$id_utama."'");
    }
}

mysqli_query($connection,"UPDATE _data_absen_mhs".$id_utama." SET status = 'Disetujui' WHERE id_absen = '".$id_absen."'");



?>


<script>
    alert("Sukses Menerima Permintaan Absen")
    window.location = "../../pages/pemlap/permintaan_absen.php"
</script>