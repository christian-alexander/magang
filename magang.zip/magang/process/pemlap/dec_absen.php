<?php
session_start();
include('../../connection/connection.php');
//cek valid login
if(isset($_SESSION['loggedUser'])){
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $entitasLoggedUser = $seleksiKolom['entitas'];
    if($entitasLoggedUser != 3){
        header("Location: ../../index.php");    
    }else{
        $namaUser = $seleksiKolom['nama'] ;
    } 
}else{
    header("Location: ../../index.php");
}

$id_utama = $_POST['dataValueIdUtama'];
$id_absen = $_POST['dataValueIdAbsen'];

mysqli_query($connection,"UPDATE _data_absen_mhs".$id_utama." SET status = 'Ditolak' WHERE id_absen = '".$id_absen."'");

?>



<script>
    alert("Sukses Menolak Permintaan Absen")
    window.location = "../../pages/pemlap/permintaan_absen.php"
</script>