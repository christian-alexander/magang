<?php

include("../../../connection/connection.php");

$id_utama = $_POST['id_utama'];
$nama = $_POST['nama'];
$nowa = $_POST['nowa'];
$email = $_POST['email'];
$nip = $_POST['NRP'];
$instansi = $_POST['instansi'];
mysqli_query($connection,"UPDATE `pembimbing_lapangan` SET `email` = '$email', `nama` = '$nama', `nip` = '$nip', `nowa` = '$nowa', `instansi` = '$instansi' WHERE `pembimbing_lapangan`.`id_utama` = '".$id_utama."'");
mysqli_query($connection,"UPDATE `akun` SET `nama` = '$nama',`email` = '$email' WHERE `id_utama` = '".$id_utama."'");


?>

<script>
    
	alert("Sukses Mengedit Akun");
 	window.location= "../../../pages/pemlap/akun.php";
	
</script>
