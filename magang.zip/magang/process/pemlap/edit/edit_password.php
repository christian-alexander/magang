<?php
session_start();
include("../../../connection/connection.php");
$loggedUser = $_SESSION['loggedUser'];
$password = $_POST['password'];
$tes = mysqli_query($connection,"UPDATE akun SET password = '$password' WHERE id_utama = '".$loggedUser."'" );
?>

<script>
    alert("Password Berhasil Diubah");
    window.location = "../../../pages/pemlap/akun.php";
</script>