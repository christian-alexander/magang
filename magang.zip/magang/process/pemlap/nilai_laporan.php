<?php
session_start();
include('../../connection/connection.php');

//cek valid login
if(isset($_SESSION['loggedUser'])){
    $loggedUser = $_SESSION['loggedUser'] ;
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = '".$loggedUser."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $entitasLoggedUser = $seleksiKolom['entitas'];
    if($entitasLoggedUser != 3){
        header("Location: ../../index.php");    
    }else{
        $namaUser = $seleksiKolom['nama'] ;
    } 
}else{
    header("Location: ../../index.php");
}


$id_utama = $_POST['id_utama'];
$komentar = $_POST['komentar'];
$nilai = $_POST['nilai'];


mysqli_query($connection,"UPDATE data_laporan SET komentar_pemlap = '$komentar',nilai_pemlap = '$nilai' WHERE id_utama = '".$id_utama."' ");



?>

<script>
	alert('Sukses menambahkan penialian');
    window.location = "../../pages/pemlap/laporan.php";
</script>