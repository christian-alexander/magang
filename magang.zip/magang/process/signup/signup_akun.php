<?php 
include('../../connection/connection.php');
$seleksiTabelWaitingList = mysqli_query($connection, "SELECT * FROM sign_up_akun");
$jumlahRow = mysqli_num_rows($seleksiTabelWaitingList);
$id= $jumlahRow+1;
$entitas = $_POST['peran'];
$nama = $_POST['nama'];
$nrp= $_POST['NRP'];
$email = $_POST['email'];
$password = $_POST['password'];
$nowa= $_POST['nowa'];
$instansi= $_POST['instansi'];
$dosen_pembimbing= $_POST['dosen_pembimbing'];
$pembimbing_lapangan = $_POST['pembimbing_lapangan'];
if($entitas == 4){
    mysqli_query($connection,"INSERT INTO `sign_up_akun` (`id`, `nama`, `nrp`, `email`, `password`, `nowa`, `instansi`, `entitas`,`dosenpembimbing`,`pembimbinglapangan`) VALUES ('$id','$nama', '$nrp', '$email', '$password', '$nowa', '$instansi', '$entitas', '$dosen_pembimbing', '$pembimbing_lapangan')");
}else if($entitas == 3){
    mysqli_query($connection,"INSERT INTO `sign_up_akun` (`id`, `nama`, `nrp`, `email`, `password`, `nowa`, `instansi`, `entitas`,`dosenpembimbing`,`pembimbinglapangan`) VALUES ('$id','$nama', '$nrp', '$email', '$password', '$nowa', '$instansi', '$entitas', '', '')");

}
?>

<script>
    alert("Sukses Mengajukan Permintaan Sign Up");
    window.location = "../../index.php";
</script>