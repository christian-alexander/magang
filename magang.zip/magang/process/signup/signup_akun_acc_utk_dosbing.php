<?php
	include('../../connection/connection.php');
    $idSignUp = $_POST['dataAcceptValue'];
    $seleksiRow = mysqli_query($connection,"SELECT * FROM sign_up_akun WHERE id = '".$idSignUp."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $nama = $seleksiKolom['nama'];
    $nowa = $seleksiKolom['nowa'];
    $instansi = $seleksiKolom['instansi'];
    $email = $seleksiKolom['email'];
    $nrp = $seleksiKolom['nrp'];
    $entitas = $seleksiKolom['entitas'];
    $password = $seleksiKolom['password'];
    $dosenpembimbing = $seleksiKolom['dosenpembimbing'];
    $pembimbinglapangan = $seleksiKolom['pembimbinglapangan'];
    if ($entitas == 3){
		$seleksiTabelPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
        $jumlahRowPemLap = mysqli_num_rows($seleksiTabelPemLap);
        $id = $jumlahRowPemLap + 1 ;
        $seleksiTabelUtama = mysqli_query($connection,"SELECT * FROM akun");
        $jumlahRowUtama = mysqli_num_rows($seleksiTabelUtama);
        $id_utama = $jumlahRowUtama + 1;

        $seleksiRowPemlap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
        $jumlahRowPemlap = mysqli_num_rows($seleksiRowPemlap);
        $id = $jumlahRowPemlap + 1 ;

        mysqli_query($connection,"INSERT INTO `pembimbing_lapangan` (`id`,`id_utama`, `nama`, `nowa`, `email`, `nip`, `instansi`) VALUES ('$id','$id_utama', '$nama', '$nowa', '$email', '$nrp','$instansi')");
        mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`) VALUES ('$id_utama','$nama', '3', '$password', '$email')");
    }else{
		$seleksiTabelMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa");
        $jumlahRowMahasiswa = mysqli_num_rows($seleksiTabelMahasiswa);
        $id = $jumlahRowMahasiswa + 1 ;
        $seleksiTabelUtama = mysqli_query($connection,"SELECT * FROM akun");
        $jumlahRowUtama = mysqli_num_rows($seleksiTabelUtama);
        $id_utama = $jumlahRowUtama + 1;

        $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa");
        $jumlahRowMahasiswa = mysqli_num_rows($seleksiRowMahasiswa);
        $id = $jumlahRowMahasiswa + 1 ;

        mysqli_query($connection,"INSERT INTO `mahasiswa` (`id`,`id_utama`, `nama`, `nowa`, `email`, `nrp`, `instansi`,`dosenpembimbing`,`pembimbinglapangan`) VALUES ('$id','$id_utama', '$nama', '$nowa', '$email', '$nrp','$instansi','$dosenpembimbing','$pembimbinglapangan')");
        mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`) VALUES ('$id_utama','$nama', '4', '$password', '$email')");
        mysqli_query($connection,"INSERT INTO `status_magang` (`id_utama`) VALUES ('$id_utama') ");
    	mysqli_query($connection,"CREATE TABLE `magang`.`_data_absen_mhs".$id_utama."` ( `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , `id_absen` INT NOT NULL , `tanggal` DATE NOT NULL , `jam_masuk` CHAR(50) NOT NULL , `jam_pulang` CHAR(50) NOT NULL , `uraian_kegiatan` TEXT NOT NULL,`status` CHAR(20) NOT NULL DEFAULT 'Diajukan' , PRIMARY KEY (`id_absen`)) ENGINE = InnoDB;");
    
        mysqli_query($connection,"CREATE TABLE `magang`.`_data_file_absen_mhs".$id_utama."` ( `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , `id_file` INT NOT NULL , `id_absen` INT NOT NULL , `file` VARCHAR(1000) NOT NULL,`status` , PRIMARY KEY (`id_file`)) ENGINE = InnoDB;");
        
    
    }

    mysqli_query($connection,"UPDATE `sign_up_akun` SET `status` = 'off' WHERE `sign_up_akun`.`id` = '".$idSignUp."'");
    
    /*
    $pesan = "Akun anda untuk web-based Kerja Praktek Teknik Informatika Telah Disetujui. Silahkan login dengan email ";
    $pesan.=$email;

    ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = "admin@christianalex.xyz";
    $to = $email;
    $subject = "Akun KP UWIKA Telah Aktif";
    $message = $pesan ;
    $headers = "From:" . $from;
    mail($to,$subject,$message, $headers);
    */
?>
<script>
	alert('sukses menambahkan akun');
    window.location = "../../pages/dosbing/permintaan_sign_up.php";
</script>