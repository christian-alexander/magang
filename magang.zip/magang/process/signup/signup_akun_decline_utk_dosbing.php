<?php
    include('../../connection/connection.php');
    $id = $_POST['dataDeclineValue'];
	mysqli_query($connection,"UPDATE `sign_up_akun` SET `status` = 'off' WHERE `sign_up_akun`.`id` = '".$id."'");
?>
<script>
	alert('sukses menolak akun');
    window.location = "../../pages/dosbing/permintaan_sign_up.php";
</script>