<?php 
include('../../connection/connection.php');
$seleksiTabelWaitingList = mysqli_query($connection, "SELECT * FROM sign_up_instansi");
$jumlahRow = mysqli_num_rows($seleksiTabelWaitingList);
$id= $jumlahRow+1;
$nama = $_POST['Nama'];
$notelp = $_POST['NoTelp'];
$nofax = $_POST['NoFax'];
$email = $_POST['Email'];
$alamat = $_POST['Alamat'];
mysqli_query($connection,"INSERT INTO `sign_up_instansi` (`id`, `nama`, `notelp`, `nofax`, `email`, `alamat`) VALUES ('$id','$nama', '$notelp', '$alamat', '$email','$alamat')");
?>

<script>
    alert("Sukses Mengajukan Permintaan Instansi");
    window.location = "../../index.php";
</script>