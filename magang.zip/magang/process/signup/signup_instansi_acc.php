<?php
	include('../../connection/connection.php');
    $id = $_POST['dataAcceptInstansiValue'];
    $seleksiRow = mysqli_query($connection,"SELECT * FROM sign_up_instansi WHERE id = '".$id."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $nama = $seleksiKolom['nama'];
    $notelp = $seleksiKolom['notelp'];
    $nofax = $seleksiKolom['nofax'];
    $email = $seleksiKolom['email'];
    $alamat = $seleksiKolom['alamat'];
    

    mysqli_query($connection,"INSERT INTO `instansi` (`nama`, `notelp`, `nofax`, `email`, `alamat`) VALUES ($nama', '$notelp', '$nofax', '$email', '$alamat')");
	mysqli_query($connection,"UPDATE `sign_up_instansi` SET `status` = 'off' WHERE `sign_up_instansi`.`id` = '".$id."'");
?>
<script>
	alert('sukses menambahkan instansi');
    window.location = "../../pages/superuser/home.php";
</script>