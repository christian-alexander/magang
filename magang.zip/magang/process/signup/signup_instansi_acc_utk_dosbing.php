<?php
	include('../../connection/connection.php');
    $id = $_POST['dataAcceptInstansiValue'];
    $seleksiRow = mysqli_query($connection,"SELECT * FROM sign_up_instansi WHERE id = '".$id."'");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    $nama = $seleksiKolom['nama'];
    $notelp = $seleksiKolom['notelp'];
    $nofax = $seleksiKolom['nofax'];
    $email = $seleksiKolom['email'];
    $alamat = $seleksiKolom['alamat'];
    
    $seleksiTabelInstansi = mysqli_query($connection,"SELECT * FROM instansi");
    $jumlahRowInstansi = mysqli_num_rows($seleksiTabelInstansi);
    $idInstansi = $jumlahRowInstansi + 1 ;

    mysqli_query($connection,"INSERT INTO `instansi` (`id_instansi`, `nama`, `notelp`, `nofax`, `email`, `alamat`) VALUES ('$idInstansi','$nama', '$notelp', '$nofax', '$email', '$alamat')");
	mysqli_query($connection,"UPDATE `sign_up_instansi` SET `status` = 'off' WHERE `sign_up_instansi`.`id` = '".$id."'");
?>
<script>
	alert('sukses menambahkan instansi');
    window.location = "../../pages/dosbing/permintaan_sign_up.php";
</script>