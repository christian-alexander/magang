<?php
    include('../../connection/connection.php');
    $id = $_POST['dataDeclineInstansiValue'];
	mysqli_query($connection,"UPDATE `sign_up_instansi` SET `status` = 'off' WHERE `sign_up_instansi`.`id` = '".$id."'");
?>
<script>
	alert('sukses menolak instansi');
    window.location = "../../pages/dosbing/permintaan_sign_up.php";
</script>