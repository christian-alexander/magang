<?php

include("../../../connection/connection.php");
$seleksiUtama=mysqli_query($connection,"SELECT * FROM akun");
$jumlahRowUtama=mysqli_num_rows($seleksiUtama);
if($_POST['peran']==2){
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nidn = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $id_utama = $jumlahRowUtama+1;
    
    $seleksiRowDosbing = mysqli_query($connection,"SELECT * FROM dosen_pembimbing");
    $jumlahRowDosbing = mysqli_num_rows($seleksiRowDosbing);
    $id = $jumlahRowDosbing + 1 ;

    mysqli_query($connection,"INSERT INTO `dosen_pembimbing` (`id`,`id_utama`, `email`, `nama`, `nidn`, `nowa`, `instansi`) VALUES ('$id','$id_utama', '$email', '$nama', '$nidn', '$nowa', '$instansi')");
	mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '2', '12345678', '$email', 'on')");
}else if($_POST['peran']==3){
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nip = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $id_utama = $jumlahRowUtama+1;

    $seleksiRowPemlap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
    $jumlahRowPemlap = mysqli_num_rows($seleksiRowPemlap);
    $id = $jumlahRowPemlap + 1 ;

    mysqli_query($connection,"INSERT INTO `pembimbing_lapangan` (`id`,`id_utama`, `email`, `nama`, `nip`, `nowa`, `instansi`) VALUES ('$id','$id_utama', '$email', '$nama', '$nip', '$nowa', '$instansi')");
	mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '3', '12345678', '$email', 'on')");
}else if($_POST['peran']==4){
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nrp = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $DosBing = $_POST['dosen_pembimbing'];
    $PemLap = $_POST['pembimbing_lapangan'];
    $id_utama = $jumlahRowUtama+1;

    $seleksiRowMahasiswa = mysqli_query($connection,"SELECT * FROM mahasiswa");
    $jumlahRowMahasiswa = mysqli_num_rows($seleksiRowMahasiswa);
    $id = $jumlahRowMahasiswa + 1 ;

    mysqli_query($connection,"INSERT INTO `mahasiswa` (`id`,`id_utama`, `email`, `nama`, `nrp`, `nowa`,`dosenpembimbing`,`pembimbinglapangan`, `instansi`) VALUES ('$id','$id_utama', '$email', '$nama', '$nrp', '$nowa', '$DosBing', '$PemLap', '$instansi')");
    
    mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '4', '12345678', '$email', 'on')");
    
    mysqli_query($connection,"INSERT INTO `status_magang` (`id_utama`) VALUES ('$id_utama') ");

    mysqli_query($connection,"CREATE TABLE `magang`.`_data_absen_mhs".$id_utama."` ( `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , `id_absen` INT NOT NULL , `tanggal` DATE NOT NULL , `jam_masuk` CHAR(50) NOT NULL , `jam_pulang` CHAR(50) NOT NULL , `uraian_kegiatan` TEXT NOT NULL,`status` CHAR(20) NOT NULL DEFAULT 'Diajukan' , PRIMARY KEY (`id_absen`)) ENGINE = InnoDB;");
    
	mysqli_query($connection,"CREATE TABLE `magang`.`_data_file_absen_mhs".$id_utama."` ( `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , `id_file` INT NOT NULL , `id_absen` INT NOT NULL , `file` VARCHAR(1000) NOT NULL , PRIMARY KEY (`id_file`)) ENGINE = InnoDB;");
}

?>

<script>
	alert("Sukses Menambah Akun. Password default adalah 12345678, yang nanti bisa diubah sendiri oleh pemilik akun");
 	window.location= "../../../pages/superuser/akun.php";
</script>
