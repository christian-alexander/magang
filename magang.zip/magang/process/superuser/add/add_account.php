<?php

include("../../../connection/connection.php");
$seleksiUtama=mysqli_query($connection,"SELECT * FROM akun");
$jumlahRowUtama=mysqli_num_rows($seleksiUtama);
if($_POST['peran']==2){
    $seleksiRowDosen = mysqli_query($connection,"SELECT * FROM dosen_pembimbing");
    $jumlahRowDosen = mysqli_num_rows($seleksiRowDosen);
    $id = $jumlahRowDosen + 1 ;
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nidn = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $id_utama = $jumlahRowUtama+1;
    mysqli_query($connection,"INSERT INTO `dosen_pembimbing` (`id`,`id_utama`, `email`, `nama`, `nidn`, `nowa`, `instansi`) VALUES ('$id', '$id_utama', '$email', '$nama', '$nidn', '$nowa', '$instansi')");
	mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '2', '1234', '$email', 'on')");
}else if($_POST['peran']==3){
    $seleksiRowPemLap = mysqli_query($connection,"SELECT * FROM pembimbing_lapangan");
    $jumlahRowPemLap = mysqli_num_rows($seleksiRowPemLap);
    $id = $jumlahRowPemLap + 1 ;
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nip = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $id_utama = $jumlahRowUtama+1;
    mysqli_query($connection,"INSERT INTO `pembimbing_lapangan` (`id`,`id_utama`, `email`, `nama`, `nip`, `nowa`, `instansi`) VALUES ('$id','$id_utama', '$email', '$nama', '$nip', '$nowa', '$instansi')");
	mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '3', '1234', '$email', 'on')");
}else if($_POST['peran']==4){
    $seleksiRowMhs = mysqli_query($connection,"SELECT * FROM mahasiswa");
    $jumlahRowMhs = mysqli_num_rows($seleksiRowMhs);
    $id = $jumlahRowMhs + 1 ;
    $nama = $_POST['nama'];
    $nowa = $_POST['nowa'];
    $email = $_POST['email'];
    $nrp = $_POST['NRP'];
    $instansi = $_POST['instansi'];
    $DosBing = $_POST['dosen_pembimbing'];
    $PemLap = $_POST['pembimbing_lapangan'];
    $id_utama = $jumlahRowUtama+1;
    mysqli_query($connection,"INSERT INTO `mahasiswa` (`id`,`id_utama`, `email`, `nama`, `nrp`, `nowa`,`dosenpembimbing`,`pembimbinglapangan`, `instansi`) VALUES ('$id','$id_utama', '$email', '$nama', '$nrp', '$nowa', '$DosBing', '$PemLap', '$instansi')");
    
    mysqli_query($connection,"INSERT INTO `akun` (`id_utama`, `nama`, `entitas`, `password`, `email`, `status`) VALUES ('$id_utama','$nama', '4', '1234', '$email', 'on')");
    
}

?>

<script>
	alert("Sukses Menambah Akun");
 	window.location= "../../../pages/superuser/akun.php";
</script>
