<?php

include("../../../connection/connection.php");
$seleksiRowInstansi = mysqli_query($connection,"SELECT * FROM instansi");
$jumlahRowInstansi = mysqli_num_rows($seleksiRowInstansi);
$jumlahRowInstansi2 = $jumlahRowInstansi + 1 ;
$id_instansi = $jumlahRowInstansi2 ;
$Nama = $_POST['Nama'];
$NoTelp = $_POST['NoTelp'];
$NoFax = $_POST['NoFax'];
$Email = $_POST['Email'];
$Alamat = $_POST['Alamat'];
mysqli_query($connection,"INSERT INTO `instansi` (`id_instansi`, `nama`, `notelp`, `nofax`, `email`, `alamat`, `status`) VALUES ('$id_instansi','$Nama', '$NoTelp', '$NoFax', '$Email', '$Alamat', 'on')");

?>

<script>
    
	alert("Sukses Menambah Instansi");
 	window.location= "../../../pages/superuser/instansi.php";
	
</script>
