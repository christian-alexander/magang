<?php
include("../../../connection/connection.php");
$Nama = $_POST['Nama'];
$NoTelp = $_POST['NoTelp'];
$NoFax = $_POST['NoFax'];
$Email = $_POST['Email'];
$Alamat = $_POST['Alamat'];
mysqli_query($connection,"INSERT INTO `instansi` (`nama`, `notelp`, `nofax`, `email`, `alamat`, `status`) VALUES ('$Nama', '$NoTelp', '$NoFax', '$Email', '$Alamat', 'on')");

?>

<script>
    
	alert("Sukses Menambah Instansi");
 	window.location= "../../../pages/superuser/instansi.php";
	
</script>
