<?php
    include('../../../connection/connection.php');
    mysqli_query($connection,"UPDATE `akun` SET `status` = 'off' WHERE `akun`.`id_utama` = '".$_POST['dataDeleteValue']."'");
	header("Location: ../../../pages/superuser/akun.php");
?>
