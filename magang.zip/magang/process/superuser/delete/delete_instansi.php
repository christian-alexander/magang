<?php
    include('../../../connection/connection.php');
    mysqli_query($connection,"UPDATE `instansi` SET `status` = 'off' WHERE `id_instansi` = '".$_POST['dataDeleteValue']."'");
	header("Location: ../../../pages/superuser/instansi.php");
?>
