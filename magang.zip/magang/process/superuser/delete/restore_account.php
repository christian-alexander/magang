<?php
    include('../../../connection/connection.php');
    mysqli_query($connection,"UPDATE `akun` SET `status` = 'on' WHERE `akun`.`id_utama` = '".$_POST['dataRestoreValue']."'");
	header("Location: ../../../pages/superuser/akun.php");
?>