<?php
    include('../../../connection/connection.php');
    mysqli_query($connection,"UPDATE `instansi` SET `status` = 'on' WHERE `id_instansi` = '".$_POST['dataRestoreValue']."'");
	header("Location: ../../../pages/superuser/instansi.php");
?>