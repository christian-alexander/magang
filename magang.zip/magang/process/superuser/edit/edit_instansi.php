<?php

include("../../../connection/connection.php");
$id_instansi = $_POST['id_instansi'];
$Nama = $_POST['Nama'];
$NoTelp = $_POST['NoTelp'];
$NoFax = $_POST['NoFax'];
$Email = $_POST['Email'];
$Alamat = $_POST['Alamat'];
mysqli_query($connection,"UPDATE `instansi` SET `nama` = '$Nama',`notelp` = '$NoTelp',`nofax` = '$NoFax', `alamat` = '$Alamat', `email` = '$Email'  WHERE `id_instansi` = '".$id_instansi."'");

?>

<script>
    
	alert("Sukses Mengedit Instansi");
 	window.location= "../../../pages/superuser/instansi.php";
	
</script>
