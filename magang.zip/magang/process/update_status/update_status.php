<?php
include("../../connection/connection.php");

//intinya adalah menyimpan timestamp lama ke slot yg ada
//timestamp terkini adalah timestamp... karena itu tidak ada timestamp 5
// karena 4 time slot + timestamp saat ini sudah 5 slot

$idStatusLama = $_POST['idStatus'];
$idStatus = $idStatusLama + 1 ;
$idUtama = $_POST['idUtama'];

$seleksiRowStatus = mysqli_query($connection,"SELECT * FROM status_magang WHERE id_utama = '".$idUtama."'");
$seleksiKolomStatus = mysqli_fetch_assoc($seleksiRowStatus);
$time = $seleksiKolomStatus['timestamp'];

if($idStatusLama == 1){
    mysqli_query($connection, "UPDATE status_magang SET id_status = '$idStatus', time1 = '$time' WHERE id_utama = '".$idUtama."'");
}else if($idStatusLama == 2){
    mysqli_query($connection, "UPDATE status_magang SET id_status = '$idStatus', time2 = '$time' WHERE id_utama = '".$idUtama."'");
}else if($idStatusLama == 3){
    mysqli_query($connection, "UPDATE status_magang SET id_status = '$idStatus', time3 = '$time' WHERE id_utama = '".$idUtama."'");
}else if($idStatusLama == 4){
    mysqli_query($connection, "UPDATE status_magang SET id_status = '$idStatus',time4 = '$time' WHERE id_utama = '".$idUtama."'");
    mysqli_query($connection,"UPDATE akun SET `status` = 'off' WHERE  id_utama = '".$idUtama."'");
}

?>



<form method = "POST" action = "../../pages/superuser/nav_detil_mahasiswa.php">
    <input type = "text" name = "dataValue" style = "display : none ;" value = "<?php echo $idUtama ?>">
    <button id = "tombol" style = "display : none"></button>
</form>


<script>
    alert("Status berhasil diubah");
    var tombol = document.getElementById('tombol');
    tombol.click() 
</script>
