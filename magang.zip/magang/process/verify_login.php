<?php
session_start();
include('../connection/connection.php');

$seleksiAkun = mysqli_query($connection,"SELECT * FROM akun");
foreach($seleksiAkun as $row){
    if($row['status'] == "on"){
        if($row['email'] == $_POST['email']){
            $emailKetemu = TRUE ;
            $id_utama = $row['id_utama'];
            break;
        }else{
            $emailKetemu = FALSE;
        }
        $emailKetemu = FALSE ;
    }
}

if($emailKetemu){
    $seleksiAkunKetemu = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama = '".$id_utama."'");
    foreach($seleksiAkunKetemu as $row){
        if ($row['password'] == $_POST['password']){
            if($row['entitas'] == 1){
                header("Location: ../pages/superuser/home.php");
                $_SESSION['loggedUser'] = $row['id_utama'];
            }else if($row['entitas'] == 2){
                header("Location: ../pages/dosbing/home.php");
                $_SESSION['loggedUser'] = $row['id_utama'];
            }else if($row['entitas'] == 3){
                header("Location: ../pages/pemlap/home.php");
                $_SESSION['loggedUser'] = $row['id_utama'];
            }else if($row['entitas'] == 4){
                header("Location: ../pages/mahasiswa/home.php");
                $_SESSION['loggedUser'] = $row['id_utama'];
            }
        }else{
            $errorMessage = "Password yang masukkan salah";
        }
    }
}else{
    $errorMessage = "Email tidak terdaftar di sistem";
}
?>

<script>
	alert("<?php echo $errorMessage ?>");
    window.location = "../index.php";
</script>
