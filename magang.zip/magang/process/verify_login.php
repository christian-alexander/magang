<?php
session_start();
include('../connection/connection.php');

$seleksi = mysqli_query($connection, "SELECT * FROM akun");
$jumlahRow = mysqli_num_rows($seleksi);
$emailKetemu = False ;
for ($row = 1 ; $row <= $jumlahRow ; $row++){
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id_utama = $row");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    if ($_POST['email'] == $seleksiKolom['email']) {
        $emailKetemu = True ;
        break;
    }
    else{
		continue;
    }
}
if ($emailKetemu){
    $passwordEncrypted = $seleksiKolom['password'] ;
    /* 
    	proses decrypt
    */
    $passwordPlain = $passwordEncrypted ;
    if ($_POST['password'] == $passwordPlain){
        if($seleksiKolom['status'] == 'on'){
            $_SESSION['loggedUser'] = $seleksiKolom['id_utama'];
            if ($seleksiKolom['entitas'] == 1){
                header('Location: ../pages/superuser/home.php') ;
                exit ;
            }
            else if ($seleksiKolom['entitas'] == 2 ){
                header('Location: ../pages/dosbing/home.php') ;
                exit ;
            }
            else if ($seleksiKolom['entitas'] == 3){
                header('Location: ../pages/pemlap/home.php') ;
                exit ;
            }
            else if ($seleksiKolom['entitas'] == 4){
                header('Location: ../pages/mahasiswa/home.php') ;
                exit ;
            }
        }
        else{
            $errorMessage = 'Akun telah non-aktif' ;
        }
    }
    else{
        $errorMessage = 'Password yang anda masukkan salah' ;
    }
}
else{
    $errorMessage = 'Email tidak terdaftar di sistem' ;
}

?>

<script>
	alert("<?php echo $errorMessage ?>");
    window.location = "../index.php";
</script>
