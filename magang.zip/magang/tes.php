<?php

include('connection/connection.php');
$seleksiRowCoba = mysqli_query($connection, "SELECT * FROM status_magang WHERE id_utama = 5");
$seleksiKolomCoba = mysqli_fetch_assoc($seleksiRowCoba);
$waktu = $seleksiKolomCoba['timestamp'];
$keywords = preg_split("/[\s]+/", "$waktu");
print($keywords[1]);
?>