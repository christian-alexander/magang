<?php
    $arr = array(array(11,12),array(21,22));
    echo $arr[0][0] . $arr[1][1];
?>