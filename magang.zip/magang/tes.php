                        <div class = "col-lg-4 col-md-6 col-sm-12 col-xs-12">
                            No Telepon<a id="warningNoTelp" style="color:red;"></a>                            
                            <p>
                                <input type = "text" name="NoTelp" id="NoTelp" class = "inside-box" value="">
                            </p>
                        </div>