

<input type="time" id="waktu">


<button onclick ="tes()">button</button>

<script>
    function tes(){
        var waktu = document.getElementById('waktu');
        alert("t"+waktu.value+"t");
    }
</script>