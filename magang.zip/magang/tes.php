<?php echo (strtotime('2021-01-24')-strtotime('2021-1-23'))/(24*60*60)?><br>
<?php echo date("Y-m-d"); ?>