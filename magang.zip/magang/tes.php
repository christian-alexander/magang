							<form class="tombol" method="POST" action="#" onsubmit ="return getIdentitasAcceptInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>()">
                            	<span><a href="#" class="done" title="Setujui" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">done</i></button></a></span> 
                                <input type="text" id="dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>" name="dataAcceptInstansiValue" value="" style="display:none;">
                                <script>
                                    function getIdentitasAcceptInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>(){
                                        if (confirm("Yakin terima permintaan instansi <?php echo $daftarPermintaanInstansi[$baris][1]?> ?")){
                                            var dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?> = document.getElementById("dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>");
                                            dataAcceptInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>.value = "<?php echo $daftarPermintaanInstansi[$baris][0] ?>";
                                            return true;
                                        }else{
                                            return false;
                                        }
                                    }
                                </script>
                            </form>
                            <form class="tombol" method="POST" action="#" onsubmit ="return getIdentitasDeclineInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>()">
                                <span><a href="#" class="block" title="Tolak" data-toggle="tooltip"><button type="submit" style="background:rgba(0,0,0,0);color:inherit;border:0px solid white;"><i class="material-icons">block</i></button></a></span> 
                                <input type="text" id="dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>" name="dataDeclineInstansiValue" value="" style="display:none;">
                                <script>
                                        function getIdentitasDeclineInstansi<?php echo $daftarPermintaanInstansi[$baris][0] ?>(){
                                            if (confirm("Yakin tolak permintaan akun <?php echo $daftarPermintaanInstansi[$baris][1]?> ?")){
                                                var dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?> = document.getElementById("dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>");
                                                dataDeclineInstansiValue<?php echo $daftarPermintaanInstansi[$baris][0] ?>.value = "<?php echo $daftarPermintaanInstansi[$baris][0] ?>";
                                                return true;
                                            }else{
                                                return false;
                                            }
                                        }
                                </script>
                            </form>