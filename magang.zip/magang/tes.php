<form method = "POST" action = "tes2.php">
    <input type = "time" name = "jam_masuk" value = "">
    <input type = "time" name = "jam_pulang" value = "">
    <input type = "date" name = "tanggal" value = "">
    <button>submit</button> 
</form>