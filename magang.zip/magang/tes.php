<?php
include("connection/connection.php");

$tes = mysqli_query($connection,"SELECT * FROM akun WHERE id_utama = 100");
$op = mysqli_fetch_assoc($tes);
if(null === $op){
    echo "kakj";
}