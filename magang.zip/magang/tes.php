<script>
    var testis = "90";
    var tes = parseInt(testis);
	if (isNaN(testis)){
        alert("asu")
    }else{
        alert('kontol')
    }
</script>