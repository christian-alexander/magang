<form onsubmit = "hei()">
<button>hei</button>
</form>

<script>
function hei(){
    alert("hei")
}
</script>