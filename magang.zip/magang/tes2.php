<?php

include("connection/connection.php");
$no = 5;
$tes = mysqli_query($connection, "INSERT INTO _data_absen_mhs".$no." (jam_masuk,jam_pulang,tanggal) VALUES ('".$_POST['jam_masuk']."' , '".$_POST['jam_pulang']."', '".$_POST['tanggal']."')");
var_dump($tes);
?>