function judulLaporan(){
    var judulLaporan = document.getElementById('judulLaporan');
    var judul = prompt("Judul Laporan");
    if(judul != null && judul !=""){
        judulLaporan.innerHTML = judul ;
        return true ;
    }else{
        return false;
    }
}