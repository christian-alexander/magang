<?php
include('connection/connection.php');
mysqli_query($connection,"INSERT INTO _data_absen_mhs5 (id_absen)VALUES('1')");
?>