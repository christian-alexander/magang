<?php
session_start();
include('../connection/connection.php');

$seleksi = mysqli_query($connection, "SELECT * FROM akun");
$jumlahRow = mysqli_num_rows($seleksi);
$emailKetemu = False ;
for ($row = 1 ; $row <= $jumlahRow ; $row++){
    $seleksiRow = mysqli_query($connection, "SELECT * FROM akun WHERE id = $row");
    $seleksiKolom = mysqli_fetch_assoc($seleksiRow);
    if ($_POST['email'] == $seleksiKolom['email']) {
        $emailKetemu = True ;
        break;
    }
    else{
		continue;
    }
}
if ($emailKetemu){
    $passwordEncrypted = $seleksiKolom['password'] ;
    /* 
    	proses decrypt
    */
    $passwordPlain = $passwordEncrypted ;
    if ($_POST['password'] == $passwordPlain){
        if($seleksiKolom['status'] == 'on'){
            $_SESSION['loggedUser'] = $seleksiKolom['email'];
            if ($seleksiKolom['entitas'] == 1){
                header('Location: ../pages/superuser/home.php') ;
                exit ;
            }
            else if ($seleksiKolom['entitas'] == 2  or $seleksiKolom['entitas'] == 3){
                header('Location: ../pages/admin/home.php') ;
                exit ;
            }
            else if ($seleksiKolom['entitas'] == 4){
                header('Location: ../pages/user/home.php') ;
                exit ;
            }
        }
        else{
            $errorTitle = 'Akun Non Aktif' ;
            $errorMessage = 'Akun telah non-aktif' ;
        }
    }
    else{
        $errorTitle = 'Password Salah';
        $errorMessage = 'Password yang anda masukkan salah' ;
    }
}
else{
    $errorTitle = 'Email Salah';
    $errorMessage = 'Email tidak terdaftar di sistem' ;
}

?>


<!DOCTYPE html>
<head>
    <title>Magang Informatika</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width = device-width, initial-scale = 1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="../css/login_warna.css">
	<style>
    	.error-message{
            text-align : right ;
        }
    </style>
</head>
<body>
	<div class = "box">
		<div class = "box2">
			<div class = "box3">
				<div class = teks-login>
					<b><?php echo $errorTitle ?></b>
				</div>
                <form action = "../index.php">			
                    <ul>
                        <li>
                            <a class = "errorMessage"><?php echo $errorMessage ?></a>
                        </li>
                        <br>
                        <li>
                            <input type = "submit" class = "btn btn-success btn-submit" value = "OK">
                        </li>
                    </ul>
                </form>
			</div>
		</div>		
	</div>	


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>